logsumexp <- function(x) {
    m <- max(x)
    m + log(sum(exp(x - m)))
}

weighted_mean <- function(x, w) {
    ok <- is.finite(x) & is.finite(w) & w > 0
    if (!any(ok)) 
        return(NA_real_)
    sum(x[ok] * w[ok])/sum(w[ok])
}

mfrm_cpp11_backend_available <- function() {
    exists("mfrm_cpp_rsm_logprob_bundle", mode = "function") && exists("mfrm_cpp_pcm_logprob_bundle", 
        mode = "function") && exists("mfrm_cpp_gpcm_logprob_bundle", mode = "function") && exists("mfrm_cpp_mml_eval_bundle", 
        mode = "function") && exists("mfrm_cpp_jml_eval_bundle", mode = "function") && exists("mfrm_cpp_adaptive_quad_basis", 
        mode = "function") && exists("mfrm_cpp_adaptive_mml_eval", mode = "function") && exists("mfrm_cpp_cml_esf", 
        mode = "function") && exists("mfrm_cpp_indexed_sum", mode = "function") && exists("mfrm_cpp_expected_category_bundle", 
        mode = "function") && exists("mfrm_cpp_compute_p_geq", mode = "function") && exists("mfrm_cpp_testlet_kernel", 
        mode = "function") && exists("mfrm_cpp_marginal_pairwise_expectations", mode = "function")
}

mfrm_use_cpp11_backend <- function(config, include_linear_part = FALSE) {
    isTRUE(getOption("mfrmr.use_cpp11_backend", TRUE)) && mfrm_cpp11_backend_available() && identical(config$model %in% 
        c("RSM", "PCM", "GPCM"), TRUE)
}

mfrm_model_code <- function(model) {
    if (identical(model, "RSM")) 
        return(0L)
    if (identical(model, "GPCM")) 
        return(2L)
    1L
}

mfrm_step_cum_matrix <- function(steps_mat) {
    nr <- nrow(steps_mat)
    nc <- ncol(steps_mat)
    out <- matrix(0, nrow = nr, ncol = nc + 1L)
    if (nc >= 1L) {
        acc <- numeric(nr)
        for (s in seq_len(nc)) {
            acc <- acc + steps_mat[, s]
            out[, s + 1L] <- acc
        }
    }
    out
}

mfrmr_gpcm_model_identity <- function(model, gpcm_spec = NULL) {
    is_gpcm <- identical(toupper(as.character(model)[1]), "GPCM")
    product <- is_gpcm && !is.null(gpcm_spec$component_levels)
    list(model_family = if (product) {
        "two_owner_product_slope_gpcm"
    } else if (is_gpcm) {
        "aligned_single_owner_relative_slope_gpcm"
    } else {
        "not_applicable"
    }, slope_action = if (is_gpcm) {
        "complete_adjacent_predictor"
    } else {
        "not_applicable"
    }, slope_composition = if (product) {
        "two_owner_product_first_gm1"
    } else if (is_gpcm) {
        "single_owner_relative_gm1"
    } else {
        "not_applicable"
    }, latent_dimension_count = if (is_gpcm) 1L else NA_integer_)
}

get_weights <- function(df) {
    if (!is.null(df) && "Weight" %in% names(df)) {
        w <- suppressWarnings(as.numeric(df$Weight))
        w <- ifelse(is.finite(w) & w > 0, w, 0)
        return(w)
    }
    rep(1, nrow(df))
}

mfrm_convergence_state <- function(fit) {
    summary_row <- if (is.data.frame(fit)) {
        fit
    }
    else if (is.list(fit) && "summary" %in% names(fit) && is.data.frame(fit[["summary"]])) {
        fit[["summary"]]
    }
    else {
        data.frame()
    }
    first_value <- function(name, default = NA) {
        if (nrow(summary_row) > 0L && name %in% names(summary_row)) {
            summary_row[[name]][1]
        }
        else {
            default
        }
    }
    code_converged <- isTRUE(as.logical(first_value("Converged", FALSE)))
    severity <- tolower(trimws(as.character(first_value("ConvergenceSeverity", ""))))
    status <- tolower(trimws(as.character(first_value("ConvergenceStatus", ""))))
    detail <- as.character(first_value("ConvergenceDetail", ""))
    direct_current <- is.data.frame(fit) && nrow(summary_row) > 0L && "ReadinessContractVersion" %in% 
        names(summary_row) && identical(as.character(summary_row$ReadinessContractVersion[1]), mfrmr_readiness_contract_version())
    readiness_row <- if (direct_current) {
        summary_row
    }
    else {
        mfrmr_get_readiness_record(fit)$fit
    }
    readiness_value <- function(name, default = NA) {
        if (nrow(readiness_row) > 0L && name %in% names(readiness_row)) {
            readiness_row[[name]][1]
        }
        else {
            default
        }
    }
    contract_version <- as.character(readiness_value("ReadinessContractVersion", ""))
    recorded_inference_ready <- as.logical(readiness_value("InferenceReady", FALSE))
    inference_ready <- identical(contract_version, mfrmr_readiness_contract_version()) && isTRUE(recorded_inference_ready)
    list(code_converged = code_converged, inference_ready = isTRUE(inference_ready), severity = if (nzchar(severity)) severity else if (inference_ready) "pass" else "review", 
        status = if (nzchar(status)) status else if (inference_ready) "converged" else "not_converged", 
        detail = detail, fit_readiness = as.character(readiness_value("FitReadiness", "legacy_unknown")), 
        readiness_contract_version = contract_version)
}

mfrm_inference_ready <- function(fit) {
    isTRUE(mfrm_convergence_state(fit)$inference_ready)
}

gpcm_scope_helper_id <- function(helper) {
    helper <- as.character(helper[1] %||% "")
    helper_full <- helper
    if (grepl("facets_output_file_bundle", helper_full, fixed = TRUE) && grepl("score", helper_full, 
        fixed = TRUE)) {
        return("scorefile_export")
    }
    key <- sub("\\(.*$", "", helper)
    key <- trimws(key)
    switch(key, `export bundle helpers` = , build_mfrm_manifest = , build_mfrm_replay_script = , export_mfrm_bundle = , 
        build_apa_outputs = , build_visual_summaries = , run_qc_pipeline = "apa_export_bundles", facets_output_contract_review = "facets_score_review", 
        facets_output_file_bundle = "scorefile_export", predict_mfrm_population = , evaluate_mfrm_design = "design_forecasting", 
        evaluate_mfrm_diagnostic_screening = , evaluate_mfrm_signal_detection = "diagnostic_signal_screening", 
        analyze_dff = , analyze_dif = , dif_interaction_table = , dif_report = , plot_dif_heatmap = , 
        plot_dif_summary = "dff_screening", build_linking_review = "linking_synthesis", unexpected_after_bias_table = "residual_bias_screening", 
        estimation_iteration_report = "optimization_replay", NULL)
}

gpcm_scope_helper_area <- function(helper) {
    capability_id <- gpcm_scope_helper_id(helper)
    if (is.null(capability_id) || !exists(".gpcm_capability_registry", mode = "function")) {
        return(NULL)
    }
    registry <- .gpcm_capability_registry()
    idx <- match(capability_id, registry$CapabilityID)
    if (is.na(idx)) 
        NULL
    else registry$Area[[idx]]
}

new_gpcm_scope_error <- function(message, helper = NULL, area = NULL, status = NULL, recommended_route = NULL, 
    follow_up = NULL, next_validation_step = NULL, supported = NULL) {
    follow_up <- as.character(follow_up[1] %||% next_validation_step[1] %||% NA_character_)
    structure(list(message = as.character(message[1] %||% ""), helper = as.character(helper[1] %||% NA_character_), 
        area = as.character(area[1] %||% NA_character_), status = as.character(status[1] %||% NA_character_), 
        recommended_route = as.character(recommended_route[1] %||% NA_character_), follow_up = follow_up, 
        next_validation_step = follow_up, supported = as.character(supported[1] %||% NA_character_)), 
        class = c("mfrmr_gpcm_scope_error", "error", "condition"))
}

gpcm_capability_boundary_table <- function(fit = NULL, helper = NULL, area = NULL, extra_areas = character(0)) {
    empty <- data.frame(Area = character(0), Status = character(0), Boundary = character(0), RecommendedRoute = character(0), 
        ModelFamily = character(0), SlopeAction = character(0), SlopeComposition = character(0), LatentDimensionCount = integer(0), 
        SlopeOwner = character(0), StepOwner = character(0), PrimarySlopeStatus = character(0), SlopeUncertaintyStatus = character(0), 
        OwnerInterpretation = character(0), stringsAsFactors = FALSE)
    if (!inherits(fit, "mfrm_fit")) 
        return(empty)
    model <- as.character(fit$config$model %||% fit$summary$Model[1] %||% NA_character_)
    if (!identical(model, "GPCM")) 
        return(empty)
    if (!exists(".gpcm_capability_registry", mode = "function")) 
        return(empty)
    tbl <- .gpcm_capability_registry()
    primary_area <- as.character(area[1] %||% gpcm_scope_helper_area(helper) %||% "")
    areas <- unique(c(primary_area, as.character(extra_areas %||% character(0))))
    areas <- areas[nzchar(areas)]
    if (length(areas) == 0L) 
        return(empty)
    out <- tbl[tbl$Area %in% areas, c("Area", "Status", "Boundary", "RecommendedRoute"), drop = FALSE]
    out <- out[match(areas[areas %in% out$Area], out$Area), , drop = FALSE]
    identity <- mfrmr_gpcm_model_identity(model)
    out$ModelFamily <- as.character(fit$config$gpcm_model_family %||% identity$model_family)
    out$SlopeAction <- as.character(fit$config$gpcm_slope_action %||% identity$slope_action)
    out$SlopeComposition <- as.character(fit$config$gpcm_slope_composition %||% identity$slope_composition)
    out$LatentDimensionCount <- as.integer(fit$config$gpcm_latent_dimension_count %||% identity$latent_dimension_count)
    slope_tbl <- as.data.frame(fit$slopes %||% data.frame(), stringsAsFactors = FALSE)
    slope_status <- if (nrow(slope_tbl) > 0L && "ParameterStatus" %in% names(slope_tbl)) {
        as.character(slope_tbl$ParameterStatus)
    }
    else {
        character(0)
    }
    slope_status <- slope_status[!is.na(slope_status) & nzchar(slope_status)]
    primary_status <- if (length(slope_status) == 0L) {
        "legacy_or_unresolved_review_required"
    }
    else if (all(slope_status == "fixed")) {
        "fixed_unit_slope_primary"
    }
    else if (all(slope_status == "finite_local_solution")) {
        "verified_local_point_estimate"
    }
    else if (all(slope_status == "finite_numerical_solution")) {
        "finite_numerical_point_estimate"
    }
    else if (any(slope_status == "finite_likelihood_limit")) {
        "partial_limiting_point_estimates"
    }
    else if (identical(fit$config$gpcm_point_estimation$overview$Status, "finite_maximum_absent")) {
        "no_finite_joint_maximum"
    }
    else if (any(slope_status %in% c("unbounded_low", "unbounded_high", "unbounded_both"))) {
        "typed_extended_boundary_primary_only"
    }
    else {
        "primary_slope_suppressed_optimizer_trace_only"
    }
    uncertainty_status <- if (length(slope_status) == 0L) {
        "legacy_or_unresolved_review_required"
    }
    else if (all(slope_status == "fixed")) {
        "not_applicable_fixed_unit_slope"
    }
    else if ("SEEligible" %in% names(slope_tbl) && all(!is.na(slope_tbl$SEEligible)) && all(as.logical(slope_tbl$SEEligible))) {
        "eligible_per_parameter_readiness"
    }
    else {
        "not_eligible_per_parameter_readiness"
    }
    out$SlopeOwner <- as.character(fit$config$slope_facet %||% NA_character_)
    out$StepOwner <- as.character(fit$config$step_facet %||% NA_character_)
    out$PrimarySlopeStatus <- primary_status
    out$SlopeUncertaintyStatus <- uncertainty_status
    out$OwnerInterpretation <- "model_conditional_discrimination_not_rater_consistency"
    rownames(out) <- NULL
    out
}

gauss_hermite_normal <- function(n) {
    if (!is.numeric(n) || length(n) != 1L || !is.finite(n) || n < 1 || n != floor(n) || n > .Machine$integer.max) {
        stop("Gauss-Hermite quadrature requires integer n >= 1 quadrature points. ", "Check the 'quad_points' argument.", 
            call. = FALSE)
    }
    if (n == 1) {
        return(list(nodes = 0, weights = 1))
    }
    i <- seq_len(n - 1)
    jmat <- matrix(0, nrow = n, ncol = n)
    jmat[cbind(i, i + 1)] <- sqrt(i)
    jmat[cbind(i + 1, i)] <- sqrt(i)
    nodes <- eigen(jmat, symmetric = TRUE, only.values = TRUE)$values
    nodes <- (nodes - rev(nodes))/2
    previous <- exp(-nodes^2/4)
    current <- nodes * previous
    squares <- previous^2 + current^2
    if (n > 2) 
        for (k in 2:(n - 1)) {
            next_value <- (nodes * current - sqrt(k - 1) * previous)/sqrt(k)
            previous <- current
            current <- next_value
            squares <- squares + current^2
        }
    weights <- exp(-nodes^2/2 - log(squares))
    if (any(!is.finite(weights)) || any(weights <= 0)) {
        stop("Gauss-Hermite weights cannot all be represented as positive finite ", "doubles at this order; reduce 'quad_points'.", 
            call. = FALSE)
    }
    weights <- weights/sum(weights)
    list(nodes = nodes, weights = weights)
}

compact_population_spec <- function(population = NULL, person_levels = character(0)) {
    pop <- population %||% list()
    person_levels <- as.character(person_levels %||% character(0))
    person_table <- pop$person_table
    person_id <- as.character(pop$person_id %||% "Person")
    person_lookup <- integer(0)
    if (!is.null(person_table) && is.data.frame(person_table) && length(person_levels) > 0 && person_id %in% 
        names(person_table)) {
        person_lookup <- match(person_levels, as.character(person_table[[person_id]]))
    }
    out <- list(active = isTRUE(pop$active), source = as.character(pop$source %||% "none"), identification_role = as.character(pop$identification_role %||% 
        "not_applicable"), posterior_basis = as.character(pop$posterior_basis %||% if (isTRUE(pop$active)) "population_model" else "legacy_mml"), 
        formula = pop$formula %||% NULL, terms = pop$terms %||% NULL, person_id = person_id, design_matrix = pop$design_matrix %||% 
            NULL, design_columns = pop$design_columns %||% if (!is.null(pop$design_matrix)) colnames(pop$design_matrix) else NULL, 
        xlevels = pop$xlevels %||% NULL, contrasts = pop$contrasts %||% NULL, coefficients = pop$coefficients %||% 
            NULL, sigma2 = pop$sigma2 %||% NULL, converged = isTRUE(pop$converged), estimation_converged = isTRUE(pop$estimation_converged), 
        inference_ready = isTRUE(pop$inference_ready), converged_basis = as.character(pop$converged_basis %||% 
            "legacy_unspecified"), policy = pop$policy %||% NULL, person_lookup = person_lookup, person_rows = if (!is.null(person_table) && 
            is.data.frame(person_table)) {
            nrow(person_table)
        } else {
            0L
        }, included_persons = as.character(pop$included_persons %||% character(0)), omitted_persons = as.character(pop$omitted_persons %||% 
            character(0)), response_rows_retained = as.integer(pop$response_rows_retained %||% NA_integer_), 
        response_rows_omitted = as.integer(pop$response_rows_omitted %||% NA_integer_), notes = pop$notes %||% 
            character(0))
    if (!is.null(pop$fixed_sd)) 
        out$fixed_sd <- pop$fixed_sd
    out
}

materialize_population_spec <- function(config, params = NULL) {
    pop <- config$population_spec %||% list()
    if (!is.null(params) && !is.null(params$population)) {
        if (!is.null(params$population$coefficients)) {
            pop$coefficients <- params$population$coefficients
        }
        if (!is.null(params$population$sigma2)) {
            pop$sigma2 <- params$population$sigma2
        }
    }
    pop
}

resolve_person_quadrature_basis <- function(quad, population_spec = NULL, person_ids = NULL, person_count = NULL) {
    if (!is.null(quad$person_basis)) 
        return(quad$person_basis)
    if (is.null(person_ids)) {
        n_persons <- as.integer(person_count %||% 0L)
        person_ids <- seq_len(max(0L, n_persons))
    }
    else {
        person_ids <- as.integer(person_ids)
        n_persons <- length(person_ids)
    }
    n_nodes <- length(quad$nodes)
    log_weights <- matrix(log(quad$weights), nrow = n_persons, ncol = n_nodes, byrow = TRUE)
    default_nodes <- matrix(quad$nodes, nrow = n_persons, ncol = n_nodes, byrow = TRUE)
    pop <- population_spec %||% list()
    if (!isTRUE(pop$active)) {
        return(list(nodes = default_nodes, log_weights = log_weights, posterior_basis = as.character(pop$posterior_basis %||% 
            "legacy_mml"), transformed = FALSE))
    }
    if (is.null(pop$design_matrix) || is.null(pop$coefficients) || is.null(pop$sigma2)) {
        stop("Population-model quadrature requested before regression coefficients and variance were estimated.", 
            call. = FALSE)
    }
    if (length(pop$person_lookup) == 0L || anyNA(pop$person_lookup[person_ids])) {
        stop("Population-model quadrature could not align all fitted persons to the latent-regression person table.", 
            call. = FALSE)
    }
    design_matrix <- pop$design_matrix[pop$person_lookup[person_ids], , drop = FALSE]
    beta <- as.numeric(pop$coefficients)
    if (length(beta) != ncol(design_matrix)) {
        stop("Population-model coefficient length does not match the latent-regression design matrix.", 
            call. = FALSE)
    }
    sigma2 <- as.numeric(pop$sigma2[1])
    if (!is.finite(sigma2) || sigma2 <= 0) {
        stop("Population-model residual variance `sigma2` must be a single positive finite value.", call. = FALSE)
    }
    mu <- as.numeric(design_matrix %*% beta)
    sigma <- sqrt(sigma2)
    nodes <- outer(mu, quad$nodes, FUN = function(m, z) m + sigma * z)
    list(nodes = nodes, log_weights = log_weights, posterior_basis = as.character(pop$posterior_basis %||% 
        "population_model"), transformed = TRUE, mu = mu, sigma = sigma)
}

center_sum_zero <- function(x) {
    if (length(x) == 0) 
        return(x)
    x - mean(x)
}

expand_facet <- function(free, n_levels) {
    if (n_levels <= 1) 
        return(rep(0, n_levels))
    c(free, -sum(free))
}

sum_zero_param_count <- function(n_levels) {
    max(as.integer(n_levels %||% 0L) - 1L, 0L)
}

build_step_constraint <- function(n_steps, anchors = NULL, target = 0, scope = "shared") {
    n_steps <- as.integer(n_steps %||% 0L)
    if (length(n_steps) != 1L || is.na(n_steps) || n_steps < 0L) {
        stop("`n_steps` must be one non-negative integer.", call. = FALSE)
    }
    target <- as.numeric(target %||% NA_real_)
    if (length(target) != 1L || !is.finite(target)) {
        stop("Step-constraint target must be one finite number.", call. = FALSE)
    }
    anchor_values <- rep(NA_real_, n_steps)
    names(anchor_values) <- as.character(seq_len(n_steps))
    if (!is.null(anchors) && length(anchors) > 0L) {
        if (is.null(names(anchors)) || anyNA(names(anchors)) || any(!nzchar(names(anchors))) || anyDuplicated(names(anchors))) {
            stop("Step anchors must have unique transition-index names.", call. = FALSE)
        }
        anchor_index <- suppressWarnings(as.integer(names(anchors)))
        if (anyNA(anchor_index) || any(anchor_index < 1L | anchor_index > n_steps) || any(as.character(anchor_index) != 
            names(anchors))) {
            stop("Step-anchor names must be canonical transition indices in range.", call. = FALSE)
        }
        anchor_numeric <- as.numeric(anchors)
        if (any(!is.finite(anchor_numeric))) {
            stop("Step-anchor values must be finite.", call. = FALSE)
        }
        anchor_values[anchor_index] <- anchor_numeric
    }
    free_index <- which(is.na(anchor_values))
    if (length(free_index) == 0L && !isTRUE(all.equal(sum(anchor_values), target, tolerance = 1e-12))) {
        stop("Fully anchored step coordinates are incompatible with the declared sum constraint.", call. = FALSE)
    }
    reference_index <- if (length(free_index) > 0L) {
        free_index[length(free_index)]
    }
    else {
        NA_integer_
    }
    list(scope = as.character(scope %||% "shared")[1], n_steps = n_steps, anchors = anchor_values, target = target, 
        free_index = as.integer(free_index), reference_index = as.integer(reference_index), n_params = as.integer(max(length(free_index) - 
            1L, 0L)), identification = "within_ladder_sum_to_target_with_fixed_anchors")
}

mfrmr_default_step_specs <- function(config) {
    n_steps <- max(as.integer(config$n_cat %||% 0L) - 1L, 0L)
    scopes <- if (identical(config$model, "RSM")) {
        "shared"
    }
    else {
        step_facet <- as.character(config$step_facet %||% NA_character_)
        if (length(step_facet) != 1L || is.na(step_facet) || !step_facet %in% as.character(config$facet_names %||% 
            character(0))) {
            stop("PCM model requires `step_facet` to name a declared facet.", call. = FALSE)
        }
        as.character(config$facet_levels[[step_facet]] %||% character(0))
    }
    specs <- lapply(scopes, function(scope) {
        build_step_constraint(n_steps = n_steps, scope = scope)
    })
    names(specs) <- scopes
    specs
}

mfrmr_step_specs <- function(config) {
    specs <- config$step_specs %||% mfrmr_default_step_specs(config)
    if (!is.list(specs)) {
        stop("Internal step-constraint specification must be a list.", call. = FALSE)
    }
    expected_scopes <- if (identical(config$model, "RSM")) {
        "shared"
    }
    else {
        as.character(config$facet_levels[[config$step_facet]] %||% character(0))
    }
    if (!identical(names(specs), expected_scopes)) {
        stop("Step-constraint scopes do not match the declared model ownership.", call. = FALSE)
    }
    n_steps <- max(as.integer(config$n_cat %||% 0L) - 1L, 0L)
    valid <- vapply(seq_along(specs), function(i) {
        spec <- specs[[i]]
        is.list(spec) && identical(as.integer(spec$n_steps), n_steps) && identical(as.character(spec$scope), 
            expected_scopes[i]) && length(spec$anchors) == n_steps && identical(as.integer(spec$free_index), 
            unname(which(is.na(spec$anchors)))) && identical(as.integer(spec$n_params), as.integer(max(length(spec$free_index) - 
            1L, 0L)))
    }, logical(1))
    if (!all(valid)) {
        stop("Step-constraint specification is inconsistent with the model.", call. = FALSE)
    }
    specs
}

expand_step_constraint <- function(free, spec) {
    out <- as.numeric(spec$anchors)
    free_index <- as.integer(spec$free_index)
    n_params <- as.integer(spec$n_params)
    free <- as.numeric(free %||% numeric(0))
    if (length(free) != n_params) {
        stop("Step parameter vector has length ", length(free), " but the typed step constraint requires ", 
            n_params, ".", call. = FALSE)
    }
    if (length(free_index) == 0L) 
        return(out)
    anchor_sum <- sum(out, na.rm = TRUE)
    if (length(free_index) == 1L) {
        out[free_index] <- spec$target - anchor_sum
        return(out)
    }
    estimated_index <- free_index[-length(free_index)]
    reference_index <- free_index[length(free_index)]
    out[estimated_index] <- free
    out[reference_index] <- spec$target - anchor_sum - sum(free)
    out
}

project_step_constraint_gradient <- function(grad_expanded, spec) {
    grad_expanded <- as.numeric(grad_expanded %||% numeric(0))
    if (length(grad_expanded) != as.integer(spec$n_steps)) {
        stop("Expanded step gradient does not match the typed step constraint.", call. = FALSE)
    }
    free_index <- as.integer(spec$free_index)
    if (length(free_index) <= 1L) 
        return(numeric(0))
    reference_index <- free_index[length(free_index)]
    grad_expanded[free_index[-length(free_index)]] - grad_expanded[reference_index]
}

initial_step_constraint_free <- function(x, spec) {
    x <- as.numeric(x %||% numeric(0))
    if (length(x) != as.integer(spec$n_steps)) {
        stop("Initial expanded steps do not match the typed step constraint.", call. = FALSE)
    }
    free_index <- as.integer(spec$free_index)
    if (length(free_index) <= 1L) 
        numeric(0)
    else {
        x[free_index[-length(free_index)]]
    }
}

expand_step_constraints <- function(free, specs) {
    free <- as.numeric(free %||% numeric(0))
    expected <- sum(vapply(specs, function(spec) {
        as.integer(spec$n_params)
    }, integer(1)))
    if (length(free) != expected) {
        stop("Step parameter vector has length ", length(free), " but the typed step constraints require ", 
            expected, ".", call. = FALSE)
    }
    rows <- vector("list", length(specs))
    cursor <- 0L
    for (i in seq_along(specs)) {
        n <- as.integer(specs[[i]]$n_params)
        segment <- if (n == 0L) 
            numeric(0)
        else free[cursor + seq_len(n)]
        rows[[i]] <- expand_step_constraint(segment, specs[[i]])
        cursor <- cursor + n
    }
    if (length(rows) == 0L) 
        return(matrix(numeric(0), nrow = 0L, ncol = 0L))
    out <- do.call(rbind, rows)
    rownames(out) <- names(specs)
    out
}

project_typed_step_gradient <- function(grad_step, config) {
    specs <- mfrmr_step_specs(config)
    grad_step <- if (identical(config$model, "RSM")) {
        matrix(as.numeric(grad_step), nrow = 1L)
    }
    else {
        as.matrix(grad_step)
    }
    if (!identical(dim(grad_step), c(length(specs), specs[[1]]$n_steps))) {
        stop("Expanded step gradient shape does not match model step ownership.", call. = FALSE)
    }
    if (!is.null(config$step_constraint_map)) {
        return(as.numeric(Matrix::crossprod(config$step_constraint_map$basis, as.vector(t(grad_step)))))
    }
    unlist(lapply(seq_along(specs), function(i) {
        project_step_constraint_gradient(grad_step[i, ], specs[[i]])
    }), use.names = FALSE)
}

build_gpcm_slope_spec <- function(levels, slope_facet, step_facet) {
    slope_levels <- as.character(levels %||% character(0))
    list(active = TRUE, slope_facet = as.character(slope_facet %||% NA_character_), step_facet = as.character(step_facet %||% 
        NA_character_), levels = slope_levels, n_params = max(length(slope_levels) - 1L, 0L), identification = "sum_to_zero_log_slopes", 
        scale_reference = "geometric_mean_one", reduction_reference = "PCM when all slopes equal 1")
}

expand_gpcm_log_slopes <- function(free, spec, include_slope_components = TRUE) {
    if (!is.null(spec$log_slope_design)) {
        if (length(free) != spec$n_params || any(!is.finite(free))) {
            stop("Product slopes require a finite vector with one entry per free coordinate.")
        }
        n <- lengths(spec$component_levels)
        component_log <- list(expand_facet(free[seq_len(n[1] - 1L)], n[1]), free[n[1] - 1L + seq_len(n[2])])
        components <- Map(function(x, labels) {
            if (!include_slope_components) 
                return(list(Slope = exp(as.numeric(x))))
            data.frame(Level = labels, LogSlope = as.numeric(x), Slope = exp(as.numeric(x)))
        }, component_log, spec$component_levels)
        names(components) <- names(spec$component_levels)
        loadNamespace("Matrix")
        log_slopes <- as.numeric(spec$log_slope_design %*% free)
        if (any(!is.finite(unlist(lapply(components, `[[`, "Slope")))) || any(unlist(lapply(components, 
            `[[`, "Slope")) <= 0)) {
            stop(new_gpcm_slope_numeric_boundary_error(unlist(component_log)))
        }
        return(list(log_slopes = log_slopes, slopes = exp(log_slopes), slope_components = if (include_slope_components) components else NULL))
    }
    n_levels <- length(spec$levels %||% character(0))
    if (n_levels == 0L) {
        return(list(log_slopes = numeric(0), slopes = numeric(0)))
    }
    log_slopes <- if ((spec$n_params %||% 0L) == 0L) {
        rep(0, n_levels)
    }
    else {
        expand_facet(as.numeric(free), n_levels)
    }
    list(log_slopes = log_slopes, slopes = exp(log_slopes))
}

new_gpcm_slope_numeric_boundary_error <- function(log_slopes) {
    log_slopes <- as.numeric(log_slopes %||% numeric(0))
    structure(list(message = paste("Expanded GPCM slopes must be finite and strictly positive after", 
        "log-scale identification."), call = NULL, expanded_log_slopes = log_slopes, expanded_slopes = suppressWarnings(exp(log_slopes))), 
        class = c("mfrmr_gpcm_slope_numeric_boundary_error", "error", "condition"))
}

new_population_variance_numeric_boundary_error <- function(log_sigma2) {
    structure(list(message = paste("Population-model residual variance `sigma2` must be a single positive", 
        "finite value after log-scale transformation."), call = NULL, log_sigma2 = as.numeric(log_sigma2), 
        sigma2 = exp(log_sigma2)), class = c("mfrmr_population_variance_numeric_boundary_error", "error", 
        "condition"))
}

project_sum_zero_gradient <- function(grad_expanded) {
    grad_expanded <- as.numeric(grad_expanded %||% numeric(0))
    n <- length(grad_expanded)
    if (n <= 1L) {
        return(numeric(0))
    }
    grad_expanded[seq_len(n - 1L)] - grad_expanded[n]
}

facet_interactions_active <- function(x) {
    specs <- if (is.list(x) && !is.null(x$interaction_specs)) {
        x$interaction_specs
    }
    else {
        x
    }
    specs <- specs %||% list()
    if (!is.list(specs) || length(specs) == 0L) 
        return(FALSE)
    any(vapply(specs, function(spec) {
        if (!is.list(spec) || is.null(spec$n_params)) return(FALSE)
        as.integer(spec$n_params %||% 0L) > 0L
    }, logical(1)))
}

normalize_facet_interactions <- function(facet_interactions, facet_names) {
    if (is.null(facet_interactions) || length(facet_interactions) == 0L) {
        return(list())
    }
    facet_names <- as.character(facet_names %||% character(0))
    terms <- if (is.character(facet_interactions)) {
        lapply(facet_interactions, function(term) {
            term <- trimws(as.character(term))
            if (is.na(term) || !nzchar(term)) {
                stop("`facet_interactions` cannot contain empty strings.", call. = FALSE)
            }
            parts <- trimws(strsplit(term, ":", fixed = TRUE)[[1]])
            if (length(parts) != 2L || any(!nzchar(parts))) {
                stop("`facet_interactions` must use explicit two-way terms such as ", "`\"Rater:Criterion\"`. Problem term: ", 
                  shQuote(term), ".", call. = FALSE)
            }
            parts
        })
    }
    else if (is.list(facet_interactions) && !is.data.frame(facet_interactions)) {
        lapply(facet_interactions, function(term) {
            parts <- trimws(as.character(term))
            parts <- parts[!is.na(parts) & nzchar(parts)]
            if (length(parts) != 2L) {
                stop("List entries in `facet_interactions` must each contain exactly ", "two facet names, for example `list(c(\"Rater\", \"Criterion\"))`.", 
                  call. = FALSE)
            }
            parts
        })
    }
    else {
        stop("`facet_interactions` must be NULL, a character vector of `A:B` terms, ", "or a list of length-two character vectors.", 
            call. = FALSE)
    }
    canonical <- character(length(terms))
    names_out <- character(length(terms))
    for (i in seq_along(terms)) {
        parts <- terms[[i]]
        if (any(parts == "Person")) {
            stop("`facet_interactions` currently supports only non-person facet pairs. ", "Remove `Person` from ", 
                shQuote(paste(parts, collapse = ":")), ".", call. = FALSE)
        }
        if (!all(parts %in% facet_names)) {
            missing <- setdiff(parts, facet_names)
            stop("`facet_interactions` references facet(s) not supplied in `facets`: ", paste(shQuote(missing), 
                collapse = ", "), ". Available non-person ", "facets are: ", paste(shQuote(facet_names), 
                collapse = ", "), ".", call. = FALSE)
        }
        if (length(unique(parts)) != 2L) {
            stop("`facet_interactions` terms must name two distinct facets. Problem term: ", shQuote(paste(parts, 
                collapse = ":")), ".", call. = FALSE)
        }
        canonical[i] <- paste(sort(parts), collapse = "\r")
        names_out[i] <- paste(parts, collapse = ":")
    }
    if (any(duplicated(canonical))) {
        dup <- names_out[duplicated(canonical)]
        stop("`facet_interactions` contains duplicate facet pairs: ", paste(shQuote(dup), collapse = ", "), 
            ". Each two-way pair may be ", "specified only once.", call. = FALSE)
    }
    names(terms) <- names_out
    terms
}

build_facet_interaction_specs <- function(prep, facet_interactions = NULL, min_obs_per_interaction = 10, 
    interaction_policy = c("warn", "error", "silent")) {
    interaction_policy <- match.arg(interaction_policy)
    if (!is.numeric(min_obs_per_interaction) || length(min_obs_per_interaction) != 1L || !is.finite(min_obs_per_interaction) || 
        min_obs_per_interaction < 0) {
        stop("`min_obs_per_interaction` must be a single non-negative finite number.", call. = FALSE)
    }
    min_obs_per_interaction <- as.numeric(min_obs_per_interaction)
    terms <- normalize_facet_interactions(facet_interactions, prep$facet_names)
    if (length(terms) == 0L) 
        return(list())
    specs <- lapply(names(terms), function(name) {
        facets <- terms[[name]]
        facet_a <- facets[1]
        facet_b <- facets[2]
        levels_a <- prep$levels[[facet_a]]
        levels_b <- prep$levels[[facet_b]]
        n_a <- length(levels_a)
        n_b <- length(levels_b)
        if (n_a < 2L || n_b < 2L) {
            stop("Facet interaction ", shQuote(name), " is not estimable because ", "both facets must have at least two observed levels.", 
                call. = FALSE)
        }
        a_idx <- as.integer(prep$data[[facet_a]])
        b_idx <- as.integer(prep$data[[facet_b]])
        cell_id <- a_idx + (b_idx - 1L) * n_a
        n_cells <- n_a * n_b
        cell_n <- matrix(tabulate(cell_id, nbins = n_cells), nrow = n_a, ncol = n_b)
        w <- suppressWarnings(as.numeric(prep$data$Weight))
        cell_weighted <- numeric(n_cells)
        weight_sum <- rowsum(matrix(w, ncol = 1), cell_id, reorder = FALSE)
        weight_ids <- as.integer(rownames(weight_sum))
        cell_weighted[weight_ids] <- as.vector(weight_sum)
        cell_weighted <- matrix(cell_weighted, nrow = n_a, ncol = n_b)
        sparse_cells <- cell_n < min_obs_per_interaction
        sparse_count <- sum(sparse_cells)
        zero_count <- sum(cell_n == 0L)
        if (sparse_count > 0L && !identical(interaction_policy, "silent")) {
            msg <- paste0("Facet interaction ", shQuote(name), " has ", sparse_count, " of ", n_cells, 
                " cells below `min_obs_per_interaction = ", min_obs_per_interaction, "` (", zero_count, 
                " zero-count cells). ", "Interaction estimates in sparse cells are weakly identified; ", 
                "use the term only when the pair is substantively justified.")
            if (identical(interaction_policy, "error")) {
                stop(msg, call. = FALSE)
            }
            warning(msg, call. = FALSE)
        }
        list(name = name, facets = facets, facet_a = facet_a, facet_b = facet_b, levels_a = levels_a, 
            levels_b = levels_b, n_a = n_a, n_b = n_b, n_cells = n_cells, n_params = (n_a - 1L) * (n_b - 
                1L), cell_n = cell_n, cell_weighted_n = cell_weighted, sparse_count = sparse_count, zero_count = zero_count, 
            min_obs_per_interaction = min_obs_per_interaction, identification = "two_way_sum_to_zero_margins", 
            interpretation = paste("Positive estimates indicate scores higher than expected under the", 
                "additive main-effects model for that facet-level combination."))
    })
    names(specs) <- names(terms)
    specs
}

expand_two_way_interaction <- function(free, spec) {
    n_a <- as.integer(spec$n_a %||% 0L)
    n_b <- as.integer(spec$n_b %||% 0L)
    mat <- matrix(0, nrow = n_a, ncol = n_b)
    if (n_a <= 1L || n_b <= 1L) 
        return(mat)
    free <- as.numeric(free %||% numeric(0))
    expected <- (n_a - 1L) * (n_b - 1L)
    if (length(free) != expected) {
        stop("Internal interaction parameter length mismatch for ", shQuote(spec$name %||% "interaction"), 
            ": expected ", expected, " free parameter(s), got ", length(free), ".", call. = FALSE)
    }
    core <- matrix(free, nrow = n_a - 1L, ncol = n_b - 1L)
    mat[seq_len(n_a - 1L), seq_len(n_b - 1L)] <- core
    mat[seq_len(n_a - 1L), n_b] <- -rowSums(core)
    mat[n_a, seq_len(n_b - 1L)] <- -colSums(core)
    mat[n_a, n_b] <- sum(core)
    dimnames(mat) <- list(spec$levels_a, spec$levels_b)
    mat
}

project_two_way_interaction_gradient <- function(grad_expanded, spec) {
    n_a <- as.integer(spec$n_a %||% nrow(grad_expanded))
    n_b <- as.integer(spec$n_b %||% ncol(grad_expanded))
    if (n_a <= 1L || n_b <= 1L) 
        return(numeric(0))
    grad_expanded <- matrix(as.numeric(grad_expanded), nrow = n_a, ncol = n_b)
    core <- grad_expanded[seq_len(n_a - 1L), seq_len(n_b - 1L), drop = FALSE]
    last_col <- grad_expanded[seq_len(n_a - 1L), n_b]
    last_row <- grad_expanded[n_a, seq_len(n_b - 1L)]
    corner <- grad_expanded[n_a, n_b]
    projected <- core - matrix(last_col, nrow = n_a - 1L, ncol = n_b - 1L) - matrix(last_row, nrow = n_a - 
        1L, ncol = n_b - 1L, byrow = TRUE) + corner
    as.vector(projected)
}

expand_interaction_params <- function(free, specs) {
    specs <- specs %||% list()
    if (length(specs) == 0L) 
        return(list())
    out <- vector("list", length(specs))
    names(out) <- names(specs)
    pos <- 1L
    for (nm in names(specs)) {
        spec <- specs[[nm]]
        k <- as.integer(spec$n_params %||% 0L)
        seg <- if (k > 0L) {
            free[pos:(pos + k - 1L)]
        }
        else {
            numeric(0)
        }
        out[[nm]] <- expand_two_way_interaction(seg, spec)
        pos <- pos + k
    }
    out
}

compute_interaction_eta <- function(idx, params, config) {
    specs <- config$interaction_specs %||% list()
    if (length(specs) == 0L) 
        return(rep(0, length(idx$score_k)))
    interactions <- params$interactions %||% list()
    eta <- rep(0, length(idx$score_k))
    for (nm in names(specs)) {
        mat <- interactions[[nm]]
        cell_id <- idx$interactions[[nm]]
        if (is.null(mat) || is.null(cell_id)) 
            next
        eta <- eta + as.vector(mat)[cell_id]
    }
    eta
}

compute_interaction_gradient_free <- function(residual, idx, config) {
    specs <- config$interaction_specs %||% list()
    if (length(specs) == 0L) 
        return(numeric(0))
    residual <- as.numeric(residual)
    out <- lapply(names(specs), function(nm) {
        spec <- specs[[nm]]
        k <- as.integer(spec$n_params %||% 0L)
        if (k == 0L) 
            return(numeric(0))
        cell_id <- idx$interactions[[nm]]
        if (is.null(cell_id)) {
            stop("Internal interaction index not found for ", shQuote(nm), ".", call. = FALSE)
        }
        if (isTRUE(getOption("mfrmr.use_cpp11_backend", TRUE)) && mfrm_cpp11_backend_available()) {
            grad_vec <- mfrm_cpp_indexed_sum(residual, as.integer(cell_id), as.integer(spec$n_cells), 
                1)
        }
        else {
            grad_vec <- numeric(spec$n_cells)
            rs <- rowsum(matrix(residual, ncol = 1), cell_id, reorder = FALSE)
            ids <- as.integer(rownames(rs))
            grad_vec[ids] <- as.vector(rs)
        }
        grad_mat <- matrix(grad_vec, nrow = spec$n_a, ncol = spec$n_b)
        project_two_way_interaction_gradient(grad_mat, spec)
    })
    unlist(out, use.names = FALSE)
}

build_interaction_effect_table <- function(config, prep, params) {
    specs <- config$interaction_specs %||% list()
    if (length(specs) == 0L) 
        return(tibble())
    interactions <- params$interactions %||% list()
    tbls <- lapply(names(specs), function(nm) {
        spec <- specs[[nm]]
        mat <- interactions[[nm]]
        if (is.null(mat)) {
            mat <- matrix(0, nrow = spec$n_a, ncol = spec$n_b)
        }
        grid <- expand.grid(FacetA_Level = spec$levels_a, FacetB_Level = spec$levels_b, KEEP.OUT.ATTRS = FALSE, 
            stringsAsFactors = FALSE)
        tibble(Interaction = spec$name, FacetA = spec$facet_a, FacetA_Level = as.character(grid$FacetA_Level), 
            FacetB = spec$facet_b, FacetB_Level = as.character(grid$FacetB_Level), Estimate = as.vector(mat), 
            N = as.integer(as.vector(spec$cell_n)), WeightedN = as.numeric(as.vector(spec$cell_weighted_n)), 
            Sparse = as.vector(spec$cell_n) < spec$min_obs_per_interaction, Identification = spec$identification)
    })
    bind_rows(tbls)
}

build_facet_constraint <- function(levels, anchors = NULL, groups = NULL, group_values = NULL, centered = TRUE, 
    centering_scope = c("remainder", "facet")) {
    centering_scope <- match.arg(centering_scope)
    lvl <- as.character(levels)
    anchors_vec <- rep(NA_real_, length(lvl))
    names(anchors_vec) <- lvl
    if (!is.null(anchors)) {
        anchors <- anchors[!is.na(names(anchors))]
        anchors_vec[names(anchors)] <- as.numeric(anchors)
    }
    groups_vec <- rep(NA_character_, length(lvl))
    names(groups_vec) <- lvl
    if (!is.null(groups)) {
        groups <- groups[!is.na(names(groups))]
        groups_vec[names(groups)] <- as.character(groups)
    }
    group_values_map <- numeric(0)
    if (!is.null(group_values)) {
        group_values <- group_values[!is.na(names(group_values))]
        group_values_map <- as.numeric(group_values)
        names(group_values_map) <- names(group_values)
    }
    spec <- list(levels = lvl, anchors = anchors_vec, groups = groups_vec, group_values = group_values_map, 
        centered = centered)
    if (identical(centering_scope, "facet")) {
        spec$centering_scope <- "facet"
        spec$groups[!is.na(spec$groups) & !nzchar(spec$groups)] <- NA_character_
        grouped <- !is.na(spec$groups)
        fixed_total <- sum(spec$anchors[!grouped], na.rm = TRUE)
        fixed_magnitude <- sum(abs(spec$anchors[!grouped]), na.rm = TRUE)
        for (gid in unique(spec$groups[grouped])) {
            members <- which(spec$groups == gid)
            value <- if (gid %in% names(spec$group_values)) 
                spec$group_values[[gid]]
            else 0
            if (length(value) != 1L || !is.finite(value)) {
                stop("A group-mean constraint requires a finite target.", call. = FALSE)
            }
            spec$group_values[gid] <- value
            target <- value * length(members)
            if (all(is.finite(spec$anchors[members]))) {
                residual <- sum(spec$anchors[members]) - target
                scale <- max(1, abs(target), sum(abs(spec$anchors[members])))
                if (abs(residual) > 1e-12 * scale) {
                  stop("Fixed anchors conflict with the mean of group '", gid, "'.", call. = FALSE)
                }
            }
            fixed_total <- fixed_total + target
            fixed_magnitude <- fixed_magnitude + abs(target)
        }
        spec$remainder_sum <- if (isTRUE(centered)) 
            -fixed_total
        else 0
        remaining <- which(is.na(spec$anchors) & !grouped)
        if (isTRUE(centered) && !length(remaining) && abs(fixed_total) > 1e-12 * max(1, fixed_magnitude)) {
            stop("Fixed anchors and group means conflict with whole-facet centering. ", "Revise the declared constraints or the facet's centering choice.", 
                call. = FALSE)
        }
    }
    spec$n_params <- count_facet_params(spec)
    spec
}

count_facet_params <- function(spec) {
    anchors <- spec$anchors
    groups <- spec$groups
    free_idx <- which(is.na(anchors))
    if (length(free_idx) == 0) 
        return(0)
    n_params <- 0
    group_ids <- unique(na.omit(groups[free_idx]))
    if (length(group_ids) > 0) {
        for (gid in group_ids) {
            group_levels <- which(groups == gid)
            free_in_group <- group_levels[is.na(anchors[group_levels])]
            k <- length(free_in_group)
            if (k > 1) 
                n_params <- n_params + (k - 1)
        }
    }
    ungrouped_idx <- free_idx[is.na(groups[free_idx]) | groups[free_idx] == ""]
    m <- length(ungrouped_idx)
    if (m == 0) 
        return(n_params)
    if (spec$centered) {
        n_params <- n_params + max(m - 1, 0)
    }
    else {
        n_params <- n_params + m
    }
    n_params
}

expand_facet_with_constraints <- function(free, spec) {
    out <- spec$anchors
    groups <- spec$groups
    group_values <- spec$group_values
    centered <- isTRUE(spec$centered)
    free_idx <- which(is.na(out))
    if (length(free_idx) == 0) 
        return(out)
    used <- 0
    group_ids <- unique(na.omit(groups[free_idx]))
    if (length(group_ids) > 0) {
        for (gid in group_ids) {
            group_levels <- which(groups == gid)
            free_in_group <- group_levels[is.na(out[group_levels])]
            if (length(free_in_group) == 0) 
                next
            group_value <- if (gid %in% names(group_values)) 
                group_values[[gid]]
            else 0
            anchor_sum <- sum(out[group_levels], na.rm = TRUE)
            target_sum <- group_value * length(group_levels)
            k <- length(free_in_group)
            if (k == 1) {
                out[free_in_group] <- target_sum - anchor_sum
            }
            else {
                seg <- free[(used + 1):(used + k - 1)]
                used <- used + (k - 1)
                last_val <- target_sum - anchor_sum - sum(seg)
                out[free_in_group] <- c(seg, last_val)
            }
        }
    }
    ungrouped_idx <- free_idx[is.na(groups[free_idx]) | groups[free_idx] == ""]
    m <- length(ungrouped_idx)
    if (m == 0) 
        return(out)
    if (centered) {
        target <- spec$remainder_sum %||% 0
        if (m == 1) {
            out[ungrouped_idx] <- target
        }
        else {
            seg <- free[(used + 1):(used + m - 1)]
            used <- used + (m - 1)
            out[ungrouped_idx] <- c(seg, target - sum(seg))
        }
    }
    else {
        seg <- free[(used + 1):(used + m)]
        used <- used + m
        out[ungrouped_idx] <- seg
    }
    out
}

constraint_grad_project <- function(grad_expanded, spec) {
    anchors <- spec$anchors
    groups <- spec$groups
    centered <- isTRUE(spec$centered)
    free_idx <- which(is.na(anchors))
    if (length(free_idx) == 0 || spec$n_params == 0) 
        return(numeric(0))
    grad_free <- numeric(spec$n_params)
    pos <- 1L
    group_ids <- unique(na.omit(groups[free_idx]))
    if (length(group_ids) > 0) {
        for (gid in group_ids) {
            group_levels <- which(groups == gid)
            free_in_group <- group_levels[is.na(anchors[group_levels])]
            k <- length(free_in_group)
            if (k <= 1) 
                next
            last_g <- grad_expanded[free_in_group[k]]
            for (j in seq_len(k - 1)) {
                grad_free[pos] <- grad_expanded[free_in_group[j]] - last_g
                pos <- pos + 1L
            }
        }
    }
    ungrouped_idx <- free_idx[is.na(groups[free_idx]) | groups[free_idx] == ""]
    m <- length(ungrouped_idx)
    if (m > 0) {
        if (centered) {
            if (m >= 2) {
                last_g <- grad_expanded[ungrouped_idx[m]]
                for (j in seq_len(m - 1)) {
                  grad_free[pos] <- grad_expanded[ungrouped_idx[j]] - last_g
                  pos <- pos + 1L
                }
            }
        }
        else {
            for (j in seq_len(m)) {
                grad_free[pos] <- grad_expanded[ungrouped_idx[j]]
                pos <- pos + 1L
            }
        }
    }
    grad_free
}

collapse_facet_with_constraints <- function(expanded, spec, tolerance = 1e-12) {
    expanded <- as.numeric(expanded %||% numeric(0))
    if (length(expanded) != length(spec$levels) || any(!is.finite(expanded))) {
        stop("Expanded facet coordinates do not match the constraint specification.", call. = FALSE)
    }
    fixed <- which(is.finite(spec$anchors))
    if (length(fixed) > 0L && any(abs(expanded[fixed] - spec$anchors[fixed]) > tolerance)) {
        stop("Expanded facet coordinates violate a fixed anchor.", call. = FALSE)
    }
    if (identical(spec$centering_scope, "facet") && isTRUE(spec$centered) && abs(sum(expanded)) > tolerance * 
        max(1, sum(abs(expanded)))) {
        stop("Expanded facet coordinates violate whole-facet centering.", call. = FALSE)
    }
    free <- numeric(0)
    free_index <- which(is.na(spec$anchors))
    groups <- as.character(spec$groups)
    for (group_id in unique(stats::na.omit(groups[free_index]))) {
        if (!nzchar(group_id)) 
            next
        members <- which(groups == group_id)
        target <- spec$group_values[[group_id]] * length(members)
        if (abs(sum(expanded[members]) - target) > tolerance) {
            stop("Expanded facet coordinates violate a group-mean constraint.", call. = FALSE)
        }
        free_members <- members[is.na(spec$anchors[members])]
        if (length(free_members) > 1L) {
            free <- c(free, expanded[free_members[-length(free_members)]])
        }
    }
    ungrouped <- free_index[is.na(groups[free_index]) | !nzchar(groups[free_index])]
    if (length(ungrouped) > 0L) {
        if (isTRUE(spec$centered)) {
            if (abs(sum(expanded[ungrouped]) - (spec$remainder_sum %||% 0)) > tolerance) {
                stop("Expanded facet coordinates violate the active sum constraint.", call. = FALSE)
            }
            if (length(ungrouped) > 1L) {
                free <- c(free, expanded[ungrouped[-length(ungrouped)]])
            }
        }
        else {
            free <- c(free, expanded[ungrouped])
        }
    }
    if (length(free) != as.integer(spec$n_params)) {
        stop("Internal facet collapse dimension mismatch.", call. = FALSE)
    }
    free
}

collapse_step_constraint <- function(expanded, spec, tolerance = 1e-12) {
    expanded <- as.numeric(expanded %||% numeric(0))
    if (length(expanded) != as.integer(spec$n_steps) || any(!is.finite(expanded))) {
        stop("Expanded step coordinates do not match the typed constraint.", call. = FALSE)
    }
    fixed <- which(is.finite(spec$anchors))
    if (length(fixed) > 0L && any(abs(expanded[fixed] - spec$anchors[fixed]) > tolerance)) {
        stop("Expanded step coordinates violate a fixed anchor.", call. = FALSE)
    }
    if (abs(sum(expanded) - spec$target) > tolerance) {
        stop("Expanded step coordinates violate the declared sum constraint.", call. = FALSE)
    }
    free_index <- as.integer(spec$free_index)
    if (length(free_index) <= 1L) 
        numeric(0)
    else {
        expanded[free_index[-length(free_index)]]
    }
}

build_param_sizes <- function(config) {
    stop_if_jml_adjustment(list(config = config), "Ordinary likelihood parameter calculations")
    mfrm_validate_facet_names(config$facet_names)
    n_steps <- max(config$n_cat - 1, 0)
    sizes <- list(theta = if (config$method == "JML") config$theta_spec$n_params else 0)
    for (facet in config$facet_names) {
        sizes[[facet]] <- config$facet_specs[[facet]]$n_params
    }
    interaction_n <- sum(vapply(config$interaction_specs %||% list(), function(spec) {
        as.integer(spec$n_params %||% 0L)
    }, integer(1)))
    if (interaction_n > 0L) {
        sizes$interactions <- interaction_n
    }
    if (config$model != "RSM") {
        if (is.null(config$step_facet) || !config$step_facet %in% config$facet_names) {
            stop("PCM model requires 'step_facet' to name one of the facet columns: ", paste(config$facet_names, 
                collapse = ", "), ". ", "Supply step_facet = '<name>'.", call. = FALSE)
        }
    }
    step_specs <- mfrmr_step_specs(config)
    if (!is.null(config$step_constraint_map) && !isNamespaceLoaded("Matrix")) 
        loadNamespace("Matrix")
    sizes$steps <- ncol(config$step_constraint_map$basis) %||% sum(vapply(step_specs, function(spec) {
        as.integer(spec$n_params)
    }, integer(1)))
    if (identical(config$model, "GPCM")) {
        gpcm_spec <- config$gpcm_spec %||% list()
        sizes$log_slopes <- as.integer(gpcm_spec$n_params %||% 0L)
    }
    if (identical(config$method, "MML") && isTRUE(config$population_spec$active)) {
        design_matrix <- config$population_spec$design_matrix
        if (is.null(design_matrix) || !is.matrix(design_matrix)) {
            stop("Active latent-regression MML requires a numeric person-level design matrix.", call. = FALSE)
        }
        sizes$beta <- ncol(design_matrix)
        sizes$log_sigma2 <- if (is.null(config$population_spec$fixed_sd)) 
            1L
        else 0L
    }
    sizes
}

split_params <- function(par, sizes) {
    if (length(par) != sum(unlist(sizes, use.names = FALSE))) {
        stop("Parameter vector length does not match the model's free-coordinate blocks.", call. = FALSE)
    }
    out <- list()
    idx <- 1
    for (nm in names(sizes)) {
        k <- sizes[[nm]]
        if (k == 0) {
            out[[nm]] <- numeric(0)
        }
        else {
            out[[nm]] <- par[idx:(idx + k - 1)]
            idx <- idx + k
        }
    }
    out
}

expand_params <- function(par, sizes, config, include_slope_components = TRUE) {
    stop_if_jml_adjustment(list(config = config), "Ordinary likelihood parameter calculations")
    parts <- split_params(par, sizes)
    theta <- if (config$method == "JML") {
        expand_facet_with_constraints(parts$theta, config$theta_spec)
    }
    else {
        numeric(0)
    }
    facets <- lapply(config$facet_names, function(facet) {
        expand_facet_with_constraints(parts[[facet]], config$facet_specs[[facet]])
    })
    names(facets) <- config$facet_names
    interactions <- expand_interaction_params(free = parts[["interactions"]] %||% numeric(0), specs = config$interaction_specs %||% 
        list())
    step_specs <- mfrmr_step_specs(config)
    step_map <- config$step_constraint_map
    if (!is.null(step_map)) {
        expanded <- step_map$offset + as.numeric(step_map$basis %*% parts$steps)
        steps <- if (config$model == "RSM") 
            expanded
        else NULL
        steps_mat <- if (config$model != "RSM") 
            matrix(expanded, byrow = TRUE, nrow = length(step_specs), dimnames = list(names(step_specs), 
                NULL))
        else NULL
    }
    else if (config$model == "RSM") {
        steps <- expand_step_constraint(parts$steps, step_specs[[1]])
        steps_mat <- NULL
    }
    else {
        n_levels <- length(config$facet_levels[[config$step_facet]])
        if (n_levels == 0 || config$n_cat <= 1) {
            steps_mat <- matrix(0, nrow = n_levels, ncol = max(config$n_cat - 1, 0))
        }
        else {
            steps_mat <- expand_step_constraints(parts$steps, step_specs)
        }
        steps <- NULL
    }
    log_slopes <- NULL
    slopes <- NULL
    if (identical(config$model, "GPCM")) {
        gpcm_expanded <- expand_gpcm_log_slopes(parts[["log_slopes"]], config$gpcm_spec %||% list(), 
            include_slope_components = include_slope_components)
        log_slopes <- gpcm_expanded$log_slopes
        slopes <- gpcm_expanded$slopes
        if (!all(is.finite(slopes)) || any(slopes <= 0)) {
            stop(new_gpcm_slope_numeric_boundary_error(log_slopes))
        }
    }
    population <- NULL
    if (identical(config$method, "MML") && isTRUE(config$population_spec$active)) {
        beta <- as.numeric(parts[["beta"]])
        beta_names <- config$population_spec$design_columns %||% colnames(config$population_spec$design_matrix) %||% 
            paste0("beta_", seq_along(beta))
        names(beta) <- beta_names
        fixed_sd <- config$population_spec$fixed_sd
        log_sigma2 <- if (is.null(fixed_sd)) {
            as.numeric(parts[["log_sigma2"]][1])
        }
        else {
            2 * log(fixed_sd)
        }
        sigma2 <- if (is.null(fixed_sd)) 
            exp(log_sigma2)
        else fixed_sd^2
        if (!is.finite(sigma2) || sigma2 <= 0) {
            stop(new_population_variance_numeric_boundary_error(log_sigma2))
        }
        population <- list(coefficients = beta, log_sigma2 = log_sigma2, sigma2 = sigma2)
    }
    out <- list(theta = theta, facets = facets, interactions = interactions, steps = steps, steps_mat = steps_mat, 
        log_slopes = log_slopes, slopes = slopes, population = population)
    if (identical(config$model, "GPCM") && !is.null(gpcm_expanded$slope_components)) {
        out$slope_components <- gpcm_expanded$slope_components
    }
    out
}

collapse_expanded_params <- function(params, config) {
    blocks <- list()
    if (identical(config$method, "JML")) {
        blocks$theta <- collapse_facet_with_constraints(params$theta, config$theta_spec)
    }
    else {
        blocks$theta <- numeric(0)
    }
    for (facet in config$facet_names) {
        blocks[[facet]] <- collapse_facet_with_constraints(params$facets[[facet]], config$facet_specs[[facet]])
    }
    if (facet_interactions_active(config)) {
        blocks$interactions <- unlist(lapply(names(config$interaction_specs), function(name) {
            spec <- config$interaction_specs[[name]]
            matrix_value <- params$interactions[[name]]
            if (spec$n_a <= 1L || spec$n_b <= 1L) 
                return(numeric(0))
            as.vector(matrix_value[seq_len(spec$n_a - 1L), seq_len(spec$n_b - 1L), drop = FALSE])
        }), use.names = FALSE)
    }
    step_specs <- mfrmr_step_specs(config)
    step_map <- config$step_constraint_map
    blocks$steps <- if (!is.null(step_map)) {
        steps <- if (identical(config$model, "RSM")) 
            params$steps
        else as.vector(t(params$steps_mat))
        free <- steps[step_map$free]
        expanded <- step_map$offset + as.numeric(step_map$basis %*% free)
        if (length(steps) != length(expanded) || any(!is.finite(steps)) || any(abs(steps - expanded) > 
            1e-12 * pmax(1, abs(expanded)))) {
            stop("Expanded steps do not satisfy the fitted step constraints.", call. = FALSE)
        }
        free
    }
    else if (identical(config$model, "RSM")) {
        collapse_step_constraint(params$steps, step_specs[[1]])
    }
    else {
        unlist(lapply(seq_along(step_specs), function(i) {
            collapse_step_constraint(params$steps_mat[i, ], step_specs[[i]])
        }), use.names = FALSE)
    }
    if (identical(config$model, "GPCM")) {
        blocks$log_slopes <- collapse_gpcm_log_slopes(params$log_slopes, config$gpcm_spec)
    }
    if (identical(config$method, "MML") && isTRUE(config$population_spec$active)) {
        blocks$beta <- as.numeric(params$population$coefficients)
        blocks$log_sigma2 <- if (is.null(config$population_spec$fixed_sd)) {
            as.numeric(params$population$log_sigma2)
        }
        else numeric(0)
    }
    sizes <- build_param_sizes(config)
    out <- unlist(blocks[names(sizes)], use.names = FALSE)
    if (length(out) != sum(unlist(sizes, use.names = FALSE))) {
        stop("Internal expanded-parameter collapse dimension mismatch.", call. = FALSE)
    }
    out
}

compute_base_eta <- function(idx, params, config) {
    eta <- rep(0, length(idx$score_k))
    facet_signs <- config$facet_signs
    for (facet in config$facet_names) {
        sign <- if (!is.null(facet_signs) && !is.null(facet_signs[[facet]])) {
            facet_signs[[facet]]
        }
        else {
            -1
        }
        eta <- eta + sign * params$facets[[facet]][idx$facets[[facet]]]
    }
    eta <- eta + compute_interaction_eta(idx, params, config)
    eta
}

compute_eta <- function(idx, params, config, theta_override = NULL) {
    theta <- if (!is.null(theta_override)) 
        theta_override
    else params$theta
    eta <- if (length(theta) == 0) {
        rep(0, length(idx$score_k))
    }
    else {
        theta[idx$person]
    }
    eta + compute_base_eta(idx, params, config)
}

mfrm_jml_eval_cpp11_stats <- function(idx, config, params, eta, step_cum = NULL, include_grad = FALSE) {
    model_code <- mfrm_model_code(config$model)
    if (is.null(step_cum)) {
        step_cum <- if (model_code == 0L) {
            c(0, cumsum(params$steps))
        }
        else {
            mfrm_step_cum_matrix(params$steps_mat)
        }
    }
    step_cum_rsm <- if (model_code == 0L) 
        as.double(step_cum)
    else numeric(0)
    step_cum_mat <- if (model_code == 0L) 
        matrix(0, 0L, 0L)
    else as.matrix(step_cum)
    if (model_code != 0L && !is.double(step_cum_mat)) 
        storage.mode(step_cum_mat) <- "double"
    step_idx <- if (model_code == 0L) 
        integer(0)
    else as.integer(idx$step_idx)
    slopes <- if (model_code == 2L) 
        as.double(params$slopes)
    else numeric(0)
    slope_idx <- if (model_code == 2L) 
        as.integer(idx$slope_idx)
    else integer(0)
    mfrm_cpp_jml_eval_bundle(model_code = model_code, score_k = as.integer(idx$score_k), person_int = as.integer(idx$person), 
        n_theta = as.integer(length(params$theta)), eta = as.double(eta), step_cum_rsm = step_cum_rsm, 
        step_cum_mat = step_cum_mat, step_idx = step_idx, slopes = slopes, slope_idx = slope_idx, weight = idx$weight %||% 
            NULL, include_grad = isTRUE(include_grad))
}

mfrm_jml_grad_from_stats <- function(stats, params, idx, config) {
    residual <- stats$residual
    grad_facets_exp <- list()
    for (facet in config$facet_names) {
        sign_f <- if (!is.null(config$facet_signs[[facet]])) 
            config$facet_signs[[facet]]
        else -1
        n_lev <- length(params$facets[[facet]])
        grad_facets_exp[[facet]] <- mfrm_cpp_indexed_sum(residual, as.integer(idx$facets[[facet]]), as.integer(n_lev), 
            as.double(sign_f))
    }
    grad_interaction_free <- compute_interaction_gradient_free(residual, idx, config)
    grad_step_free <- project_typed_step_gradient(stats$grad_step_mat, config)
    grad_log_slope_free <- if (identical(config$model, "GPCM")) {
        project_gpcm_log_slope_gradient(stats$grad_log_slope_exp, config$gpcm_spec)
    }
    else {
        numeric(0)
    }
    grad_theta_free <- constraint_grad_project(stats$grad_theta_exp, config$theta_spec)
    grad_facet_free <- unlist(lapply(config$facet_names, function(f) {
        constraint_grad_project(grad_facets_exp[[f]], config$facet_specs[[f]])
    }))
    -c(grad_theta_free, grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free)
}

mfrm_loglik_jml <- function(par, idx, config, sizes) {
    params <- expand_params(par, sizes, config)
    eta <- compute_eta(idx, params, config)
    if (mfrm_use_cpp11_backend(config)) {
        return(mfrm_jml_eval_cpp11_stats(idx, config, params, eta, include_grad = FALSE)$value)
    }
    if (config$model == "RSM") {
        step_cum <- c(0, cumsum(params$steps))
        ll <- loglik_rsm(eta, idx$score_k, step_cum, weight = idx$weight)
    }
    else if (identical(config$model, "GPCM")) {
        step_cum_mat <- t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
        ll <- loglik_gpcm(eta = eta, score_k = idx$score_k, step_cum_mat = step_cum_mat, criterion_idx = idx$step_idx, 
            slopes = params$slopes, slope_idx = idx$slope_idx, weight = idx$weight)
    }
    else {
        step_cum_mat <- t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
        ll <- loglik_pcm(eta, idx$score_k, step_cum_mat, idx$step_idx, weight = idx$weight, criterion_splits = idx$criterion_splits)
    }
    -ll
}

mfrm_loglik_jml_cached <- function(cache, idx, config) {
    eta <- cache$eta()
    step_cum <- cache$step_cum()
    if (mfrm_use_cpp11_backend(config)) {
        return(mfrm_jml_eval_cpp11_stats(idx, config, cache$params(), eta, step_cum = step_cum, include_grad = FALSE)$value)
    }
    if (config$model == "RSM") {
        ll <- loglik_rsm(eta, idx$score_k, step_cum, weight = idx$weight)
    }
    else if (identical(config$model, "GPCM")) {
        ll <- loglik_gpcm(eta = eta, score_k = idx$score_k, step_cum_mat = step_cum, criterion_idx = idx$step_idx, 
            slopes = cache$params()$slopes, slope_idx = idx$slope_idx, weight = idx$weight)
    }
    else {
        ll <- loglik_pcm(eta, idx$score_k, step_cum, idx$step_idx, weight = idx$weight, criterion_splits = idx$criterion_splits)
    }
    -ll
}

mfrm_mml_logprob_bundle_r <- function(idx, config, quad, params, base_eta, step_cum = NULL, include_probs = FALSE, 
    include_linear_part = FALSE) {
    n <- length(idx$score_k)
    score_k <- idx$score_k
    person_int <- idx$person
    n_nodes <- length(quad$nodes)
    obs_idx <- cbind(seq_len(n), score_k + 1L)
    prob_list <- if (isTRUE(include_probs)) 
        vector("list", n_nodes)
    else NULL
    linear_part_list <- if (isTRUE(include_linear_part)) 
        vector("list", n_nodes)
    else NULL
    if (is.null(step_cum)) {
        if (config$model == "RSM") {
            step_cum <- c(0, cumsum(params$steps))
        }
        else {
            step_cum <- t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
        }
    }
    quad_basis <- resolve_person_quadrature_basis(quad = quad, population_spec = materialize_population_spec(config, 
        params), person_count = config$n_person)
    person_nodes <- quad_basis$nodes
    if (config$model == "RSM") {
        k_cat <- length(step_cum)
        step_cum_row <- matrix(step_cum, nrow = n, ncol = k_cat, byrow = TRUE)
        log_prob_mat <- matrix(0, n, n_nodes)
        for (q in seq_len(n_nodes)) {
            eta_q <- base_eta + person_nodes[person_int, q]
            eta_mat <- outer(eta_q, 0:(k_cat - 1))
            log_num <- eta_mat - step_cum_row
            row_max <- log_num[cbind(seq_len(n), max.col(log_num, ties.method = "first"))]
            log_num <- log_num - row_max
            log_denom <- log(rowSums(exp(log_num)))
            lp <- log_num[obs_idx] - log_denom
            if (!is.null(idx$weight)) 
                lp <- lp * idx$weight
            log_prob_mat[, q] <- lp
            if (isTRUE(include_probs)) {
                log_denom_mat <- matrix(log_denom, nrow = n, ncol = k_cat)
                prob_list[[q]] <- exp(log_num - log_denom_mat)
            }
        }
    }
    else if (identical(config$model, "GPCM")) {
        k_cat <- ncol(step_cum)
        crit <- idx$step_idx
        slope_idx <- idx$slope_idx
        step_cum_obs <- step_cum[crit, , drop = FALSE]
        slope_obs <- matrix(params$slopes[slope_idx], nrow = n, ncol = k_cat)
        k_vals <- 0:(k_cat - 1)
        log_prob_mat <- matrix(0, n, n_nodes)
        for (q in seq_len(n_nodes)) {
            eta_q <- base_eta + person_nodes[person_int, q]
            linear_part <- outer(eta_q, k_vals) - step_cum_obs
            log_num <- linear_part * slope_obs
            row_max <- log_num[cbind(seq_len(n), max.col(log_num, ties.method = "first"))]
            log_num <- log_num - row_max
            log_denom <- log(rowSums(exp(log_num)))
            lp <- log_num[obs_idx] - log_denom
            if (!is.null(idx$weight)) 
                lp <- lp * idx$weight
            log_prob_mat[, q] <- lp
            if (isTRUE(include_probs)) {
                log_denom_mat <- matrix(log_denom, nrow = n, ncol = k_cat)
                prob_list[[q]] <- exp(log_num - log_denom_mat)
            }
            if (isTRUE(include_linear_part)) {
                linear_part_list[[q]] <- linear_part
            }
        }
    }
    else {
        k_cat <- ncol(step_cum)
        step_cum_obs <- step_cum[idx$step_idx, , drop = FALSE]
        k_vals <- 0:(k_cat - 1)
        log_prob_mat <- matrix(0, n, n_nodes)
        for (q in seq_len(n_nodes)) {
            eta_q <- base_eta + person_nodes[person_int, q]
            log_num <- outer(eta_q, k_vals) - step_cum_obs
            row_max <- log_num[cbind(seq_len(n), max.col(log_num, ties.method = "first"))]
            log_num <- log_num - row_max
            log_denom <- log(rowSums(exp(log_num)))
            lp <- log_num[obs_idx] - log_denom
            if (!is.null(idx$weight)) 
                lp <- lp * idx$weight
            log_prob_mat[, q] <- lp
            if (isTRUE(include_probs)) {
                log_denom_mat <- matrix(log_denom, nrow = n, ncol = k_cat)
                prob_list[[q]] <- exp(log_num - log_denom_mat)
            }
        }
    }
    out <- list(log_prob_mat = log_prob_mat, quad_basis = quad_basis, person_int = person_int)
    if (isTRUE(include_probs)) {
        out$prob_list <- prob_list
    }
    if (isTRUE(include_linear_part)) {
        out$linear_part_list <- linear_part_list
    }
    out
}

mfrm_mml_logprob_bundle_cpp11 <- function(idx, config, quad, params, base_eta, step_cum = NULL, include_probs = FALSE, 
    include_linear_part = FALSE) {
    person_int <- idx$person
    if (is.null(step_cum)) {
        if (config$model == "RSM") {
            step_cum <- c(0, cumsum(params$steps))
        }
        else {
            step_cum <- mfrm_step_cum_matrix(params$steps_mat)
        }
    }
    quad_basis <- resolve_person_quadrature_basis(quad = quad, population_spec = materialize_population_spec(config, 
        params), person_count = config$n_person)
    person_nodes <- quad_basis$nodes
    weight <- idx$weight %||% NULL
    compiled <- if (config$model == "RSM") {
        mfrm_cpp_rsm_logprob_bundle(score_k = as.integer(idx$score_k), person_int = as.integer(person_int), 
            base_eta = as.numeric(base_eta), person_nodes = as.matrix(person_nodes), step_cum = as.numeric(step_cum), 
            weight = weight, include_probs = isTRUE(include_probs))
    }
    else if (identical(config$model, "GPCM")) {
        step_cum_obs <- step_cum[idx$step_idx, , drop = FALSE]
        slope_obs <- params$slopes[idx$slope_idx]
        mfrm_cpp_gpcm_logprob_bundle(score_k = as.integer(idx$score_k), person_int = as.integer(person_int), 
            base_eta = as.numeric(base_eta), person_nodes = as.matrix(person_nodes), step_cum_obs = as.matrix(step_cum_obs), 
            slope_obs = as.numeric(slope_obs), weight = weight, include_probs = isTRUE(include_probs), 
            include_linear_part = isTRUE(include_linear_part))
    }
    else {
        step_cum_obs <- step_cum[idx$step_idx, , drop = FALSE]
        mfrm_cpp_pcm_logprob_bundle(score_k = as.integer(idx$score_k), person_int = as.integer(person_int), 
            base_eta = as.numeric(base_eta), person_nodes = as.matrix(person_nodes), step_cum_obs = as.matrix(step_cum_obs), 
            weight = weight, include_probs = isTRUE(include_probs))
    }
    out <- list(log_prob_mat = compiled$log_prob_mat, quad_basis = quad_basis, person_int = person_int)
    if (isTRUE(include_probs)) {
        out$prob_list <- compiled$prob_list
    }
    if (isTRUE(include_linear_part)) {
        out$linear_part_list <- if (identical(config$model, "GPCM")) {
            compiled$linear_part_list
        }
        else {
            vector("list", ncol(person_nodes))
        }
    }
    out
}

mfrm_mml_logprob_bundle <- function(idx, config, quad, params, base_eta, step_cum = NULL, include_probs = FALSE, 
    include_linear_part = FALSE) {
    if (mfrmr_adaptive_integration(config)) {
        quad$person_basis <- mfrmr_adaptive_quadrature_basis(idx, config, params, quad, base_eta)
    }
    if (mfrm_use_cpp11_backend(config, include_linear_part = include_linear_part)) {
        return(mfrm_mml_logprob_bundle_cpp11(idx = idx, config = config, quad = quad, params = params, 
            base_eta = base_eta, step_cum = step_cum, include_probs = include_probs, include_linear_part = include_linear_part))
    }
    mfrm_mml_logprob_bundle_r(idx = idx, config = config, quad = quad, params = params, base_eta = base_eta, 
        step_cum = step_cum, include_probs = include_probs, include_linear_part = include_linear_part)
}

mfrm_mml_eval_cpp11_stats <- function(idx, config, quad, params, base_eta, step_cum = NULL, include_grad = FALSE, 
    external_obs_posterior = NULL) {
    if (is.null(external_obs_posterior) && mfrmr_adaptive_integration(config)) {
        quad$person_basis <- mfrmr_adaptive_quadrature_basis(idx, config, params, quad, base_eta)
    }
    model_code <- mfrm_model_code(config$model)
    if (is.null(step_cum)) {
        step_cum <- if (model_code == 0L) {
            c(0, cumsum(params$steps))
        }
        else {
            mfrm_step_cum_matrix(params$steps_mat)
        }
    }
    population_spec <- materialize_population_spec(config, params)
    quad_basis <- resolve_person_quadrature_basis(quad = quad, population_spec = population_spec, person_count = config$n_person)
    pop_active <- isTRUE(population_spec$active) && is.null(external_obs_posterior)
    if (pop_active) {
        sigma_pop <- sqrt(as.numeric(population_spec$sigma2[1]))
        design_rows <- population_spec$person_lookup[seq_len(config$n_person)]
        pop_design_person <- as.matrix(population_spec$design_matrix[design_rows, , drop = FALSE])
        if (!is.double(pop_design_person)) 
            storage.mode(pop_design_person) <- "double"
        quad_std_nodes <- as.double(quad$nodes)
    }
    else {
        sigma_pop <- 1
        pop_design_person <- matrix(0, 0L, 0L)
        quad_std_nodes <- numeric(0)
    }
    step_cum_rsm <- if (model_code == 0L) 
        as.double(step_cum)
    else numeric(0)
    step_cum_mat <- if (model_code == 0L) 
        matrix(0, 0L, 0L)
    else as.matrix(step_cum)
    if (model_code != 0L && !is.double(step_cum_mat)) 
        storage.mode(step_cum_mat) <- "double"
    step_idx <- if (model_code == 0L) 
        integer(0)
    else as.integer(idx$step_idx)
    slopes <- if (model_code == 2L) 
        as.double(params$slopes)
    else numeric(0)
    slope_idx <- if (model_code == 2L) 
        as.integer(idx$slope_idx)
    else integer(0)
    person_nodes <- as.matrix(quad_basis$nodes)
    if (!is.double(person_nodes)) 
        storage.mode(person_nodes) <- "double"
    person_log_weights <- as.matrix(quad_basis$log_weights)
    if (!is.double(person_log_weights)) 
        storage.mode(person_log_weights) <- "double"
    res <- mfrm_cpp_mml_eval_bundle(model_code = model_code, score_k = as.integer(idx$score_k), person_int = as.integer(idx$person), 
        base_eta = as.double(base_eta), person_nodes = person_nodes, person_log_weights = person_log_weights, 
        step_cum_rsm = step_cum_rsm, step_cum_mat = step_cum_mat, step_idx = step_idx, slopes = slopes, 
        slope_idx = slope_idx, weight = idx$weight %||% NULL, external_obs_posterior = external_obs_posterior, 
        include_grad = isTRUE(include_grad), pop_active = pop_active, pop_design_person = pop_design_person, 
        quad_std_nodes = quad_std_nodes, sigma_pop = as.double(sigma_pop))
    if (is.null(external_obs_posterior)) {
        res$value <- -sum(res$log_marginal)
    }
    res$pop_active <- pop_active
    res
}

mfrm_mml_grad_from_stats <- function(stats, params, idx, config) {
    marginal_residual <- stats$marginal_residual
    grad_facets_exp <- list()
    for (facet in config$facet_names) {
        sign_f <- if (!is.null(config$facet_signs[[facet]])) 
            config$facet_signs[[facet]]
        else -1
        n_lev <- length(params$facets[[facet]])
        grad_facets_exp[[facet]] <- mfrm_cpp_indexed_sum(marginal_residual, as.integer(idx$facets[[facet]]), 
            as.integer(n_lev), as.double(sign_f))
    }
    grad_interaction_free <- compute_interaction_gradient_free(marginal_residual, idx, config)
    grad_facet_free <- unlist(lapply(config$facet_names, function(f) {
        constraint_grad_project(grad_facets_exp[[f]], config$facet_specs[[f]])
    }))
    grad_step_free <- project_typed_step_gradient(stats$grad_step_mat, config)
    grad_log_slope_free <- if (identical(config$model, "GPCM")) {
        project_gpcm_log_slope_gradient(stats$grad_log_slope_exp, config$gpcm_spec)
    }
    else {
        numeric(0)
    }
    if (isTRUE(stats$pop_active)) {
        return(-c(grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free, stats$grad_beta, 
            if (is.null(config$population_spec$fixed_sd)) stats$grad_log_sigma2 else numeric(0)))
    }
    -c(grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free)
}

mfrm_mml_person_bundle <- function(log_prob_mat, person_int, quad_basis, include_posterior = FALSE) {
    ll_by_person <- rowsum(log_prob_mat, person_int, reorder = FALSE)
    person_ids <- as.integer(rownames(ll_by_person))
    log_joint <- quad_basis$log_weights[person_ids, , drop = FALSE] + ll_by_person
    offset <- row_max_fast(ll_by_person)
    shifted <- (ll_by_person - offset) + quad_basis$log_weights[person_ids, , drop = FALSE]
    row_max <- row_max_fast(shifted)
    shifted <- shifted - row_max
    log_normalizer <- log(rowSums(exp(shifted)))
    log_marginal <- offset + (row_max + log_normalizer)
    out <- list(ll_by_person = ll_by_person, person_ids = person_ids, log_joint = log_joint, log_marginal = log_marginal)
    if (isTRUE(include_posterior)) {
        log_posterior <- shifted - log_normalizer
        out$log_posterior <- log_posterior
        out$posterior <- exp(log_posterior)
    }
    out
}

mfrm_mml_posterior_bundle <- function(logprob_bundle) {
    person_bundle <- mfrm_mml_person_bundle(log_prob_mat = logprob_bundle$log_prob_mat, person_int = logprob_bundle$person_int, 
        quad_basis = logprob_bundle$quad_basis, include_posterior = TRUE)
    person_to_row <- integer(nrow(logprob_bundle$quad_basis$nodes))
    person_to_row[person_bundle$person_ids] <- seq_along(person_bundle$person_ids)
    obs_person_row <- person_to_row[logprob_bundle$person_int]
    list(person_bundle = person_bundle, obs_person_row = obs_person_row, obs_posterior = person_bundle$posterior[obs_person_row, 
        , drop = FALSE])
}

mfrm_mml_expected_category_bundle_r <- function(logprob_bundle, posterior_bundle, include_p_geq = FALSE) {
    prob_list <- logprob_bundle$prob_list
    if (is.null(prob_list) || length(prob_list) == 0L) {
        stop("Expected-category quantities require `mfrm_mml_logprob_bundle(..., include_probs = TRUE)`.", 
            call. = FALSE)
    }
    obs_posterior <- posterior_bundle$obs_posterior
    n <- nrow(obs_posterior)
    k_cat <- ncol(prob_list[[1]])
    posterior_prob <- matrix(0, nrow = n, ncol = k_cat)
    for (q in seq_along(prob_list)) {
        posterior_prob <- posterior_prob + prob_list[[q]] * obs_posterior[, q]
    }
    k_vals <- 0:(k_cat - 1)
    expected_k <- as.vector(posterior_prob %*% k_vals)
    var_k <- mfrm_category_variance(posterior_prob, k_vals, expected_k)
    out <- list(posterior_prob = posterior_prob, expected_k = expected_k, var_k = var_k)
    if (isTRUE(include_p_geq) && k_cat > 1L) {
        out$p_geq <- compute_P_geq(posterior_prob)
    }
    out
}

mfrm_mml_expected_category_bundle <- function(logprob_bundle, posterior_bundle, include_p_geq = FALSE) {
    prob_list <- logprob_bundle$prob_list
    if (is.null(prob_list) || length(prob_list) == 0L) {
        stop("Expected-category quantities require `mfrm_mml_logprob_bundle(..., include_probs = TRUE)`.", 
            call. = FALSE)
    }
    if (isTRUE(getOption("mfrmr.use_cpp11_backend", TRUE)) && mfrm_cpp11_backend_available()) {
        return(mfrm_cpp_expected_category_bundle(prob_list = prob_list, obs_posterior = posterior_bundle$obs_posterior, 
            include_p_geq = isTRUE(include_p_geq)))
    }
    mfrm_mml_expected_category_bundle_r(logprob_bundle = logprob_bundle, posterior_bundle = posterior_bundle, 
        include_p_geq = include_p_geq)
}

mfrm_loglik_mml_cached <- function(cache, idx, config, quad) {
    params <- cache$params()
    base_eta <- cache$base_eta()
    step_cum <- cache$step_cum()
    n <- length(idx$score_k)
    if (n == 0) 
        return(0)
    if (mfrm_use_cpp11_backend(config)) {
        return(mfrm_mml_eval_cpp11_stats(idx = idx, config = config, quad = quad, params = params, base_eta = base_eta, 
            step_cum = step_cum, include_grad = FALSE)$value)
    }
    logprob_bundle <- mfrm_mml_logprob_bundle(idx = idx, config = config, quad = quad, params = params, 
        base_eta = base_eta, step_cum = step_cum)
    person_bundle <- mfrm_mml_person_bundle(log_prob_mat = logprob_bundle$log_prob_mat, person_int = logprob_bundle$person_int, 
        quad_basis = logprob_bundle$quad_basis)
    -sum(person_bundle$log_marginal)
}

mfrm_grad_jml_cached <- function(cache, idx, config, sizes, probability_bundle = NULL) {
    mfrm_grad_jml_core(cache$params(), cache$eta(), idx, config, sizes, probability_bundle = probability_bundle, 
        step_cum = cache$step_cum())
}

mfrm_grad_mml_cached <- function(cache, idx, config, sizes, quad, logprob_bundle = NULL, posterior_bundle = NULL) {
    mfrm_grad_mml_core(cache$params(), cache$base_eta(), idx, config, sizes, quad, step_cum = cache$step_cum(), 
        logprob_bundle = logprob_bundle, posterior_bundle = posterior_bundle)
}

mfrm_grad_jml <- function(par, idx, config, sizes) {
    params <- expand_params(par, sizes, config)
    eta <- compute_eta(idx, params, config)
    mfrm_grad_jml_core(params, eta, idx, config, sizes)
}

mfrm_grad_jml_core <- function(params, eta, idx, config, sizes, probability_bundle = NULL, step_cum = NULL) {
    if (is.null(probability_bundle) && mfrm_use_cpp11_backend(config)) {
        stats <- mfrm_jml_eval_cpp11_stats(idx = idx, config = config, params = params, eta = eta, step_cum = step_cum, 
            include_grad = TRUE)
        return(mfrm_jml_grad_from_stats(stats, params, idx, config))
    }
    n <- length(eta)
    score_k <- idx$score_k
    weight <- idx$weight
    if (config$model == "RSM") {
        step_cum <- step_cum %||% c(0, cumsum(params$steps))
        probs <- probability_bundle$probs %||% category_prob_rsm(eta, step_cum)
        k_cat <- ncol(probs)
        n_steps <- k_cat - 1
        expected <- as.vector(probs %*% (0:(k_cat - 1)))
        residual <- score_k - expected
        if (!is.null(weight)) 
            residual <- residual * weight
        n_theta <- length(params$theta)
        grad_theta_exp <- numeric(n_theta)
        if (n_theta > 0) {
            rs <- rowsum(matrix(residual, ncol = 1), idx$person)
            grad_theta_exp[as.integer(rownames(rs))] <- as.vector(rs)
        }
        grad_facets_exp <- list()
        for (facet in config$facet_names) {
            sign_f <- if (!is.null(config$facet_signs[[facet]])) 
                config$facet_signs[[facet]]
            else -1
            n_lev <- length(params$facets[[facet]])
            g <- numeric(n_lev)
            rs <- rowsum(matrix(sign_f * residual, ncol = 1), idx$facets[[facet]])
            g[as.integer(rownames(rs))] <- as.vector(rs)
            grad_facets_exp[[facet]] <- g
        }
        grad_interaction_free <- compute_interaction_gradient_free(residual, idx, config)
        P_geq <- compute_P_geq(probs)
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        step_resid <- P_geq - I_geq
        if (!is.null(weight)) 
            step_resid <- step_resid * weight
        grad_step_centered <- colSums(step_resid)
        grad_step_free <- project_typed_step_gradient(grad_step_centered, config)
        grad_log_slope_free <- numeric(0)
    }
    else if (identical(config$model, "GPCM")) {
        step_cum_mat <- step_cum %||% t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
        probs <- probability_bundle$probs %||% category_prob_gpcm(eta = eta, step_cum_mat = step_cum_mat, 
            criterion_idx = idx$step_idx, slopes = params$slopes, slope_idx = idx$slope_idx)
        k_cat <- ncol(probs)
        n_steps <- k_cat - 1
        n_criteria <- nrow(params$steps_mat)
        k_vals <- 0:(k_cat - 1)
        slope_obs <- params$slopes[idx$slope_idx]
        linear_part <- probability_bundle$linear_part %||% (outer(eta, k_vals) - step_cum_mat[idx$step_idx, 
            , drop = FALSE])
        expected <- as.vector(probs %*% k_vals)
        residual <- slope_obs * (score_k - expected)
        if (!is.null(weight)) 
            residual <- residual * weight
        n_theta <- length(params$theta)
        grad_theta_exp <- numeric(n_theta)
        if (n_theta > 0) {
            rs <- rowsum(matrix(residual, ncol = 1), idx$person)
            grad_theta_exp[as.integer(rownames(rs))] <- as.vector(rs)
        }
        grad_facets_exp <- list()
        for (facet in config$facet_names) {
            sign_f <- if (!is.null(config$facet_signs[[facet]])) 
                config$facet_signs[[facet]]
            else -1
            n_lev <- length(params$facets[[facet]])
            g <- numeric(n_lev)
            rs <- rowsum(matrix(sign_f * residual, ncol = 1), idx$facets[[facet]])
            g[as.integer(rownames(rs))] <- as.vector(rs)
            grad_facets_exp[[facet]] <- g
        }
        grad_interaction_free <- compute_interaction_gradient_free(residual, idx, config)
        P_geq <- compute_P_geq(probs)
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        step_resid <- (P_geq - I_geq) * slope_obs
        if (!is.null(weight)) 
            step_resid <- step_resid * weight
        grad_step_mat <- matrix(0, n_criteria, n_steps)
        rs_step <- rowsum(step_resid, idx$step_idx)
        rs_ids <- as.integer(rownames(rs_step))
        grad_step_mat[rs_ids, ] <- rs_step
        grad_step_free <- project_typed_step_gradient(grad_step_mat, config)
        obs_linear <- linear_part[cbind(seq_len(n), score_k + 1L)]
        slope_score <- slope_obs * rowSums(probs * (obs_linear - linear_part))
        if (!is.null(weight)) 
            slope_score <- slope_score * weight
        grad_log_slope_exp <- numeric(length(params$slopes))
        rs_slope <- rowsum(matrix(slope_score, ncol = 1), idx$slope_idx)
        slope_ids <- as.integer(rownames(rs_slope))
        grad_log_slope_exp[slope_ids] <- as.vector(rs_slope)
        grad_log_slope_free <- project_gpcm_log_slope_gradient(grad_log_slope_exp, config$gpcm_spec)
    }
    else {
        step_cum_mat <- step_cum %||% t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
        probs <- probability_bundle$probs %||% category_prob_pcm(eta, step_cum_mat, idx$step_idx, criterion_splits = idx$criterion_splits)
        k_cat <- ncol(probs)
        n_steps <- k_cat - 1
        n_criteria <- nrow(params$steps_mat)
        expected <- as.vector(probs %*% (0:(k_cat - 1)))
        residual <- score_k - expected
        if (!is.null(weight)) 
            residual <- residual * weight
        n_theta <- length(params$theta)
        grad_theta_exp <- numeric(n_theta)
        if (n_theta > 0) {
            rs <- rowsum(matrix(residual, ncol = 1), idx$person)
            grad_theta_exp[as.integer(rownames(rs))] <- as.vector(rs)
        }
        grad_facets_exp <- list()
        for (facet in config$facet_names) {
            sign_f <- if (!is.null(config$facet_signs[[facet]])) 
                config$facet_signs[[facet]]
            else -1
            n_lev <- length(params$facets[[facet]])
            g <- numeric(n_lev)
            rs <- rowsum(matrix(sign_f * residual, ncol = 1), idx$facets[[facet]])
            g[as.integer(rownames(rs))] <- as.vector(rs)
            grad_facets_exp[[facet]] <- g
        }
        grad_interaction_free <- compute_interaction_gradient_free(residual, idx, config)
        P_geq <- compute_P_geq(probs)
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        step_resid <- P_geq - I_geq
        if (!is.null(weight)) 
            step_resid <- step_resid * weight
        grad_step_mat <- matrix(0, n_criteria, n_steps)
        rs_step <- rowsum(step_resid, idx$step_idx)
        rs_ids <- as.integer(rownames(rs_step))
        grad_step_mat[rs_ids, ] <- rs_step
        grad_step_free <- project_typed_step_gradient(grad_step_mat, config)
        grad_log_slope_free <- numeric(0)
    }
    grad_theta_free <- constraint_grad_project(grad_theta_exp, config$theta_spec)
    grad_facet_free <- unlist(lapply(config$facet_names, function(f) {
        constraint_grad_project(grad_facets_exp[[f]], config$facet_specs[[f]])
    }))
    -c(grad_theta_free, grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free)
}

mfrm_loglik_mml <- function(par, idx, config, sizes, quad) {
    params <- expand_params(par, sizes, config)
    n <- length(idx$score_k)
    if (n == 0) 
        return(0)
    base_eta <- compute_base_eta(idx, params, config)
    if (mfrm_use_cpp11_backend(config)) {
        return(mfrm_mml_eval_cpp11_stats(idx = idx, config = config, quad = quad, params = params, base_eta = base_eta, 
            include_grad = FALSE)$value)
    }
    logprob_bundle <- mfrm_mml_logprob_bundle(idx = idx, config = config, quad = quad, params = params, 
        base_eta = base_eta)
    person_bundle <- mfrm_mml_person_bundle(log_prob_mat = logprob_bundle$log_prob_mat, person_int = logprob_bundle$person_int, 
        quad_basis = logprob_bundle$quad_basis)
    -sum(person_bundle$log_marginal)
}

mfrm_grad_mml <- function(par, idx, config, sizes, quad) {
    params <- expand_params(par, sizes, config)
    base_eta <- compute_base_eta(idx, params, config)
    mfrm_grad_mml_core(params, base_eta, idx, config, sizes, quad)
}

mfrm_grad_mml_core <- function(params, base_eta, idx, config, sizes, quad, step_cum = NULL, logprob_bundle = NULL, 
    posterior_bundle = NULL) {
    n <- length(idx$score_k)
    if (n == 0) 
        return(rep(0, sum(unlist(sizes))))
    if (mfrmr_adaptive_integration(config)) {
        evaluate <- mfrmr_make_adaptive_mml_evaluator(idx, config, sizes, length(quad$nodes))
        return(evaluate(collapse_expanded_params(params, config))$gradient)
    }
    if (is.null(logprob_bundle) && is.null(posterior_bundle) && mfrm_use_cpp11_backend(config)) {
        stats <- mfrm_mml_eval_cpp11_stats(idx = idx, config = config, quad = quad, params = params, 
            base_eta = base_eta, step_cum = step_cum, include_grad = TRUE)
        return(mfrm_mml_grad_from_stats(stats, params, idx, config))
    }
    score_k <- idx$score_k
    weight <- idx$weight
    population_spec <- materialize_population_spec(config, params)
    pop_active <- isTRUE(population_spec$active)
    person_ids_template <- seq_len(config$n_person)
    if (pop_active) {
        sigma_pop <- sqrt(as.numeric(population_spec$sigma2[1]))
        design_rows <- population_spec$person_lookup[person_ids_template]
        design_matrix <- population_spec$design_matrix[design_rows, , drop = FALSE]
        grad_beta <- numeric(ncol(design_matrix))
        grad_log_sigma2 <- 0
    }
    else {
        sigma_pop <- NA_real_
        design_matrix <- NULL
    }
    if (is.null(logprob_bundle)) {
        logprob_bundle <- mfrm_mml_logprob_bundle(idx = idx, config = config, quad = quad, params = params, 
            base_eta = base_eta, step_cum = step_cum, include_probs = TRUE, include_linear_part = identical(config$model, 
                "GPCM"))
    }
    posterior_bundle <- posterior_bundle %||% mfrm_mml_posterior_bundle(logprob_bundle)
    person_bundle <- posterior_bundle$person_bundle
    posterior <- person_bundle$posterior
    obs_posterior <- posterior_bundle$obs_posterior
    person_ids <- person_bundle$person_ids
    n_nodes <- ncol(posterior)
    design_matrix_person <- if (pop_active) {
        design_matrix[person_ids, , drop = FALSE]
    }
    else {
        NULL
    }
    grad_facets_exp <- lapply(config$facet_names, function(f) numeric(length(params$facets[[f]])))
    names(grad_facets_exp) <- config$facet_names
    marginal_residual <- numeric(n)
    if (config$model == "RSM") {
        k_cat <- ncol(logprob_bundle$prob_list[[1]])
        n_steps <- k_cat - 1
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        k_vals <- 0:(k_cat - 1)
        grad_step_centered <- numeric(n_steps)
        for (q in seq_len(n_nodes)) {
            probs_q <- logprob_bundle$prob_list[[q]]
            expected_q <- as.vector(probs_q %*% k_vals)
            residual_q <- score_k - expected_q
            if (!is.null(weight)) 
                residual_q <- residual_q * weight
            if (pop_active) {
                rs_person <- rowsum(matrix(residual_q, ncol = 1), logprob_bundle$person_int, reorder = FALSE)
                person_score_q <- as.numeric(rs_person[, 1])
                grad_beta <- grad_beta + as.numeric(crossprod(design_matrix_person, posterior[, q] * 
                  person_score_q))
                grad_log_sigma2 <- grad_log_sigma2 + sum(posterior[, q] * person_score_q * quad$nodes[q]) * 
                  (0.5 * sigma_pop)
            }
            obs_post_q <- obs_posterior[, q]
            w_residual <- residual_q * obs_post_q
            marginal_residual <- marginal_residual + w_residual
            P_geq <- compute_P_geq(probs_q)
            step_resid <- (P_geq - I_geq) * obs_post_q
            if (!is.null(weight)) 
                step_resid <- step_resid * weight
            grad_step_centered <- grad_step_centered + colSums(step_resid)
        }
        grad_step_free <- project_typed_step_gradient(grad_step_centered, config)
        grad_log_slope_free <- numeric(0)
    }
    else if (identical(config$model, "GPCM")) {
        k_cat <- ncol(logprob_bundle$prob_list[[1]])
        n_steps <- k_cat - 1
        n_criteria <- nrow(params$steps_mat)
        k_vals <- 0:(k_cat - 1)
        slope_idx_int <- idx$slope_idx
        slope_obs <- params$slopes[slope_idx_int]
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        grad_step_mat <- matrix(0, n_criteria, n_steps)
        marginal_step_residual <- matrix(0, n, n_steps)
        grad_log_slope_exp <- numeric(length(params$slopes))
        marginal_slope_score <- numeric(n)
        obs_idx <- cbind(seq_len(n), score_k + 1L)
        for (q in seq_len(n_nodes)) {
            probs_q <- logprob_bundle$prob_list[[q]]
            linear_part_q <- logprob_bundle$linear_part_list[[q]]
            expected_q <- as.vector(probs_q %*% k_vals)
            residual_q <- slope_obs * (score_k - expected_q)
            if (!is.null(weight)) 
                residual_q <- residual_q * weight
            if (pop_active) {
                rs_person <- rowsum(matrix(residual_q, ncol = 1), logprob_bundle$person_int, reorder = FALSE)
                person_score_q <- as.numeric(rs_person[, 1])
                grad_beta <- grad_beta + as.numeric(crossprod(design_matrix_person, posterior[, q] * 
                  person_score_q))
                grad_log_sigma2 <- grad_log_sigma2 + sum(posterior[, q] * person_score_q * quad$nodes[q]) * 
                  (0.5 * sigma_pop)
            }
            obs_post_q <- obs_posterior[, q]
            w_residual <- residual_q * obs_post_q
            marginal_residual <- marginal_residual + w_residual
            p_geq_q <- if (is.null(logprob_bundle$p_geq_list)) 
                compute_P_geq(probs_q)
            else logprob_bundle$p_geq_list[[q]]
            step_resid <- (p_geq_q - I_geq) * slope_obs * obs_post_q
            if (!is.null(weight)) 
                step_resid <- step_resid * weight
            marginal_step_residual <- marginal_step_residual + step_resid
            obs_linear <- linear_part_q[obs_idx]
            slope_score <- slope_obs * rowSums(probs_q * (obs_linear - linear_part_q)) * obs_post_q
            if (!is.null(weight)) 
                slope_score <- slope_score * weight
            marginal_slope_score <- marginal_slope_score + slope_score
        }
        rs_step <- rowsum(marginal_step_residual, idx$step_idx, reorder = FALSE)
        grad_step_mat[as.integer(rownames(rs_step)), ] <- rs_step
        grad_step_free <- project_typed_step_gradient(grad_step_mat, config)
        rs_slope <- rowsum(matrix(marginal_slope_score, ncol = 1), slope_idx_int, reorder = FALSE)
        grad_log_slope_exp[as.integer(rownames(rs_slope))] <- as.vector(rs_slope)
        grad_log_slope_free <- project_gpcm_log_slope_gradient(grad_log_slope_exp, config$gpcm_spec)
    }
    else {
        k_cat <- ncol(logprob_bundle$prob_list[[1]])
        n_steps <- k_cat - 1
        n_criteria <- nrow(params$steps_mat)
        I_geq <- outer(score_k, seq_len(n_steps), ">=") * 1
        k_vals <- 0:(k_cat - 1)
        grad_step_mat <- matrix(0, n_criteria, n_steps)
        marginal_step_residual <- matrix(0, n, n_steps)
        for (q in seq_len(n_nodes)) {
            probs_q <- logprob_bundle$prob_list[[q]]
            expected_q <- as.vector(probs_q %*% k_vals)
            residual_q <- score_k - expected_q
            if (!is.null(weight)) 
                residual_q <- residual_q * weight
            if (pop_active) {
                rs_person <- rowsum(matrix(residual_q, ncol = 1), logprob_bundle$person_int, reorder = FALSE)
                person_score_q <- as.numeric(rs_person[, 1])
                grad_beta <- grad_beta + as.numeric(crossprod(design_matrix_person, posterior[, q] * 
                  person_score_q))
                grad_log_sigma2 <- grad_log_sigma2 + sum(posterior[, q] * person_score_q * quad$nodes[q]) * 
                  (0.5 * sigma_pop)
            }
            obs_post_q <- obs_posterior[, q]
            w_residual <- residual_q * obs_post_q
            marginal_residual <- marginal_residual + w_residual
            P_geq <- compute_P_geq(probs_q)
            step_resid <- (P_geq - I_geq) * obs_post_q
            if (!is.null(weight)) 
                step_resid <- step_resid * weight
            marginal_step_residual <- marginal_step_residual + step_resid
        }
        rs_step <- rowsum(marginal_step_residual, idx$step_idx, reorder = FALSE)
        grad_step_mat[as.integer(rownames(rs_step)), ] <- rs_step
        grad_step_free <- project_typed_step_gradient(grad_step_mat, config)
        grad_log_slope_free <- numeric(0)
    }
    for (facet in config$facet_names) {
        sign_f <- if (!is.null(config$facet_signs[[facet]])) 
            config$facet_signs[[facet]]
        else -1
        rs <- rowsum(matrix(sign_f * marginal_residual, ncol = 1), idx$facets[[facet]], reorder = FALSE)
        f_ids <- as.integer(rownames(rs))
        grad_facets_exp[[facet]][f_ids] <- as.vector(rs)
    }
    grad_interaction_free <- compute_interaction_gradient_free(marginal_residual, idx, config)
    grad_facet_free <- unlist(lapply(config$facet_names, function(f) {
        constraint_grad_project(grad_facets_exp[[f]], config$facet_specs[[f]])
    }))
    if (pop_active) {
        return(-c(grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free, grad_beta, 
            if (is.null(config$population_spec$fixed_sd)) grad_log_sigma2 else numeric(0)))
    }
    -c(grad_facet_free, grad_interaction_free, grad_step_free, grad_log_slope_free)
}

compute_person_eap <- function(idx, config, params, quad) {
    n <- length(idx$score_k)
    if (n == 0) {
        return(tibble(Person = character(0), Estimate = numeric(0), SD = numeric(0)))
    }
    base_eta <- compute_base_eta(idx, params, config)
    logprob_bundle <- mfrm_mml_logprob_bundle(idx = idx, config = config, quad = quad, params = params, 
        base_eta = base_eta)
    person_bundle <- mfrm_mml_person_bundle(log_prob_mat = logprob_bundle$log_prob_mat, person_int = logprob_bundle$person_int, 
        quad_basis = logprob_bundle$quad_basis, include_posterior = TRUE)
    nodes_mat <- logprob_bundle$quad_basis$nodes[person_bundle$person_ids, , drop = FALSE]
    eap <- rowSums(nodes_mat * person_bundle$posterior)
    sd_eap <- sqrt(rowSums((nodes_mat - eap)^2 * person_bundle$posterior))
    n_person <- nrow(logprob_bundle$quad_basis$nodes)
    person_ids <- as.integer(person_bundle$person_ids)
    if (length(person_ids) != length(eap) || anyNA(person_ids) || any(person_ids < 1L | person_ids > 
        n_person) || anyDuplicated(person_ids)) {
        stop("Internal MML Person posterior indices were malformed.", call. = FALSE)
    }
    eap_aligned <- rep(NA_real_, n_person)
    sd_eap_aligned <- rep(NA_real_, n_person)
    eap_aligned[person_ids] <- eap
    sd_eap_aligned[person_ids] <- sd_eap
    tibble(Estimate = eap_aligned, SD = sd_eap_aligned)
}

prepare_constraint_specs <- function(prep, anchor_df = NULL, group_anchor_df = NULL, noncenter_facet = "Person", 
    dummy_facets = character(0), centering_scope = "remainder", anchor_review = NULL) {
    centering_scope <- match.arg(centering_scope, c("facet", "remainder", "anchor_origin"))
    facet_names <- prep$facet_names
    all_facets <- c("Person", facet_names)
    anchor_review <- anchor_review %||% audit_anchor_tables(prep = prep, anchor_df = anchor_df, group_anchor_df = group_anchor_df, 
        noncenter_facet = noncenter_facet, dummy_facets = dummy_facets, centering_scope = centering_scope)
    anchor_df <- anchor_review$anchors
    group_anchor_df <- anchor_review$group_anchors
    anchor_origin <- identical(centering_scope, "anchor_origin")
    anchored_facets <- unique(c(as.character(anchor_df$Facet), as.character(group_anchor_df$Facet)))
    if (anchor_origin) {
        if (noncenter_facet %in% c(anchored_facets, dummy_facets)) {
            stop("`centering_scope = 'anchor_origin'` requires an unanchored, active `noncenter_facet`. Choose a facet without direct anchors, group anchors or dummy constraints.", 
                call. = FALSE)
        }
    }
    map_scope <- if (anchor_origin) 
        "facet"
    else centering_scope
    is_centered <- function(facet) {
        !identical(noncenter_facet, facet) && !(anchor_origin && facet %in% anchored_facets)
    }
    anchor_map <- setNames(vector("list", length(all_facets)), all_facets)
    group_map <- setNames(vector("list", length(all_facets)), all_facets)
    group_values <- setNames(vector("list", length(all_facets)), all_facets)
    for (facet in all_facets) {
        levels <- prep$levels[[facet]]
        if (!is.null(levels)) {
            if (facet %in% dummy_facets) {
                anchor_map[[facet]] <- setNames(rep(0, length(levels)), levels)
                group_map[facet] <- list(NULL)
                group_values[[facet]] <- numeric(0)
                next
            }
            if (nrow(anchor_df) > 0) {
                df <- filter(anchor_df, Facet == facet)
                if (nrow(df) > 0) {
                  anchors <- setNames(df$Anchor, df$Level)
                  anchors <- anchors[names(anchors) %in% levels]
                  if (length(anchors) > 0) 
                    anchor_map[[facet]] <- anchors
                }
            }
            if (nrow(group_anchor_df) > 0) {
                df <- filter(group_anchor_df, Facet == facet)
                if (nrow(df) > 0) {
                  groups <- setNames(df$Group, df$Level)
                  groups <- groups[names(groups) %in% levels]
                  if (length(groups) > 0) 
                    group_map[[facet]] <- groups
                  group_vals <- mutate(summarize(group_by(filter(distinct(select(df, Group, GroupValue)), 
                    !is.na(Group)), Group), GroupValue = {
                    vals <- GroupValue[!is.na(GroupValue)]
                    if (length(vals) == 0) 
                      NA_real_
                    else vals[1]
                  }, .groups = "drop"), GroupValue = ifelse(is.na(GroupValue), 0, GroupValue))
                  if (nrow(group_vals) > 0) {
                    group_values[[facet]] <- setNames(group_vals$GroupValue, group_vals$Group)
                  }
                }
            }
        }
    }
    theta_spec <- build_facet_constraint(levels = prep$levels$Person, anchors = anchor_map$Person, groups = group_map$Person, 
        group_values = group_values$Person, centered = is_centered("Person"), centering_scope = map_scope)
    facet_specs <- lapply(facet_names, function(facet) {
        build_facet_constraint(levels = prep$levels[[facet]], anchors = anchor_map[[facet]], groups = group_map[[facet]], 
            group_values = group_values[[facet]], centered = is_centered(facet), centering_scope = map_scope)
    })
    names(facet_specs) <- facet_names
    anchor_summary <- tibble(Facet = all_facets, AnchoredLevels = vapply(anchor_map, function(x) length(x), 
        integer(1)), GroupAnchors = vapply(group_map, function(x) length(unique(x)), integer(1)), DummyFacet = all_facets %in% 
        dummy_facets)
    list(theta_spec = theta_spec, facet_specs = facet_specs, anchor_summary = anchor_summary, anchor_review = anchor_review)
}

resolve_step_and_slope_facets <- function(model, step_facet, slope_facet, facet_names, method = NULL) {
    if (identical(model, "RSM")) {
        if (!is.null(step_facet) || !is.null(slope_facet)) {
            warning("`step_facet` and `slope_facet` are not used by `model = \"RSM\"`; ", "the rating-scale thresholds are shared across facets.", 
                call. = FALSE)
        }
        return(list(step_facet = NULL, slope_facet = NULL, step_facet_source = "not_applicable", step_facet_note = "RSM uses one shared set of rating-scale thresholds."))
    }
    if (identical(model, "GPCM") && is.null(step_facet)) {
        stop("The current `GPCM` branch requires an explicit `step_facet`.", call. = FALSE)
    }
    step_source <- "explicit"
    step_note <- "Selected explicitly by `step_facet`."
    if (is.null(step_facet)) {
        normalized_facets <- gsub("[^a-z0-9]+", "", tolower(facet_names))
        item_like <- normalized_facets %in% c("item", "items", "prompt", "prompts", "question", "questions", 
            "task", "tasks", "criterion", "criteria")
        candidates <- facet_names[item_like]
        if (length(candidates) == 1L) {
            resolved_step <- candidates
            step_source <- "inferred_from_name"
            step_note <- paste0("Inferred from the item-like facet name `", resolved_step, "`. Supply `step_facet` explicitly to override this choice.")
        }
        else {
            resolved_step <- facet_names[1]
            step_source <- "first_facet_fallback"
            step_note <- paste0("No unique item-like facet name was available; `", resolved_step, "` was selected as the first declared facet.")
            warning("`model = \"PCM\"` needs a facet whose levels receive separate step ", "parameters. No unique item-like facet could be inferred, so the first ", 
                "declared facet (`", resolved_step, "`) was selected for backward ", "compatibility. Verify this choice and set `step_facet` explicitly for ", 
                "a final analysis.", call. = FALSE)
        }
    }
    else {
        if (length(step_facet) != 1L || !is.atomic(step_facet) || anyNA(step_facet) || !nzchar(as.character(step_facet))) {
            stop("`step_facet` must name exactly one declared facet; multiple threshold owners are unsupported.", 
                call. = FALSE)
        }
        resolved_step <- as.character(step_facet)
    }
    if (!resolved_step %in% facet_names) {
        stop("step_facet = '", resolved_step, "' is not among the declared facets: ", paste(facet_names, 
            collapse = ", "), ". ", "Supply a valid facet name.", call. = FALSE)
    }
    if (identical(model, "PCM")) {
        return(list(step_facet = resolved_step, slope_facet = NULL, step_facet_source = step_source, 
            step_facet_note = step_note))
    }
    resolved_slope <- if (is.null(slope_facet)) 
        resolved_step
    else as.character(slope_facet[1])
    if (!resolved_slope %in% facet_names) {
        stop("slope_facet = '", resolved_slope, "' is not among the declared facets: ", paste(facet_names, 
            collapse = ", "), ". ", "Supply a valid facet name.", call. = FALSE)
    }
    if (!identical(resolved_step, resolved_slope) && !identical(method, "MML")) {
        stop("Separate GPCM slope and step owners require MML; this route requires `slope_facet == step_facet`.", 
            call. = FALSE)
    }
    list(step_facet = resolved_step, slope_facet = resolved_slope, step_facet_source = step_source, step_facet_note = step_note)
}

sanitize_noncenter_facet <- function(noncenter_facet, facet_names) {
    if (is.null(noncenter_facet)) 
        return("Person")
    valid_set <- c("Person", facet_names)
    if (length(noncenter_facet) == 1L && noncenter_facet %in% valid_set) {
        return(noncenter_facet)
    }
    warning("`noncenter_facet` value ", shQuote(noncenter_facet), " is not one of the available facets (", 
        paste(shQuote(valid_set), collapse = ", "), "); falling back to 'Person'. Check for typos.", 
        call. = FALSE)
    "Person"
}

sanitize_dummy_facets <- function(dummy_facets, facet_names) {
    if (is.null(dummy_facets)) 
        return(character(0))
    valid_set <- c("Person", facet_names)
    kept <- intersect(dummy_facets, valid_set)
    dropped <- setdiff(dummy_facets, valid_set)
    if (length(dropped) > 0L) {
        warning("`dummy_facets` contains value(s) not present in the model: ", paste(shQuote(dropped), 
            collapse = ", "), " (available: ", paste(shQuote(valid_set), collapse = ", "), "). Unknown entries are ignored; check for typos.", 
            call. = FALSE)
    }
    kept
}

build_facet_signs <- function(facet_names, positive_facets = character(0)) {
    positives <- intersect(positive_facets, facet_names)
    dropped <- setdiff(positive_facets, facet_names)
    if (length(dropped) > 0L) {
        warning("`positive_facets` contains value(s) not present in the model: ", paste(shQuote(dropped), 
            collapse = ", "), " (available: ", paste(shQuote(facet_names), collapse = ", "), "). Unknown entries are ignored; check for typos (case-sensitive).", 
            call. = FALSE)
    }
    signs <- setNames(ifelse(facet_names %in% positives, 1, -1), facet_names)
    list(signs = signs, positive_facets = positives)
}

audit_interaction_orientation <- function(config, interaction_facets) {
    interaction_facets <- unique(as.character(interaction_facets %||% character(0)))
    interaction_facets <- interaction_facets[!is.na(interaction_facets) & nzchar(interaction_facets)]
    if (length(interaction_facets) == 0) {
        return(list(table = tibble(), mixed_sign = FALSE, direction_note = "No interaction facets were supplied for orientation review.", 
            recommended_action = "None."))
    }
    sign_map <- config$facet_signs %||% numeric(0)
    sign_vals <- vapply(interaction_facets, function(facet) {
        if (!is.null(names(sign_map)) && facet %in% names(sign_map)) {
            mapped <- suppressWarnings(as.numeric(sign_map[[facet]][1]))
            if (is.finite(mapped)) 
                return(mapped)
        }
        if (identical(facet, "Person")) 
            1
        else -1
    }, numeric(1))
    positive_facets <- as.character(config$positive_facets %||% character(0))
    orientation_tbl <- tibble(Facet = interaction_facets, Sign = sign_vals, Orientation = ifelse(sign_vals >= 
        0, "positive", "negative"), InPositiveFacets = interaction_facets %in% positive_facets)
    mixed_sign <- length(unique(sign_vals[is.finite(sign_vals)])) > 1L
    if (mixed_sign) {
        direction_note <- paste("Selected interaction facets mix positive and negative score orientations.", 
            "Report cells as higher-than-expected or lower-than-expected rather than using directional labels tied to a single facet.")
        recommended_action <- paste("For clearer interpretation, either align the selected facets through `positive_facets`", 
            "or keep the mixed orientation and use neutral higher/lower-than-expected wording in reports.")
    }
    else {
        direction_note <- "Selected interaction facets share the same score orientation."
        recommended_action <- "Directional wording is stable across the selected interaction facets."
    }
    list(table = orientation_tbl, mixed_sign = mixed_sign, direction_note = direction_note, recommended_action = recommended_action)
}

build_estimation_config <- function(prep, model, method, step_facet, slope_facet, interaction_specs = NULL, 
    weight_col, facet_signs, positive_facets, noncenter_facet, dummy_facets, anchor_df, group_anchor_df, 
    population = NULL, centering_scope = "remainder", anchor_review = NULL, constraint_specs = NULL, 
    step_constraints = NULL) {
    if (identical(centering_scope, "anchor_origin") && (!identical(method, "JML") || !model %in% c("RSM", 
        "PCM") || length(interaction_specs) > 0L)) {
        stop("`centering_scope = 'anchor_origin'` requires ordinary additive RSM/PCM JML.", call. = FALSE)
    }
    config <- list(model = model, method = method, n_person = length(prep$levels$Person), person_levels = prep$levels$Person, 
        n_cat = prep$rating_max - prep$rating_min + 1, facet_names = prep$facet_names, facet_levels = prep$levels[prep$facet_names], 
        step_facet = step_facet, slope_facet = slope_facet, interaction_specs = interaction_specs %||% 
            list(), facet_interactions = names(interaction_specs %||% list()), keep_original = isTRUE(prep$keep_original), 
        rating_min = prep$rating_min, rating_max = prep$rating_max, rating_range_source = prep$rating_range_source %||% 
            NA_character_, rating_min_source = prep$rating_min_source %||% NA_character_, rating_max_source = prep$rating_max_source %||% 
            NA_character_, score_map = prep$score_map)
    config$weight_col <- if (!is.null(weight_col)) 
        weight_col
    else NULL
    config$positive_facets <- positive_facets
    config$facet_signs <- facet_signs
    constraint_specs <- constraint_specs %||% prepare_constraint_specs(prep = prep, anchor_df = anchor_df, 
        group_anchor_df = group_anchor_df, noncenter_facet = noncenter_facet, dummy_facets = dummy_facets, 
        centering_scope = centering_scope, anchor_review = anchor_review)
    theta_spec <- constraint_specs$theta_spec
    if (identical(method, "MML") && (any(is.finite(theta_spec$anchors)) || any(!is.na(theta_spec$groups)))) {
        stop("Person anchors and Person group anchors are not supported with MML. ", "MML integrates Person ability rather than fixing individual values or ", 
            "their group mean. Common Persons in the rating design do not require ", "anchors. Fixed Person constraints are available with JML, whose ", 
            "estimation assumptions differ.", call. = FALSE)
    }
    config$theta_spec <- constraint_specs$theta_spec
    config$facet_specs <- constraint_specs$facet_specs
    config$noncenter_facet <- noncenter_facet
    config$centering_scope <- centering_scope
    config$dummy_facets <- dummy_facets
    config$anchor_summary <- constraint_specs$anchor_summary
    config$anchor_review <- constraint_specs$anchor_review
    config$step_specs <- mfrmr_default_step_specs(config)
    if (!is.null(step_constraints)) {
        config$step_constraint_map <- build_mfrm_step_map(step_constraints, config, prep)
    }
    config$source_columns <- prep$source_columns
    config$repeated_ratings <- prep$repeated_ratings %||% "review"
    config$population_spec <- compact_population_spec(population, prep$levels$Person)
    config$gpcm_spec <- if (identical(model, "GPCM")) {
        build_gpcm_slope_spec(levels = prep$levels[[slope_facet]], slope_facet = slope_facet, step_facet = step_facet)
    }
    else {
        NULL
    }
    list(config = config, sizes = build_param_sizes(config))
}

build_initial_param_vector <- function(config, sizes) {
    n_cat <- config$n_cat
    step_init <- if (n_cat > 1) {
        seq(-1, 1, length.out = n_cat - 1)
    }
    else {
        numeric(0)
    }
    facet_starts <- unlist(lapply(config$facet_names, function(f) rep(0, sizes[[f]])))
    step_specs <- mfrmr_step_specs(config)
    step_init_free <- unlist(lapply(step_specs, function(spec) {
        initial_step_constraint_free(center_sum_zero(step_init), spec)
    }), use.names = FALSE)
    if (!is.null(config$step_constraint_map)) {
        step_init_free <- rep(center_sum_zero(step_init), length(step_specs))[config$step_constraint_map$free]
    }
    base <- c(rep(0, sizes$theta), facet_starts, if (facet_interactions_active(config)) {
        rep(0, sizes[["interactions"]] %||% 0L)
    } else {
        numeric(0)
    }, step_init_free, if (identical(config$model, "GPCM")) {
        rep(0, sizes[["log_slopes"]] %||% 0L)
    } else {
        numeric(0)
    })
    if (identical(config$method, "MML") && isTRUE(config$population_spec$active)) {
        base <- c(base, rep(0, sizes[["beta"]]), rep(0, sizes[["log_sigma2"]]))
    }
    base
}

make_param_cache <- function(sizes, config, idx, is_mml = FALSE) {
    cached_par <- NULL
    cached_params <- NULL
    cached_eta <- NULL
    cached_base_eta <- NULL
    cached_step_cum <- NULL
    list(ensure = function(par) {
        if (identical(par, cached_par)) return(invisible(NULL))
        next_params <- expand_params(par, sizes, config)
        next_eta <- NULL
        next_base_eta <- NULL
        if (is_mml) {
            next_base_eta <- compute_base_eta(idx, next_params, config)
        } else {
            next_eta <- compute_eta(idx, next_params, config)
        }
        next_step_cum <- if (config$model == "RSM") {
            c(0, cumsum(next_params$steps))
        } else {
            mfrm_step_cum_matrix(next_params$steps_mat)
        }
        cached_par <<- par + 0
        cached_params <<- next_params
        cached_eta <<- next_eta
        cached_base_eta <<- next_base_eta
        cached_step_cum <<- next_step_cum
        invisible(NULL)
    }, params = function() cached_params, eta = function() cached_eta, base_eta = function() cached_base_eta, 
        step_cum = function() cached_step_cum)
}

compute_gradient_metrics <- function(gradient) {
    grad <- as.numeric(gradient %||% numeric(0))
    if (length(grad) == 0L || any(!is.finite(grad))) {
        return(list(TerminalGradientSupNorm = NA_real_, TerminalGradientRMS = NA_real_))
    }
    scale <- max(abs(grad))
    list(TerminalGradientSupNorm = scale, TerminalGradientRMS = if (scale == 0) 0 else scale * sqrt(mean((grad/scale)^2)))
}

build_optimizer_diagnostics <- function(opt, gradient = NULL, reltol = 1e-06, maxit = NA_integer_, optimizer_method = "BFGS", 
    convergence_basis = c("optimizer_gradient", "relative_loglik", "marginal_score_per_person"), gradient_tolerance = NULL) {
    convergence_basis <- match.arg(convergence_basis)
    code <- as.integer(opt$convergence %||% NA_integer_)
    counts <- opt$counts %||% c()
    fn_evals <- as.integer(unname(counts[["function"]] %||% NA_integer_))
    gr_evals <- as.integer(unname(counts[["gradient"]] %||% NA_integer_))
    message_raw <- opt$message
    message <- if (length(message_raw) == 0L || is.null(message_raw)) {
        NA_character_
    }
    else {
        as.character(message_raw[1])
    }
    grad_metrics <- compute_gradient_metrics(gradient)
    if (!is.null(opt$par)) {
        if (!is.null(gradient) && length(opt$par) == 0L && length(gradient) == 0L) {
            grad_metrics <- list(TerminalGradientSupNorm = 0, TerminalGradientRMS = 0)
        }
        else if (length(gradient) != length(opt$par)) {
            grad_metrics <- compute_gradient_metrics(NULL)
        }
    }
    grad_tol <- if (is.finite(reltol)) 
        max(1e-04, 10 * reltol)
    else 1e-04
    if (identical(convergence_basis, "optimizer_gradient") && !is.null(gradient_tolerance)) {
        if (!is.numeric(gradient_tolerance) || is.complex(gradient_tolerance) || length(gradient_tolerance) != 
            1L || !is.finite(gradient_tolerance) || gradient_tolerance <= 0) 
            stop("Supply a finite positive optimizer-gradient tolerance.")
        grad_tol <- gradient_tolerance
    }
    if (identical(convergence_basis, "marginal_score_per_person")) {
        if (length(gradient_tolerance) != 1L || !is.finite(gradient_tolerance) || gradient_tolerance <= 
            0) 
            stop("Supply the positive marginal-score stopping tolerance.")
        grad_tol <- gradient_tolerance
        reviewable_warning <- FALSE
        passed <- identical(code, 0L) && is.finite(grad_metrics$TerminalGradientSupNorm) && grad_metrics$TerminalGradientSupNorm <= 
            grad_tol
        status <- if (passed) 
            "converged"
        else if (identical(code, 1L)) 
            "iteration_limit"
        else "optimizer_warning"
        reason <- if (passed) 
            "marginal_score_tolerance_met"
        else "marginal_score_tolerance_not_met"
        severity <- if (passed) 
            "pass"
        else "fail"
        detail <- if (passed) {
            "EM met the marginal-score tolerance per Person; this is numerical convergence, not inferential eligibility."
        }
        else {
            "EM stopped without meeting the marginal-score tolerance per Person."
        }
    }
    else if (identical(convergence_basis, "relative_loglik")) {
        reviewable_warning <- FALSE
        if (is.na(code)) {
            status <- "unknown"
            reason <- "missing_code"
            severity <- "review"
            detail <- "EM did not return a convergence code."
        }
        else if (identical(code, 0L) && !is.finite(grad_metrics$TerminalGradientSupNorm)) {
            status <- "converged_gradient_review"
            reason <- "code_zero_unavailable_gradient"
            severity <- "review"
            detail <- "EM relative log-likelihood change met its stopping tolerance, but a complete finite terminal gradient is unavailable."
        }
        else if (identical(code, 0L)) {
            status <- "converged"
            reason <- "relative_loglik_tolerance_met"
            severity <- "pass"
            detail <- "EM relative log-likelihood change met the stopping tolerance."
        }
        else if (identical(code, 1L)) {
            status <- "iteration_limit"
            reason <- "relative_loglik_iteration_limit"
            severity <- "fail"
            detail <- "EM reached the iteration limit before the relative log-likelihood change met the stopping tolerance."
        }
        else {
            status <- "optimizer_warning"
            reason <- "nonzero_code"
            severity <- "fail"
            detail <- "EM returned a nonzero convergence code that requires follow-up."
        }
    }
    else {
        gradient_review <- !is.na(code) && identical(code, 0L) && is.finite(grad_metrics$TerminalGradientSupNorm) && 
            grad_metrics$TerminalGradientSupNorm > grad_tol
        reviewable_warning <- !is.na(code) && code != 0L && is.finite(grad_metrics$TerminalGradientSupNorm) && 
            grad_metrics$TerminalGradientSupNorm <= grad_tol
        precision_warning <- is.character(message) && !is.na(message) && grepl("precision loss", message, 
            ignore.case = TRUE)
        if (is.na(code)) {
            status <- "unknown"
            reason <- "missing_code"
            severity <- "review"
            detail <- "Optimizer did not return a convergence code."
        }
        else if (identical(code, 0L) && !is.finite(grad_metrics$TerminalGradientSupNorm)) {
            status <- "converged_gradient_review"
            reason <- "code_zero_unavailable_gradient"
            severity <- "review"
            reviewable_warning <- TRUE
            detail <- paste0("Optimizer returned convergence code 0, but a complete finite ", "terminal gradient is unavailable; stationarity and inference readiness are not verified.")
        }
        else if (identical(code, 0L) && gradient_review) {
            status <- "converged_gradient_review"
            reason <- "code_zero_large_gradient"
            severity <- "review"
            reviewable_warning <- TRUE
            detail <- paste0("Optimizer returned convergence code 0, but the terminal gradient ", "exceeded the review tolerance; confirm numerical stability before ", 
                "reporting.")
        }
        else if (identical(code, 0L)) {
            status <- "converged"
            reason <- "tolerance_met"
            severity <- "pass"
            detail <- "Optimizer returned convergence code 0."
        }
        else if (reviewable_warning && precision_warning) {
            status <- "reviewable_warning"
            reason <- "precision_warning_small_gradient"
            severity <- "review"
            detail <- "Optimizer reported precision loss, but the terminal gradient was already within the review tolerance."
        }
        else if (reviewable_warning && identical(code, 1L)) {
            status <- "reviewable_warning"
            reason <- "iteration_limit_small_gradient"
            severity <- "review"
            detail <- "Optimizer reached the iteration limit, but the terminal gradient was already within the review tolerance."
        }
        else if (reviewable_warning) {
            status <- "reviewable_warning"
            reason <- "nonzero_code_small_gradient"
            severity <- "review"
            detail <- "Optimizer returned a nonzero code, but the terminal gradient was already within the review tolerance."
        }
        else if (identical(code, 1L)) {
            status <- "iteration_limit"
            reason <- "iteration_limit_large_gradient"
            severity <- "fail"
            detail <- "Optimizer reached the iteration limit before the terminal gradient became small enough for review-only acceptance."
        }
        else {
            status <- "optimizer_warning"
            reason <- "nonzero_code"
            severity <- "fail"
            detail <- "Optimizer returned a nonzero convergence code that requires follow-up."
        }
    }
    list(OptimizerMethod = as.character(optimizer_method), ConvergenceCode = code, ConvergenceBasis = as.character(convergence_basis), 
        ConvergenceStatus = status, ConvergenceReason = reason, ConvergenceSeverity = severity, ConvergenceMessage = message, 
        ConvergenceDetail = detail, ReviewableWarning = reviewable_warning, GradientReviewTolerance = grad_tol, 
        FunctionEvaluations = fn_evals, GradientEvaluations = gr_evals, TerminalGradientSupNorm = grad_metrics$TerminalGradientSupNorm, 
        TerminalGradientRMS = grad_metrics$TerminalGradientRMS)
}

normalize_mml_engine <- function(mml_engine = "direct") {
    match.arg(tolower(as.character(mml_engine %||% "direct")[1]), c("direct", "em", "hybrid"))
}

resolve_mml_engine_plan <- function(method, model, requested = "direct", population_active = FALSE, interaction_active = FALSE) {
    requested <- normalize_mml_engine(requested)
    if (!identical(method, "MML")) {
        return(list(Requested = requested, Used = "not_applicable", Fallback = FALSE, Detail = "MML engine selection applies only to method = 'MML'."))
    }
    if (identical(requested, "direct")) {
        return(list(Requested = requested, Used = requested, Fallback = FALSE, Detail = "Direct marginal likelihood optimization."))
    }
    if (identical(model, "GPCM")) {
        return(list(Requested = requested, Used = "direct", Fallback = TRUE, Detail = "EM and hybrid MML are currently implemented only for RSM/PCM; falling back to direct optimization for GPCM."))
    }
    if (isTRUE(population_active)) {
        return(list(Requested = requested, Used = "direct", Fallback = TRUE, Detail = "EM and hybrid MML currently require `population = NULL`; falling back to direct optimization for the latent-regression branch."))
    }
    list(Requested = requested, Used = requested, Fallback = FALSE, Detail = if (identical(requested, 
        "em")) {
        "Expectation-maximization over the marginal likelihood."
    } else {
        "EM warm start followed by direct marginal likelihood optimization."
    })
}

compute_hybrid_em_maxit <- function(maxit) {
    maxit <- as.integer(maxit %||% 0L)
    max(2L, min(3L, maxit%/%10L))
}

compute_hybrid_em_mstep_maxit <- function(em_maxit) {
    em_maxit <- as.integer(em_maxit %||% 0L)
    max(2L, min(4L, em_maxit + 1L))
}

compute_hybrid_em_reltol <- function(reltol) {
    reltol <- as.numeric(reltol %||% 1e-06)
    max(0.001, sqrt(reltol))
}

build_person_table <- function(method, idx, config, params, prep, quad_points, quad = NULL) {
    extreme_flag <- .flag_extreme_persons(prep, rating_min = prep$rating_min, rating_max = prep$rating_max)
    if (method == "MML") {
        if (is.null(quad)) 
            quad <- gauss_hermite_normal(quad_points)
        tbl <- select(mutate(compute_person_eap(idx, config, params, quad), Person = prep$levels$Person), 
            Person, Estimate, SD)
        tbl$PosteriorSD <- tbl$SD
        tbl$SE <- tbl$SD
        tbl$Extreme <- extreme_flag[match(tbl$Person, names(extreme_flag))]
        return(tbl)
    }
    tbl <- tibble(Person = prep$levels$Person, Estimate = params$theta)
    tbl$SE <- NA_real_
    tbl$Extreme <- extreme_flag[match(tbl$Person, names(extreme_flag))]
    tbl
}

.flag_extreme_persons <- function(prep, rating_min, rating_max) {
    if (is.null(prep$data) || nrow(prep$data) == 0L) {
        return(setNames(character(0), character(0)))
    }
    by_person <- split(prep$data$Score, prep$data$Person)
    flag <- vapply(by_person, function(s) {
        s <- s[is.finite(s)]
        if (length(s) == 0L) 
            return(NA_character_)
        if (all(s == rating_max, na.rm = TRUE)) 
            return("high")
        if (all(s == rating_min, na.rm = TRUE)) 
            return("low")
        "none"
    }, character(1))
    flag
}

build_other_facet_table <- function(config, prep, params) {
    facet_tbls <- lapply(config$facet_names, function(facet) {
        mutate(tibble(Level = prep$levels[[facet]], Estimate = params$facets[[facet]]), Facet = facet, 
            .before = 1)
    })
    bind_rows(facet_tbls)
}

build_step_table <- function(config, prep, params) {
    if (config$model == "RSM") {
        tbl <- tibble(Step = paste0("Step_", seq_len(config$n_cat - 1)), Estimate = params$steps)
    }
    else {
        tbl <- mutate(expand_grid(StepFacet = prep$levels[[config$step_facet]], Step = paste0("Step_", 
            seq_len(config$n_cat - 1))), Estimate = as.vector(t(params$steps_mat)))
    }
    step_map <- config$step_constraint_map
    if (!is.null(step_map)) {
        varying <- Matrix::rowSums(abs(step_map$basis)) > 0
        tbl$ConstraintGroup <- step_map$groups
        tbl$ConstraintStatus <- ifelse(step_map$fixed, "fixed_value", ifelse(!varying, "fixed_by_constraints", 
            ifelse(!is.na(step_map$groups), "shared", "estimated")))
    }
    tbl
}

build_slope_table <- function(config, prep, params) {
    if (!identical(config$model, "GPCM")) {
        return(tibble())
    }
    if (!is.null(config$gpcm_spec$component_levels)) {
        spec <- config$gpcm_spec
        components <- params$slope_components
        if (!identical(prep$levels[config$slope_facet], spec$component_levels) || !identical(names(components), 
            names(spec$component_levels)) || !all(vapply(names(components), function(owner) identical(components[[owner]]$Level, 
            spec$component_levels[[owner]]), logical(1)))) {
            stop("Slope tables require the fitted owners and level ordering.", call. = FALSE)
        }
        meta <- mfrm_gpcm_product_metadata(spec)
        return(tibble(SlopeOwner = meta$Owner, SlopeFacet = meta$Level, LogEstimate = unlist(lapply(components, 
            `[[`, "LogSlope"), use.names = FALSE), Estimate = unlist(lapply(components, `[[`, "Slope"), 
            use.names = FALSE), ScaleReference = meta$ScaleReference, Identification = meta$Identification))
    }
    tibble(SlopeFacet = prep$levels[[config$slope_facet]], LogEstimate = params$log_slopes, Estimate = params$slopes)
}

mfrm_ic_common_panel <- function(deviance, npar, persons) {
    deviance <- suppressWarnings(as.numeric(deviance)[1])
    npar_raw <- suppressWarnings(as.numeric(npar)[1])
    persons_raw <- suppressWarnings(as.numeric(persons)[1])
    integer_tolerance <- sqrt(.Machine$double.eps)
    if (!is.finite(deviance)) {
        stop("`deviance` must be one finite numeric value.", call. = FALSE)
    }
    if (!is.finite(npar_raw) || npar_raw < 0 || abs(npar_raw - round(npar_raw)) > integer_tolerance) {
        stop("`npar` must be one non-negative integer.", call. = FALSE)
    }
    if (!is.finite(persons_raw) || persons_raw < 1 || abs(persons_raw - round(persons_raw)) > integer_tolerance) {
        stop("`persons` must be one positive integer.", call. = FALSE)
    }
    npar <- as.integer(round(npar_raw))
    persons <- as.integer(round(persons_raw))
    formula_ids <- .mfrmr_const_mfrm_ic_formula_identifiers
    list(Deviance = deviance, Npar = npar, Persons = persons, AIC = deviance + 2 * npar, BIC = deviance + 
        log(persons) * npar, SABIC = deviance + log((persons + 2)/24) * npar, SABICSelectable = persons > 
        22L, AICFormula = unname(formula_ids[["AIC"]]), BICFormula = unname(formula_ids[["BIC"]]), SABICFormula = unname(formula_ids[["SABIC"]]))
}

mfrm_ic_console_lines <- function(summary_row, digits = 3L) {
    row <- as.data.frame(summary_row %||% data.frame(), stringsAsFactors = FALSE)
    if (nrow(row) == 0L) 
        return(character(0))
    row <- row[1, , drop = FALSE]
    digits <- suppressWarnings(as.integer(digits)[1])
    if (!is.finite(digits)) 
        digits <- 3L
    digits <- max(0L, digits)
    format_value <- function(field, fallback = NA_real_) {
        value <- if (field %in% names(row)) {
            suppressWarnings(as.numeric(row[[field]][1]))
        }
        else {
            fallback
        }
        if (!is.finite(value)) 
            return("NA")
        formatC(value, format = "f", digits = digits)
    }
    contract_current <- "ICContractVersion" %in% names(row) && identical(as.character(row$ICContractVersion[1]), 
        .mfrmr_const_mfrm_ic_contract_version)
    eligible <- contract_current && "ICEligible" %in% names(row) && isTRUE(as.logical(row$ICEligible[1]))
    ic_selectable <- eligible && "ICSelectable" %in% names(row) && isTRUE(as.logical(row$ICSelectable[1]))
    status <- if ("ICStatus" %in% names(row)) {
        as.character(row$ICStatus[1])
    }
    else {
        "legacy_or_unknown"
    }
    quadrature_points <- if ("ICQuadraturePoints" %in% names(row)) {
        suppressWarnings(as.integer(row$ICQuadraturePoints[1]))
    }
    else {
        NA_integer_
    }
    loglik <- format_value("LogLik")
    if (identical(status, "descriptive_jml")) {
        return(paste0("LogLik: ", loglik, " | Information-criterion ranking is unavailable for JML."))
    }
    if (eligible) {
        lines <- paste0("LogLik: ", loglik, " | Canonical MML AIC: ", format_value("AIC"), " | Person-BIC: ", 
            format_value("BIC"), " | Sclove SABIC: ", format_value("SABIC"))
        if (!ic_selectable) {
            lines <- c(lines, paste0("Integration selection guard: criteria are displayed for ", "screening/review only; automatic deltas, weights, preferences, ", 
                "and LRT are disabled at q=", if (is.finite(quadrature_points)) quadrature_points else "unknown", 
                ". Use q >= 31 as the comparison starting ", "grid and check a denser common grid when the decision is close."))
        }
        persons <- if ("Persons" %in% names(row)) {
            suppressWarnings(as.integer(row$Persons[1]))
        }
        else {
            NA_integer_
        }
        if (is.finite(persons) && persons <= 22L) {
            lines <- c(lines, paste0("SABIC selection guard: displayed for sensitivity only; automatic ", 
                "SABIC selection is disabled at Persons <= 22."))
        }
        return(lines)
    }
    legacy_aic <- if ("LegacyAIC" %in% names(row)) 
        "LegacyAIC"
    else "AIC"
    legacy_bic <- if ("LegacyBIC" %in% names(row)) 
        "LegacyBIC"
    else "BIC"
    reason <- switch(status, invalid_weight_policy = "invalid observation weights", suppressed_nonunit_weight = "non-unit observation weights lack ordinary likelihood-based comparison support", 
        invalid_person_count = "the Person count is invalid", invalid_likelihood_contract = "likelihood or parameter-count information is unavailable", 
        unsupported_product_slopes = "two-family slope model comparison is not yet supported", "current comparison support is not established")
    lines <- paste0("LogLik: ", loglik, " | Canonical MML information-criterion panel: not eligible; ", 
        reason, ".")
    if (is.finite(suppressWarnings(as.numeric(row[[legacy_aic]][1] %||% NA_real_))) || is.finite(suppressWarnings(as.numeric(row[[legacy_bic]][1] %||% 
        NA_real_)))) {
        lines <- c(lines, paste0("Legacy descriptive AIC: ", format_value(legacy_aic), " | Legacy descriptive BIC: ", 
            format_value(legacy_bic), ". These values are not part of the common MML ranking panel."))
    }
    lines
}

mfrm_ic_weight_policy <- function(prep, config, tolerance = sqrt(.Machine$double.eps)) {
    dat <- prep$data %||% data.frame()
    if (!is.data.frame(dat) || !"Weight" %in% names(dat)) {
        return("invalid")
    }
    weights <- suppressWarnings(as.numeric(dat$Weight))
    if (length(weights) == 0L || any(!is.finite(weights)) || any(weights <= 0)) {
        return("invalid")
    }
    declared <- !is.null(config$weight_col) && length(config$weight_col) > 0L && !is.na(config$weight_col[1]) && 
        nzchar(as.character(config$weight_col[1]))
    if (all(abs(weights - 1) <= tolerance)) {
        return(if (declared) "explicit_unit" else "unweighted")
    }
    if (!"Person" %in% names(dat)) 
        return("nonunit_row_varying")
    person_weights <- split(weights, as.character(dat$Person), drop = TRUE)
    constant_within_person <- all(vapply(person_weights, function(x) {
        length(x) > 0L && max(x) - min(x) <= tolerance
    }, logical(1)))
    if (constant_within_person) {
        "nonunit_constant_within_person"
    }
    else {
        "nonunit_row_varying"
    }
}

mfrm_ic_integration_evaluation_id <- function(method, config) {
    method <- public_mfrm_method_label(toupper(as.character(method)[1]))
    if (!identical(method, "MML")) 
        return("not_applicable_jml")
    quad_points <- suppressWarnings(as.integer(config$estimation_control$quad_points %||% NA_integer_))
    paste0(if (mfrmr_adaptive_integration(config)) 
        "mfrmr_aghq_normal_v1:q="
    else "mfrmr_ghq_normal_v1:q=", if (is.finite(quad_points)) 
        quad_points
    else "unknown")
}

mfrm_ic_integration_policy <- function(method, config) {
    method <- public_mfrm_method_label(toupper(as.character(method)[1]))
    if (!identical(method, "MML")) {
        return(list(QuadraturePoints = NA_integer_, Tier = "not_applicable_jml", Status = "not_applicable_jml", 
            Selectable = FALSE))
    }
    quad_raw <- suppressWarnings(as.numeric(config$estimation_control$quad_points %||% NA_real_)[1])
    integer_tolerance <- sqrt(.Machine$double.eps)
    if (!is.finite(quad_raw) || quad_raw < 1 || abs(quad_raw - round(quad_raw)) > integer_tolerance) {
        return(list(QuadraturePoints = NA_integer_, Tier = "unknown", Status = "invalid_or_unknown_quadrature", 
            Selectable = FALSE))
    }
    quad_points <- as.integer(round(quad_raw))
    if (quad_points < 15L) {
        tier <- "coarse_screening"
        status <- "screening_only"
        selectable <- FALSE
    }
    else if (quad_points < 31L) {
        tier <- "intermediate_review"
        status <- "review_only"
        selectable <- FALSE
    }
    else if (quad_points < 61L) {
        tier <- "standard_start"
        status <- "selection_start"
        selectable <- TRUE
    }
    else {
        tier <- "dense_sensitivity"
        status <- "dense_sensitivity"
        selectable <- TRUE
    }
    list(QuadraturePoints = quad_points, Tier = tier, Status = status, Selectable = selectable)
}

build_mfrm_ic_contract <- function(loglik, npar, prep, config, method) {
    loglik <- suppressWarnings(as.numeric(loglik)[1])
    npar_raw <- suppressWarnings(as.numeric(npar)[1])
    npar <- if (is.finite(npar_raw) && npar_raw >= 0 && abs(npar_raw - round(npar_raw)) <= sqrt(.Machine$double.eps)) {
        as.integer(round(npar_raw))
    }
    else {
        NA_integer_
    }
    method <- public_mfrm_method_label(toupper(as.character(method)[1]))
    dat <- prep$data %||% data.frame()
    response_rows <- if (is.data.frame(dat)) 
        nrow(dat)
    else NA_integer_
    weights <- if (is.data.frame(dat) && "Weight" %in% names(dat)) {
        suppressWarnings(as.numeric(dat$Weight))
    }
    else if (is.finite(response_rows) && response_rows >= 0L) {
        rep(1, response_rows)
    }
    else {
        numeric(0)
    }
    weighted_response_total <- if (length(weights) > 0L && all(is.finite(weights))) {
        sum(weights)
    }
    else {
        NA_real_
    }
    persons <- if (is.data.frame(dat) && "Person" %in% names(dat)) {
        person_values <- as.character(dat$Person)
        length(unique(person_values[!is.na(person_values)]))
    }
    else {
        suppressWarnings(as.integer(config$n_person %||% NA_integer_))
    }
    legacy_basis <- if (!is.null(config$weight_col)) 
        "sum_weights"
    else "row_count"
    legacy_n <- if (identical(legacy_basis, "sum_weights")) {
        weighted_response_total
    }
    else {
        as.numeric(response_rows)
    }
    deviance <- if (is.finite(loglik)) 
        -2 * loglik
    else NA_real_
    legacy_aic <- if (is.finite(deviance) && is.finite(npar)) {
        deviance + 2 * npar
    }
    else {
        NA_real_
    }
    legacy_bic <- if (is.finite(deviance) && is.finite(npar) && is.finite(legacy_n) && legacy_n > 0) {
        deviance + log(legacy_n) * npar
    }
    else {
        NA_real_
    }
    weight_policy <- mfrm_ic_weight_policy(prep, config)
    valid_likelihood_contract <- is.finite(deviance) && is.finite(npar) && npar >= 0L
    structural_eligible <- identical(method, "MML") && weight_policy %in% c("unweighted", "explicit_unit") && 
        is.finite(persons) && persons >= 1L && valid_likelihood_contract
    product_slopes <- !is.null(config$gpcm_spec$component_levels)
    if (product_slopes) {
        structural_eligible <- FALSE
        legacy_aic <- legacy_bic <- NA_real_
    }
    ic_status <- if (product_slopes) {
        "unsupported_product_slopes"
    }
    else if (!identical(method, "MML")) {
        "descriptive_jml"
    }
    else if (identical(weight_policy, "invalid")) {
        "invalid_weight_policy"
    }
    else if (!weight_policy %in% c("unweighted", "explicit_unit")) {
        "suppressed_nonunit_weight"
    }
    else if (!is.finite(persons) || persons < 1L) {
        "invalid_person_count"
    }
    else if (!valid_likelihood_contract) {
        "invalid_likelihood_contract"
    }
    else if (persons <= 22L) {
        "ok_sabic_nonpositive"
    }
    else {
        "ok"
    }
    ic_sample_size <- if (structural_eligible) 
        as.numeric(persons)
    else NA_real_
    ic_sample_size_basis <- if (structural_eligible) {
        "person_count"
    }
    else if (product_slopes) {
        "unsupported_product_slopes"
    }
    else if (!identical(method, "MML")) {
        "descriptive_jml"
    }
    else if (identical(weight_policy, "invalid")) {
        "invalid_weight_policy"
    }
    else if (!weight_policy %in% c("unweighted", "explicit_unit")) {
        "unsupported_nonunit_weights"
    }
    else if (!valid_likelihood_contract) {
        "invalid_likelihood_contract"
    }
    else {
        "invalid_person_count"
    }
    aic <- bic <- sabic <- NA_real_
    common_panel <- NULL
    if (structural_eligible) {
        common_panel <- mfrm_ic_common_panel(deviance, npar, persons)
        aic <- common_panel$AIC
        bic <- common_panel$BIC
        sabic <- common_panel$SABIC
    }
    formula_ids <- .mfrmr_const_mfrm_ic_formula_identifiers
    integration_policy <- mfrm_ic_integration_policy(method, config)
    ic_selectable <- isTRUE(structural_eligible) && isTRUE(integration_policy$Selectable)
    list(ICContractVersion = .mfrmr_const_mfrm_ic_contract_version, N = legacy_n, ResponseRows = as.integer(response_rows), 
        WeightedResponseTotal = as.numeric(weighted_response_total), Persons = as.integer(persons), Npar = as.integer(npar), 
        LogLik = as.numeric(loglik), Deviance = as.numeric(deviance), WeightPolicy = weight_policy, ICEligible = isTRUE(structural_eligible), 
        ICSelectable = ic_selectable, ICStatus = ic_status, ICSampleSize = ic_sample_size, ICSampleSizeBasis = ic_sample_size_basis, 
        AIC = as.numeric(aic), BIC = as.numeric(bic), SABIC = as.numeric(sabic), SABICSelectable = ic_selectable && 
            persons > 22L, AICFormula = unname(formula_ids[["AIC"]]), BICFormula = unname(formula_ids[["BIC"]]), 
        SABICFormula = unname(formula_ids[["SABIC"]]), IntegrationEvaluationId = mfrm_ic_integration_evaluation_id(method, 
            config), ICQuadraturePoints = integration_policy$QuadraturePoints, ICIntegrationTier = integration_policy$Tier, 
        ICIntegrationStatus = integration_policy$Status, ICIntegrationSelectable = isTRUE(integration_policy$Selectable), 
        LegacyAIC = as.numeric(legacy_aic), LegacyBIC = as.numeric(legacy_bic), LegacyICSampleSize = as.numeric(legacy_n), 
        LegacyICSampleSizeBasis = legacy_basis)
}

build_estimation_summary <- function(model, method, prep, config, sizes, opt, readiness_record = NULL) {
    k_params <- as.integer(sum(unlist(sizes)))
    retained_npar <- length(opt$par %||% numeric(0))
    if (!identical(k_params, as.integer(retained_npar))) {
        stop("Internal parameter-dimension mismatch: `sizes` imply ", k_params, " free coordinates, but the retained optimizer vector has ", 
            retained_npar, ".", call. = FALSE)
    }
    loglik <- -opt$value
    ic <- build_mfrm_ic_contract(loglik = loglik, npar = k_params, prep = prep, config = config, method = method)
    interaction_specs <- config$interaction_specs %||% list()
    interaction_count <- length(interaction_specs)
    interaction_params <- sum(vapply(interaction_specs, function(spec) {
        as.integer(spec$n_params %||% 0L)
    }, integer(1)))
    interaction_cells <- sum(vapply(interaction_specs, function(spec) {
        as.integer(spec$n_cells %||% 0L)
    }, integer(1)))
    interaction_sparse_cells <- sum(vapply(interaction_specs, function(spec) {
        as.integer(spec$sparse_count %||% 0L)
    }, integer(1)))
    facet_sample_flag <- NA_character_
    facet_sample_min_n <- NA_integer_
    facet_sample_sparse_count <- 0L
    if (!is.null(config$facet_names) && length(config$facet_names) > 0L && !is.null(prep$data) && nrow(prep$data) > 
        0L) {
        facet_min_ns <- vapply(config$facet_names, function(f) {
            if (!f %in% names(prep$data)) 
                return(NA_integer_)
            counts <- tabulate(as.integer(factor(prep$data[[f]])))
            if (length(counts) == 0L) 
                NA_integer_
            else as.integer(min(counts))
        }, integer(1))
        facet_sample_min_n <- suppressWarnings(min(facet_min_ns, na.rm = TRUE))
        if (!is.finite(facet_sample_min_n)) 
            facet_sample_min_n <- NA_integer_
        if (is.finite(facet_sample_min_n)) {
            facet_sample_flag <- if (facet_sample_min_n < 10L) 
                "sparse"
            else if (facet_sample_min_n < 30L) 
                "marginal"
            else if (facet_sample_min_n < 50L) 
                "standard"
            else "strong"
            facet_sample_sparse_count <- sum(facet_min_ns < 10L, na.rm = TRUE)
        }
    }
    optimizer_diag <- opt$optimizer_diagnostics %||% build_optimizer_diagnostics(opt = opt)
    optimizer_polish <- opt$optimizer_polish %||% list()
    mml_engine <- opt$mml_engine %||% list()
    mml_used <- if (identical(method, "MML")) {
        as.character(mml_engine$Used %||% config$estimation_control$mml_engine_used %||% "direct")
    }
    else {
        NA_character_
    }
    iterations <- if (identical(method, "MML") && identical(mml_used, "em")) {
        as.integer(mml_engine$EMIterations %||% optimizer_diag$FunctionEvaluations)
    }
    else {
        optimizer_diag$FunctionEvaluations
    }
    iterations_basis <- if (identical(method, "MML") && identical(mml_used, "em")) {
        "em_iterations"
    }
    else {
        "function_evaluations"
    }
    fit_readiness <- as.data.frame(readiness_record$fit %||% data.frame(), stringsAsFactors = FALSE)
    component_readiness <- as.data.frame(readiness_record$components %||% data.frame(), stringsAsFactors = FALSE)
    boundary_readiness <- if (nrow(component_readiness) > 0L && all(c("Component", "State") %in% names(component_readiness))) {
        component_readiness[component_readiness$Component == "boundary", , drop = FALSE]
    }
    else {
        as.data.frame(config$boundary_audit$readiness %||% data.frame(), stringsAsFactors = FALSE)
    }
    boundary_state <- if (nrow(fit_readiness) > 0L && "BoundaryState" %in% names(fit_readiness)) {
        as.character(fit_readiness$BoundaryState[1])
    }
    else if (nrow(boundary_readiness) > 0L && "BoundaryState" %in% names(boundary_readiness)) {
        as.character(boundary_readiness$BoundaryState[1])
    }
    else if (nrow(boundary_readiness) > 0L && "State" %in% names(boundary_readiness)) {
        as.character(boundary_readiness$State[1])
    }
    else {
        "not_evaluated"
    }
    boundary_reasons <- if (nrow(boundary_readiness) > 0L && "ReasonCodes" %in% names(boundary_readiness)) {
        as.character(boundary_readiness$ReasonCodes[1])
    }
    else {
        ""
    }
    readiness_value <- function(field, default) {
        if (nrow(fit_readiness) > 0L && field %in% names(fit_readiness)) {
            fit_readiness[[field]][1]
        }
        else {
            default
        }
    }
    tibble(Model = model, Method = public_mfrm_method_label(method), MethodUsed = method, MMLIntegration = if (identical(method, 
        "MML")) {
        config$estimation_control$mml_integration %||% "fixed"
    }
    else "not_applicable_jml", MMLAccuracyStatus = config$mml_accuracy$status %||% "not_requested", ICContractVersion = ic$ICContractVersion, 
        N = ic$N, ResponseRows = ic$ResponseRows, WeightedResponseTotal = ic$WeightedResponseTotal, Persons = ic$Persons, 
        Npar = ic$Npar, Facets = length(config$facet_names), FacetInteractions = interaction_count, InteractionParameters = interaction_params, 
        InteractionCells = interaction_cells, InteractionSparseCells = interaction_sparse_cells, Categories = config$n_cat, 
        LogLik = ic$LogLik, Deviance = ic$Deviance, WeightPolicy = ic$WeightPolicy, ICEligible = ic$ICEligible, 
        ICSelectable = ic$ICSelectable, ICStatus = ic$ICStatus, ICSampleSize = ic$ICSampleSize, ICSampleSizeBasis = ic$ICSampleSizeBasis, 
        AIC = ic$AIC, BIC = ic$BIC, SABIC = ic$SABIC, SABICSelectable = ic$SABICSelectable, AICFormula = ic$AICFormula, 
        BICFormula = ic$BICFormula, SABICFormula = ic$SABICFormula, IntegrationEvaluationId = ic$IntegrationEvaluationId, 
        ICQuadraturePoints = ic$ICQuadraturePoints, ICIntegrationTier = ic$ICIntegrationTier, ICIntegrationStatus = ic$ICIntegrationStatus, 
        ICIntegrationSelectable = ic$ICIntegrationSelectable, LegacyAIC = ic$LegacyAIC, LegacyBIC = ic$LegacyBIC, 
        LegacyICSampleSize = ic$LegacyICSampleSize, LegacyICSampleSizeBasis = ic$LegacyICSampleSizeBasis, 
        Converged = opt$convergence == 0, ReadinessContractVersion = as.character(readiness_value("ReadinessContractVersion", 
            NA_character_)), FitReadiness = as.character(readiness_value("FitReadiness", if (identical(optimizer_diag$ConvergenceSeverity, 
            "pass") && boundary_state == "finite") "ready" else "review")), InferenceReady = as.logical(readiness_value("InferenceReady", 
            identical(optimizer_diag$ConvergenceSeverity, "pass") && boundary_state == "finite")), InputState = as.character(readiness_value("InputState", 
            NA_character_)), EstimabilityState = as.character(readiness_value("EstimabilityState", NA_character_)), 
        CategoryState = as.character(readiness_value("CategoryState", NA_character_)), BoundaryState = boundary_state, 
        NumericalState = as.character(readiness_value("NumericalState", NA_character_)), ReadinessReasonCodes = as.character(readiness_value("ReasonCodes", 
            "")), ReadinessAuditProvenance = as.character(readiness_value("AuditProvenance", "")), BoundaryReasonCodes = boundary_reasons, 
        Iterations = iterations, IterationsBasis = iterations_basis, MMLEngineRequested = if (identical(method, 
            "MML")) {
            as.character(mml_engine$Requested %||% config$estimation_control$mml_engine_requested %||% 
                "direct")
        }
        else {
            NA_character_
        }, MMLEngineUsed = mml_used, MMLEngineDetail = if (identical(method, "MML")) {
            as.character(mml_engine$Detail %||% NA_character_)
        }
        else {
            NA_character_
        }, EMIterations = if (identical(method, "MML")) {
            as.integer(mml_engine$EMIterations %||% NA_integer_)
        }
        else {
            NA_integer_
        }, EMConverged = if (identical(method, "MML")) {
            as.logical(mml_engine$EMConverged %||% NA)
        }
        else {
            NA
        }, EMRelativeChange = if (identical(method, "MML")) {
            as.numeric(mml_engine$EMRelativeChange %||% NA_real_)
        }
        else {
            NA_real_
        }, OptimizerMethod = optimizer_diag$OptimizerMethod, OptimizerInitialMethod = as.character(optimizer_polish$InitialMethod %||% 
            optimizer_diag$OptimizerMethod), OptimizerPolished = isTRUE(optimizer_polish$Triggered), 
        OptimizerPolishSucceeded = isTRUE(optimizer_polish$Succeeded), OptimizerPolishStages = if (isTRUE(optimizer_polish$Triggered)) {
            max(0L, nrow(as.data.frame(optimizer_polish$Stages %||% data.frame())) - 1L)
        }
        else {
            0L
        }, RequestedReltol = as.numeric(optimizer_polish$RequestedReltol %||% optimizer_diag$RequestedReltol %||% 
            NA_real_), EffectiveReltol = as.numeric(optimizer_polish$EffectiveReltol %||% optimizer_diag$EffectiveReltol %||% 
            config$estimation_control$reltol %||% NA_real_), OptimizerFactr = as.numeric(optimizer_polish$EffectiveFactr %||% 
            optimizer_diag$OptimizerFactr %||% NA_real_), OptimizerPgtol = as.numeric(optimizer_polish$EffectivePgtol %||% 
            optimizer_diag$OptimizerPgtol %||% NA_real_), InitialTerminalGradientSupNorm = as.numeric(optimizer_polish$InitialTerminalGradientSupNorm %||% 
            optimizer_diag$TerminalGradientSupNorm), ConvergenceCode = optimizer_diag$ConvergenceCode, 
        ConvergenceBasis = optimizer_diag$ConvergenceBasis, ConvergenceStatus = optimizer_diag$ConvergenceStatus, 
        ConvergenceReason = optimizer_diag$ConvergenceReason, ConvergenceSeverity = optimizer_diag$ConvergenceSeverity, 
        ConvergenceMessage = optimizer_diag$ConvergenceMessage, ConvergenceDetail = optimizer_diag$ConvergenceDetail, 
        ReviewableWarning = optimizer_diag$ReviewableWarning, GradientReviewTolerance = optimizer_diag$GradientReviewTolerance, 
        FunctionEvaluations = optimizer_diag$FunctionEvaluations, GradientEvaluations = optimizer_diag$GradientEvaluations, 
        TerminalGradientSupNorm = optimizer_diag$TerminalGradientSupNorm, TerminalGradientRMS = optimizer_diag$TerminalGradientRMS, 
        FacetSampleSizeFlag = facet_sample_flag, FacetMinLevelN = facet_sample_min_n, FacetSparseCount = facet_sample_sparse_count, 
        ExtremeHighN = .count_extreme_persons(prep, which = "high"), ExtremeLowN = .count_extreme_persons(prep, 
            which = "low"))
}

.count_extreme_persons <- function(prep, which = c("high", "low")) {
    which <- match.arg(which)
    flag <- .flag_extreme_persons(prep, rating_min = prep$rating_min, rating_max = prep$rating_max)
    as.integer(sum(flag == which, na.rm = TRUE))
}

build_mfrm_data_review <- function(prep, anchors = NULL, group_anchors = NULL, estimability_audit = NULL, 
    category_support_audit = NULL) {
    facet_names <- as.character(prep$facet_names %||% character(0))
    subset_tables <- calc_subsets(prep$data, c("Person", facet_names))
    subset_summary <- as.data.frame(subset_tables$summary %||% data.frame(), stringsAsFactors = FALSE)
    subset_nodes <- as.data.frame(subset_tables$nodes %||% data.frame(), stringsAsFactors = FALSE)
    subset_count <- if (nrow(subset_summary) > 0L) 
        nrow(subset_summary)
    else NA_integer_
    anchors_present <- nrow(as.data.frame(anchors %||% data.frame())) > 0L || nrow(as.data.frame(group_anchors %||% 
        data.frame())) > 0L
    support <- if (length(facet_names) == 0L) {
        data.frame()
    }
    else {
        dplyr::bind_rows(lapply(facet_names, function(facet) {
            dplyr::mutate(dplyr::summarise(dplyr::group_by(prep$data, Level = as.character(.data[[facet]])), 
                Observations = dplyr::n(), WeightedN = sum(.data$Weight, na.rm = TRUE), DistinctScores = dplyr::n_distinct(.data$Score), 
                MinScore = min(.data$Score, na.rm = TRUE), MaxScore = max(.data$Score, na.rm = TRUE), 
                .groups = "drop"), Facet = facet, ConstantScore = .data$DistinctScores <= 1L, BoundaryConstant = .data$ConstantScore & 
                (.data$MinScore == prep$rating_min | .data$MaxScore == prep$rating_max), .before = 1L)
        }))
    }
    boundary_levels <- if (nrow(support) > 0L) {
        support[as.logical(support$BoundaryConstant), , drop = FALSE]
    }
    else {
        data.frame()
    }
    single_level_facets <- facet_names[vapply(facet_names, function(facet) {
        length(unique(as.character(prep$data[[facet]]))) <= 1L
    }, logical(1))]
    prep_notes <- as.data.frame(prep$preparation_notes %||% data.frame(), stringsAsFactors = FALSE)
    prep_review <- if (nrow(prep_notes) > 0L && "Severity" %in% names(prep_notes)) {
        tolower(as.character(prep_notes$Severity)) %in% c("review", "warning", "error")
    }
    else {
        logical(0)
    }
    design_status <- if (is.finite(subset_count) && subset_count > 1L) {
        if (isTRUE(anchors_present)) 
            "review_disconnected_with_anchors"
        else "hold_disconnected"
    }
    else if (identical(subset_count, 1L)) {
        "pass_linked"
    }
    else {
        "review_not_assessed"
    }
    estimability_state <- as.character(estimability_audit$readiness$EstimabilityState[1] %||% NA_character_)
    if (identical(design_status, "pass_linked") && identical(estimability_state, "population_assumption_linked")) {
        design_status <- "review_population_assumption_linked"
    }
    else if (identical(design_status, "pass_linked") && identical(estimability_state, "weak_information")) {
        design_status <- "review_weak_estimability"
    }
    stability_status <- if (nrow(boundary_levels) > 0L) {
        "hold_boundary_separation"
    }
    else if (length(single_level_facets) > 0L) {
        "hold_single_level_facet"
    }
    else {
        "pass"
    }
    data_status <- if (any(prep_review)) 
        "review"
    else "pass"
    reporting_status <- if (startsWith(design_status, "hold_")) {
        "hold_design"
    }
    else if (startsWith(stability_status, "hold_")) {
        "hold_stability"
    }
    else if (!identical(data_status, "pass") || startsWith(design_status, "review_")) {
        "review"
    }
    else {
        "ready_for_diagnostics"
    }
    list(status = data.frame(Domain = c("Data", "Design", "Stability", "Reporting"), Status = c(data_status, 
        design_status, stability_status, reporting_status), stringsAsFactors = FALSE), overall_connectivity = list(summary = subset_summary, 
        nodes = subset_nodes, components = subset_count, connected = identical(subset_count, 1L), anchors_present = isTRUE(anchors_present)), 
        facet_support = as.data.frame(support, stringsAsFactors = FALSE), boundary_levels = as.data.frame(boundary_levels, 
            stringsAsFactors = FALSE), single_level_facets = single_level_facets, preparation_notes = prep_notes, 
        estimability = estimability_audit, category_support = category_support_audit)
}

prepare_mfrm_estimation_structure <- function(data = NULL, person_col = NULL, facet_cols = NULL, score_col = NULL, 
    rating_min = NULL, rating_max = NULL, weight_col = NULL, keep_original = FALSE, missing_codes = NULL, 
    model = c("RSM", "PCM", "GPCM"), method = c("JML", "MML"), step_facet = NULL, slope_facet = NULL, 
    facet_interactions = NULL, min_obs_per_interaction = 10, interaction_policy = c("warn", "error", 
        "silent"), anchor_df = NULL, group_anchor_df = NULL, noncenter_facet = "Person", dummy_facets = character(0), 
    positive_facets = character(0), population = NULL, quad_points = 15, maxit = 400, reltol = 1e-09, 
    optimizer = "auto", mml_engine = "direct", checkpoint = NULL, mml_integration = "fixed", repeated_ratings = c("review", 
        "independent"), centering_scope = "remainder", prep = NULL, anchor_review = NULL, constraint_specs = NULL, 
    phase_clock = function() NULL, phase_finish = function(...) invisible(NULL), step_constraints = NULL) {
    phase_started <- phase_clock()
    model <- match.arg(model)
    method <- match.arg(method)
    interaction_policy <- match.arg(interaction_policy)
    allow_single_person <- model %in% c("RSM", "PCM") && (method == "JML" || !isTRUE(population$active))
    if (is.null(prep)) {
        prep <- prepare_mfrm_data(data, person_col = person_col, facet_cols = facet_cols, score_col = score_col, 
            rating_min = rating_min, rating_max = rating_max, weight_col = weight_col, keep_original = keep_original, 
            missing_codes = missing_codes, repeated_ratings = repeated_ratings, allow_single_person = allow_single_person)
    }
    else {
        validate_mfrm_single_person_support(length(prep$levels$Person), allow_single_person = allow_single_person)
    }
    phase_finish("prepare_data", phase_started, "input normalization and retained data")
    phase_started <- phase_clock()
    resolved_families <- resolve_step_and_slope_facets(model = model, step_facet = step_facet, slope_facet = slope_facet, 
        facet_names = prep$facet_names, method = method)
    step_facet <- resolved_families$step_facet
    slope_facet <- resolved_families$slope_facet
    noncenter_facet <- sanitize_noncenter_facet(noncenter_facet, prep$facet_names)
    dummy_facets <- sanitize_dummy_facets(dummy_facets, prep$facet_names)
    sign_info <- build_facet_signs(prep$facet_names, positive_facets)
    if (!is.null(facet_interactions) && length(facet_interactions) > 0L && identical(model, "GPCM")) {
        stop("`facet_interactions` currently supports only `model = \"RSM\"` or ", "`model = \"PCM\"`. Re-fit without interactions or use a Rasch-family ", 
            "model before extending the `GPCM` branch.", call. = FALSE)
    }
    interaction_specs <- build_facet_interaction_specs(prep = prep, facet_interactions = facet_interactions, 
        min_obs_per_interaction = min_obs_per_interaction, interaction_policy = interaction_policy)
    phase_finish("resolve_structure", phase_started, "model and active structure")
    phase_started <- phase_clock()
    idx <- build_indices(prep, step_facet = step_facet, slope_facet = slope_facet, interaction_specs = interaction_specs)
    cfg <- build_estimation_config(prep = prep, model = model, method = method, step_facet = step_facet, 
        slope_facet = slope_facet, interaction_specs = interaction_specs, weight_col = weight_col, facet_signs = sign_info$signs, 
        positive_facets = sign_info$positive_facets, noncenter_facet = noncenter_facet, dummy_facets = dummy_facets, 
        anchor_df = anchor_df, group_anchor_df = group_anchor_df, population = population, centering_scope = centering_scope, 
        anchor_review = anchor_review, constraint_specs = constraint_specs, step_constraints = step_constraints)
    config <- cfg$config
    if (isTRUE(population$active) && !identical(noncenter_facet, "Person")) {
        if (!any(is.finite(config$facet_specs[[noncenter_facet]]$anchors)) || length(config$dummy_facets)) 
            stop("Anchor-origin population estimation requires a retained direct anchor on `noncenter_facet`, without dummy facets.", 
                call. = FALSE)
    }
    config$step_facet_source <- resolved_families$step_facet_source
    config$step_facet_note <- resolved_families$step_facet_note
    integration_requested <- match.arg(mml_integration, c("fixed", "adaptive", "auto"))
    if (integration_requested == "auto" && (method != "MML" || mml_engine != "direct" || !is.null(checkpoint))) {
        stop("Automatic integration requires direct MML without a checkpoint.", call. = FALSE)
    }
    config$estimation_control <- list(maxit = as.integer(maxit), reltol = as.numeric(reltol), quad_points = as.integer(quad_points), 
        mml_integration = if (integration_requested == "auto") "fixed" else integration_requested, optimizer_requested = normalize_mfrm_optimizer(optimizer), 
        mml_engine_requested = normalize_mml_engine(mml_engine), checkpoint = checkpoint)
    sizes <- cfg$sizes
    start <- build_initial_param_vector(config, sizes)
    phase_finish("build_design_config", phase_started, "indices, constraints, and starting values")
    phase_started <- phase_clock()
    category_support_audit <- audit_mfrm_category_support(prep = prep, config = config, sizes = sizes)
    phase_finish("category_support_audit", phase_started, "pre-fit category support")
    phase_started <- phase_clock()
    estimability_audit <- audit_mfrm_estimability(prep = prep, idx = idx, config = config, sizes = sizes)
    phase_finish("estimability_audit", phase_started, "pre-fit constrained estimability")
    phase_started <- phase_clock()
    config$category_support_audit <- category_support_audit
    config$estimability_audit <- estimability_audit
    data_review <- build_mfrm_data_review(prep = prep, anchors = anchor_df, group_anchors = group_anchor_df, 
        estimability_audit = estimability_audit, category_support_audit = category_support_audit)
    estimability_state <- as.character(estimability_audit$readiness$EstimabilityState[1] %||% NA_character_)
    if (identical(estimability_state, "structurally_unidentified")) {
        mfrmr_stop_unidentified(estimability_audit)
    }
    category_state <- as.character(category_support_audit$readiness$CategoryState[1] %||% NA_character_)
    if (identical(category_state, "unsupported_coordinate")) {
        mfrmr_stop_unsupported_category(category_support_audit)
    }
    mfrmr_check_extreme_person_anchor_origin(prep, config)
    if (prep$n_person == 1L) {
        adjacent <- mfrmr_estimability_adjacent_design(prep, idx, config, sizes, include_person = method == 
            "JML", include_population_beta = FALSE)
        boundary <- mfrmr_additive_response_boundary(adjacent, idx, config)
        config$single_person_boundary <- boundary
        if (boundary$state != "no_recession_detected") 
            stop("One-Person calibration finite-MLE check: ", boundary$state, ". ", boundary$reason %||% 
                "", " No finite point estimate or Wald interval is returned.", call. = FALSE)
    }
    if (estimability_state %in% c("population_assumption_linked", "weak_information")) {
        mfrmr_warn_estimability(estimability_audit)
    }
    if (identical(category_state, "weak_information")) {
        mfrmr_warn_category_support(category_support_audit)
    }
    design_status <- data_review$status$Status[match("Design", data_review$status$Domain)]
    stability_status <- data_review$status$Status[match("Stability", data_review$status$Domain)]
    if (startsWith(design_status, "hold_")) {
        warning("The observed measurement design contains ", data_review$overall_connectivity$components, 
            " disconnected subset(s). Numerical estimation can continue, but ", "cross-subset comparisons are not design-linked and reporting remains ", 
            "on hold until the design or an external linking justification is reviewed.", call. = FALSE)
    }
    else if (identical(design_status, "review_disconnected_with_anchors")) {
        warning("The observed measurement design is disconnected and includes supplied ", "anchors. Review whether those anchors justify cross-subset comparisons ", 
            "before reporting.", call. = FALSE)
    }
    if (startsWith(stability_status, "hold_")) {
        warning("Boundary-constant or single-level facet support was detected. The model ", "may return a small terminal gradient while one or more facet estimates ", 
            "remain weakly identified or separated; reporting is on hold pending ", "the structured data-support review in `fit$data_review`.", 
            call. = FALSE)
    }
    phase_finish("data_review_and_guards", phase_started, "pre-fit review assembly and fail-closed guards")
    list(model = model, method = method, prep = prep, idx = idx, config = config, sizes = sizes, start = start, 
        integration_requested = integration_requested, category_support_audit = category_support_audit, 
        estimability_audit = estimability_audit, data_review = data_review)
}

mfrm_estimate <- function(data, person_col, facet_cols, score_col, rating_min = NULL, rating_max = NULL, 
    weight_col = NULL, keep_original = FALSE, missing_codes = NULL, model = c("RSM", "PCM", "GPCM"), 
    method = c("JML", "MML"), step_facet = NULL, slope_facet = NULL, facet_interactions = NULL, min_obs_per_interaction = 10, 
    interaction_policy = c("warn", "error", "silent"), anchor_df = NULL, group_anchor_df = NULL, noncenter_facet = "Person", 
    dummy_facets = character(0), positive_facets = character(0), population = NULL, quad_points = 15, 
    maxit = 400, reltol = 1e-09, optimizer = "auto", mml_engine = "direct", checkpoint = NULL, mml_integration = "fixed", 
    repeated_ratings = c("review", "independent"), centering_scope = "remainder", mml_accuracy_control = NULL, 
    mml_starts = NULL, prep = NULL, anchor_review = NULL, constraint_specs = NULL, step_constraints = NULL) {
    phase_timing_enabled <- isTRUE(getOption("mfrmr.phase_timing", FALSE))
    phase_timing_rows <- list()
    phase_clock <- function() {
        if (!phase_timing_enabled) 
            return(NULL)
        unname(proc.time()[["elapsed"]])
    }
    phase_finish <- function(phase, started, scope) {
        if (!phase_timing_enabled) 
            return(invisible(NULL))
        phase_timing_rows[[length(phase_timing_rows) + 1L]] <<- data.frame(Phase = as.character(phase), 
            ElapsedSeconds = max(0, phase_clock() - started), Clock = "proc.time.elapsed", Scope = as.character(scope), 
            DecisionUse = "diagnostic_only", stringsAsFactors = FALSE)
        invisible(NULL)
    }
    estimation_started <- phase_clock()
    structure_bundle <- prepare_mfrm_estimation_structure(data = data, person_col = person_col, facet_cols = facet_cols, 
        score_col = score_col, rating_min = rating_min, rating_max = rating_max, weight_col = weight_col, 
        keep_original = keep_original, missing_codes = missing_codes, model = model, method = method, 
        step_facet = step_facet, slope_facet = slope_facet, facet_interactions = facet_interactions, 
        min_obs_per_interaction = min_obs_per_interaction, interaction_policy = interaction_policy, anchor_df = anchor_df, 
        group_anchor_df = group_anchor_df, noncenter_facet = noncenter_facet, dummy_facets = dummy_facets, 
        positive_facets = positive_facets, population = population, quad_points = quad_points, maxit = maxit, 
        reltol = reltol, optimizer = optimizer, mml_engine = mml_engine, checkpoint = checkpoint, mml_integration = mml_integration, 
        repeated_ratings = repeated_ratings, centering_scope = centering_scope, prep = prep, anchor_review = anchor_review, 
        constraint_specs = constraint_specs, phase_clock = phase_clock, phase_finish = phase_finish, 
        step_constraints = step_constraints)
    model <- structure_bundle$model
    method <- structure_bundle$method
    prep <- structure_bundle$prep
    idx <- structure_bundle$idx
    config <- structure_bundle$config
    sizes <- structure_bundle$sizes
    start <- structure_bundle$start
    integration_requested <- structure_bundle$integration_requested
    category_support_audit <- structure_bundle$category_support_audit
    estimability_audit <- structure_bundle$estimability_audit
    data_review <- structure_bundle$data_review
    population_boundary <- mfrmr_mml_population_boundary(prep, config)
    if (!is.null(population_boundary)) 
        stop(population_boundary$reason, call. = FALSE)
    phase_started <- phase_clock()
    if (integration_requested == "auto") {
        refined <- mfrmr_optimize_accuracy_mml(start, idx, config, sizes, prep$levels$Person, maxit, 
            reltol, config$estimation_control$optimizer_requested, mfrmr_mml_accuracy_control(mml_accuracy_control))
        opt <- refined$opt
        config <- refined$config
        config$estimation_control$mml_integration_requested <- "auto"
        config$estimation_control$quad_points_requested <- as.integer(quad_points)
        quad_points <- config$estimation_control$quad_points
    }
    else if (!is.null(mml_starts)) {
        opt <- mfrmr_run_mml_starts(start, mml_starts, prep, idx, config, sizes, quad_points, maxit, 
            reltol, config$estimation_control$optimizer_requested)
    }
    else {
        opt <- run_mfrm_optimization(start = start, method = method, idx = idx, config = config, sizes = sizes, 
            quad_points = quad_points, maxit = maxit, reltol = reltol, optimizer = config$estimation_control$optimizer_requested, 
            checkpoint = config$estimation_control$checkpoint)
    }
    optimizer_stage_parameters <- opt$optimizer_stage_parameters %||% matrix(numeric(0), nrow = 0L, ncol = length(opt$par %||% 
        numeric(0)))
    opt$optimizer_stage_parameters <- NULL
    phase_finish("optimization", phase_started, "objective evaluation and optimizer")
    config$estimation_control$optimizer_used <- as.character(opt$optimizer_plan$Used %||% opt$optimizer_diagnostics$OptimizerMethod %||% 
        NA_character_)
    config$estimation_control$optimizer_initial <- as.character(opt$optimizer_plan$InitialUsed %||% config$estimation_control$optimizer_used)
    config$estimation_control$optimizer_polish <- opt$optimizer_polish %||% list(Triggered = FALSE, Succeeded = FALSE, 
        RequestedReltol = as.numeric(reltol), EffectiveReltol = as.numeric(reltol), EffectiveFactr = NA_real_, 
        EffectivePgtol = NA_real_, Stages = data.frame())
    config$estimation_control$effective_reltol <- as.numeric(opt$optimizer_diagnostics$EffectiveReltol %||% 
        reltol)
    config$estimation_control$optimizer_factr <- as.numeric(opt$optimizer_diagnostics$OptimizerFactr %||% 
        NA_real_)
    config$estimation_control$optimizer_pgtol <- as.numeric(opt$optimizer_diagnostics$OptimizerPgtol %||% 
        NA_real_)
    config$estimation_control$mml_engine_used <- as.character(opt$mml_engine$Used %||% NA_character_)
    config$estimation_control$mml_engine_detail <- as.character(opt$mml_engine$Detail %||% NA_character_)
    phase_started <- phase_clock()
    if (identical(config$method, "MML") && length(estimability_audit$nonlinear_blocks %||% character(0)) > 
        0L) {
        estimability_audit$mml_observed_pattern_score <- audit_mfrm_mml_observed_pattern_score(opt = opt, 
            prep = prep, idx = idx, config = config, sizes = sizes, quad_points = quad_points, nonlinear_blocks = estimability_audit$nonlinear_blocks)
        estimability_audit$mml_all_pattern_information <- audit_mfrm_mml_all_pattern_information(opt = opt, 
            prep = prep, idx = idx, config = config, sizes = sizes, quad_points = quad_points, nonlinear_blocks = estimability_audit$nonlinear_blocks)
        config$estimability_audit <- estimability_audit
        data_review$estimability <- estimability_audit
    }
    if (identical(config$model, "GPCM")) {
        estimability_audit$gpcm_response_kernel <- audit_mfrm_gpcm_response_kernel(prep = prep, idx = idx, 
            config = config, sizes = sizes, par = opt$par)
        config$estimability_audit <- estimability_audit
        data_review$estimability <- estimability_audit
    }
    if (length(estimability_audit$nonlinear_blocks %||% character(0)) > 0L) {
        estimability_audit$nonlinear_transformation <- mfrmr_nonlinear_transformation_audit(par = opt$par, 
            sizes = sizes, config = config, nonlinear_blocks = estimability_audit$nonlinear_blocks)
        estimability_audit$fitted_information <- audit_mfrm_fitted_information(opt = opt, idx = idx, 
            config = config, sizes = sizes, quad_points = quad_points, nonlinear_blocks = estimability_audit$nonlinear_blocks)
        config$estimability_audit <- estimability_audit
        data_review$estimability <- estimability_audit
    }
    estimability_audit$nonlinear_local_estimability <- mfrmr_classify_nonlinear_local_estimability(audit = estimability_audit, 
        config = config)
    config$estimability_audit <- estimability_audit
    data_review$estimability <- estimability_audit
    phase_finish("post_optimization_audits", phase_started, "nonlinear score, kernel, transformation, and information audits")
    phase_started <- phase_clock()
    params <- expand_params(opt$par, sizes, config)
    person_tbl <- build_person_table(method, idx, config, params, prep, quad_points)
    phase_finish("parameter_and_person_tables", phase_started, "parameter expansion and person summaries")
    phase_started <- phase_clock()
    boundary_audit <- audit_mfrm_person_boundary(person_table = person_tbl, config = config, prep = prep)
    phase_finish("person_boundary_audit", phase_started, "person extreme-score and boundary state")
    phase_started <- phase_clock()
    shared_recession_geometry <- NULL
    if (identical(config$method, "JML") && requireNamespace("lpSolve", quietly = TRUE)) {
        shared_candidate <- mfrmr_jml_recession_shared_geometry(prep = prep, idx = idx, config = config, 
            sizes = sizes, params = params)
        if (isTRUE(shared_candidate$ready)) {
            shared_recession_geometry <- shared_candidate
        }
    }
    boundary_audit$structural_additive <- audit_mfrm_jml_structural_recession(prep = prep, idx = idx, 
        config = config, sizes = sizes, params = params, shared_geometry = shared_recession_geometry)
    phase_finish("structural_recession_audit", phase_started, "additive structural recession directions")
    phase_started <- phase_clock()
    boundary_audit$joint_additive <- audit_mfrm_jml_joint_recession(prep = prep, idx = idx, config = config, 
        sizes = sizes, params = params, person_boundary_audit = boundary_audit, shared_geometry = shared_recession_geometry)
    phase_finish("joint_recession_audit", phase_started, "joint additive recession directions")
    if (identical(config$centering_scope, "anchor_origin")) {
        targets <- boundary_audit$joint_additive$target_status
        structural_boundary <- !is.null(targets) && nrow(targets) > 0L && any(targets$ParameterClass != 
            "person" & targets$CandidateStatus %in% c("unbounded_low", "unbounded_high", "unbounded_both"))
        if (isTRUE(structural_boundary)) {
            stop("`centering_scope = 'anchor_origin'` has a detected joint additive recession direction affecting calibration. No finite joint maximum is available under these anchors; review anchor support and constraints.", 
                call. = FALSE)
        }
    }
    phase_started <- phase_clock()
    boundary_audit$gpcm_slope_boundary <- if (identical(method, "MML")) {
        audit_mfrm_mml_gpcm_slope_boundary(prep = prep, idx = idx, config = config, sizes = sizes, par = opt$par, 
            quad_points = quad_points)
    }
    else {
        audit_mfrm_jml_gpcm_slope_boundary(prep = prep, idx = idx, config = config, sizes = sizes, par = opt$par)
    }
    phase_finish("gpcm_slope_boundary_audit", phase_started, if (identical(method, "MML")) {
        "fixed-quadrature marginal GPCM slope-only boundary directions"
    }
    else {
        "conditional JML GPCM slope-only boundary directions"
    })
    phase_started <- phase_clock()
    boundary_audit$gpcm_joint_boundary <- audit_mfrm_jml_gpcm_joint_boundary(prep = prep, idx = idx, 
        config = config, sizes = sizes, par = opt$par)
    phase_finish("gpcm_joint_boundary_audit", phase_started, "GPCM joint additive-slope boundary directions")
    if (identical(method, "JML") && identical(model, "GPCM")) {
        boundary_audit$gpcm_fixed_objective_classification <- mfrmr_classify_jml_gpcm_fixed_objective_boundary(config = config, 
            slope_audit = boundary_audit$gpcm_slope_boundary, joint_audit = boundary_audit$gpcm_joint_boundary)
        boundary_audit$gpcm_asymptotically_affine_transport <- audit_mfrm_jml_gpcm_asymptotically_affine_transport(config = config, 
            slope_audit = boundary_audit$gpcm_slope_boundary, joint_audit = boundary_audit$gpcm_joint_boundary, 
            boundary_classification = boundary_audit$gpcm_fixed_objective_classification)
        boundary_audit$gpcm_boundary_compactification <- audit_mfrm_jml_gpcm_boundary_compactification(config = config, 
            sizes = sizes, boundary_classification = boundary_audit$gpcm_fixed_objective_classification, 
            affine_transport = boundary_audit$gpcm_asymptotically_affine_transport)
        boundary_audit$gpcm_rate_hierarchy <- audit_mfrm_jml_gpcm_rate_hierarchy_scope(config = config, 
            sizes = sizes, compactification = boundary_audit$gpcm_boundary_compactification)
        boundary_audit$gpcm_lexicographic_limit <- audit_mfrm_jml_gpcm_lexicographic_limit_scope(config = config, 
            sizes = sizes, rate_hierarchy = boundary_audit$gpcm_rate_hierarchy)
        boundary_audit$gpcm_parameter_path_reachability <- audit_mfrm_jml_gpcm_parameter_path_scope(prep = prep, 
            idx = idx, config = config, sizes = sizes, lexicographic_limit = boundary_audit$gpcm_lexicographic_limit)
        boundary_audit$gpcm_optimizer_sequence_diagnostic <- audit_mfrm_jml_gpcm_optimizer_sequence_scope(config = config, 
            sizes = sizes, stages = opt$optimizer_polish$Stages %||% data.frame(), parameter_sequence = optimizer_stage_parameters, 
            parameter_path = boundary_audit$gpcm_parameter_path_reachability)
        boundary_audit$gpcm_parameter_sequence_flag <- audit_mfrm_jml_gpcm_parameter_sequence_flag_scope(config = config, 
            sizes = sizes, n_observations = length(idx$score_k), n_categories = config$n_cat, compactification = boundary_audit$gpcm_boundary_compactification, 
            sequence_diagnostic = boundary_audit$gpcm_optimizer_sequence_diagnostic)
        boundary_audit$gpcm_global_existence <- audit_mfrm_jml_gpcm_global_existence(config = config, 
            person_boundary = boundary_audit, joint_additive = boundary_audit$joint_additive, parameter_sequence_flag = boundary_audit$gpcm_parameter_sequence_flag, 
            slope_boundary = boundary_audit$gpcm_slope_boundary, joint_slope_boundary = boundary_audit$gpcm_joint_boundary, 
            retained_log_likelihood = -as.numeric(opt$value))
        canonical_zero_utility_center_certified <- tryCatch({
            zero_kernel <- mfrmr_gpcm_response_kernel_design(prep = prep, idx = idx, config = config, 
                sizes = sizes, par = rep(0, length(opt$par)))
            offset <- as.numeric(zero_kernel$eta_minus_step)
            length(offset) == zero_kernel$transition_rows && all(is.finite(offset)) && all(offset == 
                0)
        }, error = function(e) FALSE)
        boundary_audit$gpcm_exponential_balance <- audit_mfrm_jml_gpcm_exponential_balance_scope(config = config, 
            sizes = sizes, parameter_sequence_flag = boundary_audit$gpcm_parameter_sequence_flag, global_existence = boundary_audit$gpcm_global_existence, 
            canonical_zero_utility_center_certified = canonical_zero_utility_center_certified)
        boundary_audit$gpcm_terminal_gradient_stability <- audit_mfrm_jml_gpcm_terminal_gradient(idx = idx, 
            config = config, sizes = sizes, par = opt$par, opt = opt, boundary_classification = boundary_audit$gpcm_fixed_objective_classification)
    }
    phase_started <- phase_clock()
    person_tbl <- apply_mfrm_person_boundary(person_tbl, boundary_audit)
    config$boundary_audit <- boundary_audit
    data_review$boundary <- boundary_audit
    phase_finish("boundary_application", phase_started, "apply boundary states to returned objects")
    phase_started <- phase_clock()
    slope_tbl <- build_slope_table(config, prep, params)
    readiness_record <- build_mfrm_readiness_record(prep = prep, data_review = data_review, config = config, 
        opt = opt, slope_table = slope_tbl)
    slope_tbl <- apply_mfrm_slope_readiness(slope_tbl, readiness_record)
    person_tbl <- apply_mfrm_person_source_readiness(person_tbl, readiness_record)
    phase_finish("readiness_assembly", phase_started, "slope eligibility and fit readiness")
    phase_started <- phase_clock()
    facet_tbl <- build_other_facet_table(config, prep, params)
    interaction_tbl <- build_interaction_effect_table(config, prep, params)
    step_tbl <- build_step_table(config, prep, params)
    summary_tbl <- build_estimation_summary(model, method, prep, config, sizes, opt, readiness_record = readiness_record)
    phase_finish("remaining_output_tables", phase_started, "facet, interaction, step, and summary tables")
    if (phase_timing_enabled) {
        phase_finish("mfrm_estimate_total", estimation_started, "complete mfrm_estimate call")
        phase_timing <- do.call(rbind, phase_timing_rows)
        phase_timing$Order <- seq_len(nrow(phase_timing))
        phase_timing <- phase_timing[, c("Order", "Phase", "ElapsedSeconds", "Clock", "Scope", "DecisionUse")]
        config$phase_timing <- phase_timing
    }
    list(summary = summary_tbl, facets = list(person = person_tbl, others = facet_tbl), interactions = list(effects = interaction_tbl, 
        specs = config$interaction_specs), steps = step_tbl, slopes = slope_tbl, readiness = readiness_record, 
        config = config, prep = prep, data_review = data_review, opt = opt)
}

compute_obs_table <- function(res) {
    prep <- res$prep
    config <- res$config
    idx <- build_indices(prep, step_facet = config$step_facet, slope_facet = config$slope_facet, interaction_specs = config$interaction_specs)
    sizes <- build_param_sizes(config)
    params <- expand_params(res$opt$par, sizes, config)
    theta_hat <- if (config$method == "JML") {
        params$theta
    }
    else {
        mfrm_saved_person_estimates(res)
    }
    person_measure <- theta_hat
    person_measure_by_row <- person_measure[idx$person]
    eta <- compute_eta(idx, params, config, theta_override = theta_hat)
    prob_bundle <- compute_response_probability_bundle(config, idx, params, eta)
    resid_k <- idx$score_k - prob_bundle$expected_k
    std_sq <- resid_k^2/prob_bundle$var_k
    probs_mat <- prob_bundle$probs
    n_rows <- nrow(probs_mat)
    if (n_rows > 0L) {
        score_k_int <- as.integer(idx$score_k)
        obs_col <- pmin(pmax(score_k_int + 1L, 1L), ncol(probs_mat))
        pr_obs <- probs_mat[cbind(seq_len(n_rows), obs_col)]
        log_probs_mat <- log(probs_mat)
        log_probs_mat[probs_mat == 0] <- 0
        item_entropy <- as.numeric(rowSums(probs_mat * log_probs_mat))
        item_e_logp_sq <- as.numeric(rowSums(probs_mat * log_probs_mat^2))
        item_var_logp <- pmax(item_e_logp_sq - item_entropy^2, 0)
        k_mat <- matrix(seq_len(ncol(probs_mat)) - 1L, nrow = n_rows, ncol = ncol(probs_mat), byrow = TRUE)
        score_deriv_mat <- sweep(k_mat, 1L, prob_bundle$expected_k, FUN = "-") * matrix(prob_bundle$slope_obs, 
            nrow = n_rows, ncol = ncol(probs_mat))
        item_logp_score_cov <- as.numeric(rowSums(probs_mat * log_probs_mat * score_deriv_mat))
        observed_score_deriv <- prob_bundle$slope_obs * (idx$score_k - prob_bundle$expected_k)
    }
    else {
        pr_obs <- numeric(0)
        item_entropy <- numeric(0)
        item_var_logp <- numeric(0)
        item_logp_score_cov <- numeric(0)
        observed_score_deriv <- numeric(0)
    }
    out <- mutate(prep$data, PersonMeasure = person_measure_by_row, MeasureSum = as.numeric(eta), Observed = prep$rating_min + 
        idx$score_k, Expected = prep$rating_min + prob_bundle$expected_k, Var = prob_bundle$var_k, FourthCentralMoment = prob_bundle$fourth_central_moment, 
        ScoreInformation = prob_bundle$score_information, ScoreSlope = prob_bundle$slope_obs, ObservedScoreDerivative = observed_score_deriv, 
        Residual = Observed - Expected, StdResidual = Residual/sqrt(Var), StdSq = std_sq, PrObserved = pr_obs, 
        ItemEntropy = item_entropy, ItemVarLogP = item_var_logp, ItemLogPScoreCov = item_logp_score_cov)
    out <- mfrm_annotate_diagnostic_responses(out, res, idx, prob_bundle)
    attr(out, "person_fit_moments_version") <- 2L
    out
}

extract_bias_facet_spec <- function(bias_results, data_cols = NULL) {
    if (is.null(bias_results) || is.null(bias_results$table) || nrow(bias_results$table) == 0) {
        return(NULL)
    }
    tbl <- as.data.frame(bias_results$table, stringsAsFactors = FALSE)
    facets <- character(0)
    if (!is.null(bias_results$interaction_facets)) {
        facets <- c(facets, as.character(bias_results$interaction_facets))
    }
    if (!is.null(bias_results$facet_a) && length(bias_results$facet_a) > 0) {
        facets <- c(facets, as.character(bias_results$facet_a[1]))
    }
    if (!is.null(bias_results$facet_b) && length(bias_results$facet_b) > 0) {
        facets <- c(facets, as.character(bias_results$facet_b[1]))
    }
    facets <- facets[!is.na(facets) & nzchar(facets)]
    facets <- unique(facets)
    level_cols <- grep("^Facet[0-9]+_Level$", names(tbl), value = TRUE)
    if (length(level_cols) > 0) {
        ord <- suppressWarnings(as.integer(sub("^Facet([0-9]+)_Level$", "\\1", level_cols)))
        ok <- is.finite(ord)
        level_cols <- level_cols[ok]
        ord <- ord[ok]
        if (length(level_cols) == 0) 
            return(NULL)
        o <- order(ord)
        ord <- ord[o]
        level_cols <- level_cols[o]
        facet_name_cols <- paste0("Facet", ord)
        if (all(facet_name_cols %in% names(tbl)) && nrow(tbl) > 0) {
            facets_from_tbl <- vapply(facet_name_cols, function(col) as.character(tbl[[col]][1]), character(1))
            if (all(!is.na(facets_from_tbl) & nzchar(facets_from_tbl))) {
                facets <- facets_from_tbl
            }
        }
        if (length(facets) < length(level_cols)) {
            return(NULL)
        }
        facets <- facets[seq_along(level_cols)]
        index_cols <- paste0("Facet", ord, "_Index")
        measure_cols <- paste0("Facet", ord, "_Measure")
        se_cols <- paste0("Facet", ord, "_SE")
    }
    else if (all(c("FacetA_Level", "FacetB_Level") %in% names(tbl))) {
        if (length(facets) < 2 && all(c("FacetA", "FacetB") %in% names(tbl)) && nrow(tbl) > 0) {
            facets <- c(as.character(tbl$FacetA[1]), as.character(tbl$FacetB[1]))
        }
        facets <- facets[!is.na(facets) & nzchar(facets)]
        facets <- unique(facets)
        if (length(facets) < 2) 
            return(NULL)
        facets <- facets[1:2]
        level_cols <- c("FacetA_Level", "FacetB_Level")
        index_cols <- c("FacetA_Index", "FacetB_Index")
        measure_cols <- c("FacetA_Measure", "FacetB_Measure")
        se_cols <- c("FacetA_SE", "FacetB_SE")
    }
    else {
        return(NULL)
    }
    if (!is.null(data_cols) && !all(facets %in% data_cols)) {
        return(NULL)
    }
    list(facets = facets, level_cols = level_cols, index_cols = index_cols, measure_cols = measure_cols, 
        se_cols = se_cols, interaction_order = length(facets), interaction_mode = ifelse(length(facets) > 
            2, "higher_order", "pairwise"))
}

compute_bias_adjustment_vector <- function(res, bias_results = NULL) {
    n <- nrow(res$prep$data)
    if (n == 0) 
        return(numeric(0))
    adj <- rep(0, n)
    if (is.null(bias_results) || is.null(bias_results$table) || nrow(bias_results$table) == 0) {
        return(adj)
    }
    data <- res$prep$data
    spec <- extract_bias_facet_spec(bias_results, data_cols = names(data))
    if (is.null(spec) || length(spec$facets) < 2) {
        return(adj)
    }
    tbl <- as.data.frame(bias_results$table, stringsAsFactors = FALSE)
    req_cols <- c(spec$level_cols, "Bias Size")
    if (!all(req_cols %in% names(tbl))) {
        return(adj)
    }
    level_cols <- spec$level_cols
    tbl <- filter(mutate(tbl, across(all_of(level_cols), as.character), `Bias Size` = suppressWarnings(as.numeric(.data$`Bias Size`))), 
        is.finite(.data$`Bias Size`))
    if (nrow(tbl) == 0) 
        return(adj)
    lookup <- summarize(group_by(tbl, across(all_of(level_cols))), Bias = mean(.data$`Bias Size`, na.rm = TRUE), 
        .groups = "drop")
    key_levels <- lapply(level_cols, function(col) unique(as.character(lookup[[col]])))
    lookup_key_parts <- Map(function(col, levels) match(as.character(lookup[[col]]), levels), level_cols, 
        key_levels)
    lookup$Key <- do.call(paste, c(lookup_key_parts, sep = ":"))
    data_key_parts <- Map(function(f, levels) match(as.character(data[[f]]), levels), spec$facets, key_levels)
    names(data_key_parts) <- spec$facets
    keys <- do.call(paste, c(data_key_parts, sep = ":"))
    idx_hit <- match(keys, lookup$Key)
    hit <- !is.na(idx_hit)
    if (any(hit)) {
        adj[hit] <- lookup$Bias[idx_hit[hit]]
    }
    adj
}



calc_unexpected_response_table <- function(obs_df, probs, facet_names, rating_min, abs_z_min = 3, prob_max = 0.3, 
    rule = c("residual", "either", "both")) {
    rule <- match.arg(tolower(rule), c("residual", "either", "both"))
    if (!is.numeric(abs_z_min) || length(abs_z_min) != 1L || is.na(abs_z_min) || abs_z_min < 0 || !is.numeric(prob_max) || 
        length(prob_max) != 1L || !is.finite(prob_max) || prob_max < 0 || prob_max > 1) {
        stop("Unexpected-response cutoffs require abs_z_min >= 0 and 0 <= prob_max <= 1.", call. = FALSE)
    }
    retain_coverage <- function(table, flags = rep(NA, nrow(obs_df) %||% 0L)) {
        attr(table, "unexpected_coverage") <- c(Evaluated = sum(!is.na(flags)), Unavailable = sum(is.na(flags)))
        table
    }
    if (is.null(obs_df) || nrow(obs_df) == 0 || is.null(probs) || nrow(probs) != nrow(obs_df)) {
        return(retain_coverage(tibble()))
    }
    if (!"score_k" %in% names(obs_df) || !"StdResidual" %in% names(obs_df)) {
        return(retain_coverage(tibble()))
    }
    score_k <- suppressWarnings(as.integer(obs_df$score_k))
    n_cat <- ncol(probs)
    valid <- is.finite(score_k) & score_k >= 0 & score_k < n_cat
    obs_prob <- rep(NA_real_, nrow(obs_df))
    row_idx <- which(valid)
    if (length(row_idx) > 0) {
        obs_prob[row_idx] <- probs[cbind(row_idx, score_k[row_idx] + 1L)]
    }
    max_idx <- max.col(probs, ties.method = "first")
    most_likely_k <- max_idx - 1L
    most_likely <- rating_min + most_likely_k
    most_likely_prob <- probs[cbind(seq_len(nrow(probs)), max_idx)]
    abs_std <- abs(obs_df$StdResidual)
    surprise <- -log10(pmax(obs_prob, .Machine$double.xmin))
    modes <- probs == most_likely_prob
    mode_count <- rowSums(modes)
    cat_gap <- vapply(seq_len(nrow(probs)), function(i) {
        k <- which(modes[i, ]) - 1L + rating_min
        if (!length(k)) 
            NA_real_
        else min(abs(obs_df$Observed[i] - k))
    }, numeric(1))
    most_likely[mode_count != 1L] <- NA_real_
    low_prob <- ifelse(is.finite(obs_prob) & obs_prob >= 0 & obs_prob <= 1, obs_prob <= prob_max, NA)
    high_resid <- ifelse(is.finite(abs_std), abs_std >= abs_z_min, NA)
    flagged <- if (rule == "residual") {
        high_resid
    }
    else if (rule == "both") {
        low_prob & high_resid
    }
    else {
        low_prob | high_resid
    }
    out <- filter(mutate(obs_df, Row = dplyr::row_number(), ObsProb = obs_prob, MostLikely = most_likely, 
        MostLikelyProb = most_likely_prob, MostLikelyCount = mode_count, Surprise = surprise, AbsStdResidual = abs_std, 
        CategoryGap = cat_gap, FlagLowProbability = low_prob, FlagLargeResidual = high_resid, Unexpected = flagged, 
        Direction = dplyr::case_when(!is.finite(.data$Residual) ~ "Residual unavailable", .data$Residual > 
            0 ~ "Higher than expected", .data$Residual < 0 ~ "Lower than expected", TRUE ~ "As expected"), 
        Severity = .data$AbsStdResidual + .data$Surprise + 0.5 * .data$CategoryGap), .data$Unexpected)
    id_cols <- c("Person", facet_names)
    if ("Weight" %in% names(obs_df)) 
        id_cols <- c(id_cols, "Weight")
    id_cols <- unique(id_cols)
    keep_cols <- c("Row", id_cols, "Score", "Observed", "Expected", "Residual", "StdResidual", "ObsProb", 
        "MostLikely", "MostLikelyProb", "MostLikelyCount", "CategoryGap", "Surprise", "Direction", "FlagLowProbability", 
        "FlagLargeResidual", "Severity")
    keep_cols <- keep_cols[keep_cols %in% names(out)]
    out <- select(arrange(out, desc(.data$Severity), desc(abs(.data$StdResidual)), .data$ObsProb), dplyr::all_of(keep_cols))
    retain_coverage(out, flagged)
}

summarize_unexpected_response_table <- function(unexpected_tbl, total_observations, abs_z_min = 3, prob_max = 0.3, 
    rule = "residual") {
    coverage <- attr(unexpected_tbl, "unexpected_coverage", exact = TRUE)
    evaluated <- as.integer(coverage["Evaluated"] %||% NA_integer_)
    unavailable <- as.integer(coverage["Unavailable"] %||% NA_integer_)
    n_flagged <- nrow(unexpected_tbl) %||% 0L
    low_n <- if ("FlagLowProbability" %in% names(unexpected_tbl)) {
        sum(unexpected_tbl$FlagLowProbability, na.rm = TRUE)
    }
    else {
        if (n_flagged == 0L) 
            0L
        else NA_integer_
    }
    resid_n <- if ("FlagLargeResidual" %in% names(unexpected_tbl)) {
        sum(unexpected_tbl$FlagLargeResidual, na.rm = TRUE)
    }
    else {
        if (n_flagged == 0L) 
            0L
        else NA_integer_
    }
    tibble(TotalObservations = total_observations, EvaluatedObservations = evaluated, UnavailableObservations = unavailable, 
        UnexpectedN = if (is.finite(evaluated) && evaluated > 0L) 
            n_flagged
        else NA_integer_, UnexpectedPercent = if (total_observations > 0 && isTRUE(unavailable == 0L)) 
            100 * n_flagged/total_observations
        else NA_real_, LowProbabilityN = low_n, LargeResidualN = resid_n, Rule = rule, AbsZThreshold = abs_z_min, 
        ProbThreshold = prob_max)
}

compute_prob_matrix <- function(res) {
    prep <- res$prep
    config <- res$config
    idx <- build_indices(prep, step_facet = config$step_facet, slope_facet = config$slope_facet, interaction_specs = config$interaction_specs)
    sizes <- build_param_sizes(config)
    params <- expand_params(res$opt$par, sizes, config)
    theta_hat <- if (config$method == "JML") {
        params$theta
    }
    else {
        mfrm_saved_person_estimates(res)
    }
    eta <- compute_eta(idx, params, config, theta_override = theta_hat)
    compute_response_probability_bundle(config, idx, params, eta)$probs
}

calc_displacement_table <- function(obs_df, res, measures = NULL, abs_displacement_warn = 0.5, abs_t_warn = 2) {
    if (is.null(obs_df) || nrow(obs_df) == 0 || is.null(res$config)) {
        return(tibble())
    }
    facet_cols <- c("Person", res$config$facet_names)
    obs_df <- mutate(obs_df, .Weight = get_weights(obs_df))
    info_col <- if ("ScoreInformation" %in% names(obs_df)) 
        "ScoreInformation"
    else "Var"
    gradient_col <- if ("ObservedScoreDerivative" %in% names(obs_df)) 
        "ObservedScoreDerivative"
    else "Residual"
    displacement_signs <- c(Person = 1, res$config$facet_signs %||% stats::setNames(rep(-1, length(res$config$facet_names)), 
        res$config$facet_names))
    displacement <- purrr::map_dfr(facet_cols, function(facet) {
        select(mutate(summarize(group_by(obs_df, .data[[facet]]), WeightedN = sum(.data$.Weight, na.rm = TRUE), 
            ResidualSum = sum(.data[[gradient_col]] * .data$.Weight, na.rm = TRUE), Information = sum(.data[[info_col]] * 
                .data$.Weight, na.rm = TRUE), .groups = "drop"), Facet = facet, Level = as.character(.data[[facet]])), 
            "Facet", "Level", "WeightedN", "ResidualSum", "Information")
    })
    if (nrow(displacement) == 0) 
        return(tibble())
    displacement <- mutate(displacement, FacetSign = as.numeric(displacement_signs[.data$Facet]), Displacement = ifelse(.data$Information > 
        0, .data$FacetSign * .data$ResidualSum/.data$Information, NA_real_), DisplacementSE = ifelse(.data$Information > 
        0, 1/sqrt(.data$Information), NA_real_), DisplacementT = ifelse(is.finite(.data$DisplacementSE) & 
        .data$DisplacementSE > 0, .data$Displacement/.data$DisplacementSE, NA_real_))
    if (!is.null(measures) && nrow(measures) > 0) {
        displacement <- left_join(displacement, select(measures, "Facet", "Level", "Estimate", "SE", 
            "N"), by = c("Facet", "Level"))
    }
    else {
        displacement <- mutate(displacement, Estimate = NA_real_, SE = NA_real_, N = .data$WeightedN)
    }
    anchor_tbl <- extract_anchor_tables(res$config)$anchors
    if (is.null(anchor_tbl) || nrow(anchor_tbl) == 0) {
        anchor_tbl <- tibble(Facet = character(0), Level = character(0), AnchorValue = numeric(0))
    }
    else {
        anchor_tbl <- transmute(anchor_tbl, Facet = as.character(.data$Facet), Level = as.character(.data$Level), 
            AnchorValue = as.numeric(.data$Anchor))
    }
    status_tbl <- purrr::map_dfr(unique(displacement$Facet), function(facet) {
        lv <- pull(filter(displacement, .data$Facet == facet), .data$Level)
        tibble(Facet = facet, Level = lv, AnchorStatus = facet_anchor_status(facet, lv, res$config))
    })
    arrange(mutate(left_join(left_join(displacement, anchor_tbl, by = c("Facet", "Level")), status_tbl, 
        by = c("Facet", "Level")), AnchorType = case_when(.data$AnchorStatus == "A" ~ "Anchor", .data$AnchorStatus == 
        "G" ~ "Group", TRUE ~ "Free"), ReleasedEstimate = ifelse(is.finite(.data$Estimate) & is.finite(.data$Displacement), 
        .data$Estimate + .data$Displacement, NA_real_), AnchorGap = ifelse(is.finite(.data$AnchorValue) & 
        is.finite(.data$ReleasedEstimate), .data$ReleasedEstimate - .data$AnchorValue, NA_real_), FlagDisplacement = is.finite(.data$Displacement) & 
        abs(.data$Displacement) >= abs_displacement_warn, FlagT = is.finite(.data$DisplacementT) & abs(.data$DisplacementT) >= 
        abs_t_warn, Flag = .data$FlagDisplacement | .data$FlagT), desc(abs(.data$Displacement)), desc(abs(.data$DisplacementT)))
}

summarize_displacement_table <- function(displacement_tbl, abs_displacement_warn = 0.5, abs_t_warn = 2) {
    if (is.null(displacement_tbl) || nrow(displacement_tbl) == 0) {
        return(tibble(Levels = 0L, AnchoredLevels = 0L, FlaggedLevels = 0L, FlaggedAnchoredLevels = 0L, 
            MaxAbsDisplacement = NA_real_, MaxAbsDisplacementT = NA_real_, AbsDisplacementThreshold = abs_displacement_warn, 
            AbsTThreshold = abs_t_warn))
    }
    is_anchored <- displacement_tbl$AnchorType %in% c("Anchor", "Group")
    flagged <- if ("Flag" %in% names(displacement_tbl)) {
        displacement_tbl$Flag
    }
    else {
        rep(FALSE, nrow(displacement_tbl))
    }
    abs_disp <- abs(displacement_tbl$Displacement)
    abs_t <- abs(displacement_tbl$DisplacementT)
    tibble(Levels = nrow(displacement_tbl), AnchoredLevels = sum(is_anchored, na.rm = TRUE), FlaggedLevels = sum(flagged, 
        na.rm = TRUE), FlaggedAnchoredLevels = sum(flagged & is_anchored, na.rm = TRUE), MaxAbsDisplacement = if (any(is.finite(abs_disp))) 
        max(abs_disp, na.rm = TRUE)
    else NA_real_, MaxAbsDisplacementT = if (any(is.finite(abs_t))) 
        max(abs_t, na.rm = TRUE)
    else NA_real_, AbsDisplacementThreshold = abs_displacement_warn, AbsTThreshold = abs_t_warn)
}

fit_df_method_choices <- c("engine", "facets", "both")

match_fit_df_method <- function(fit_df_method = "engine") {
    match.arg(as.character(fit_df_method %||% "engine"), fit_df_method_choices)
}

fit_zstd_transform_label <- function(whexact = FALSE) {
    switch(mfrm_zstd_method(whexact), facets_yes = "Wilson-Hilferty (FACETS WHEXACT=YES)", facets_no = "Cube root without q/3 (FACETS WHEXACT=NO)", 
        legacy_linear = "Legacy linear normal approximation")
}

mfrm_fit_observation_terms <- function(obs_df) {
    obs_df <- tibble::as_tibble(obs_df)
    w <- get_weights(obs_df)
    obs_df$.Weight <- w
    primary <- obs_df[["PrimaryPersonMeasure"]] %||% rep(NA_real_, nrow(obs_df))
    basis <- obs_df[["PersonMeasureBasis"]] %||% rep("", nrow(obs_df))
    obs_df$.FitBoundaryProxy <- basis %in% "JML optimizer" & is.infinite(primary)
    obs_df$.FitAvailable <- is.finite(obs_df$StdSq) & obs_df$StdSq >= 0 & is.finite(obs_df$Var) & obs_df$Var > 
        0 & is.finite(w) & w > 0
    fourth <- obs_df[["FourthCentralMoment"]] %||% rep(NA_real_, nrow(obs_df))
    safe_var <- ifelse(is.finite(obs_df$Var) & obs_df$Var > 1e-12 & is.finite(fourth) & is.finite(w) & 
        w > 0, obs_df$Var, NA_real_)
    obs_df$.FourthInfit <- w * (fourth - safe_var^2)
    obs_df$.FourthOutfit <- w * (fourth/safe_var^2 - 1)
    obs_df
}

apply_fit_df_method <- function(tbl, fit_df_method = "engine", whexact = FALSE, facets_zstd_cap = 9) {
    fit_df_method <- match_fit_df_method(fit_df_method)
    if (!all(c("Infit", "Outfit", "DF_Infit", "DF_Outfit", "DF_Infit_FACETS", "DF_Outfit_FACETS") %in% 
        names(tbl))) {
        return(tbl)
    }
    engine_cols <- c(DF_Infit_ENGINE = "DF_Infit", DF_Outfit_ENGINE = "DF_Outfit", InfitZSTD_ENGINE = "InfitZSTD", 
        OutfitZSTD_ENGINE = "OutfitZSTD")
    for (nm in names(engine_cols)) {
        src <- unname(engine_cols[nm])
        tbl[[nm]] <- tbl[[src]]
    }
    tbl$InfitZSTD_FACETS <- zstd_from_mnsq_facets(tbl$Infit, tbl$DF_Infit_FACETS, whexact = whexact, 
        cap = facets_zstd_cap)
    tbl$OutfitZSTD_FACETS <- zstd_from_mnsq_facets(tbl$Outfit, tbl$DF_Outfit_FACETS, whexact = whexact, 
        cap = facets_zstd_cap)
    if (identical(fit_df_method, "facets")) {
        tbl$DF_Infit <- tbl$DF_Infit_FACETS
        tbl$DF_Outfit <- tbl$DF_Outfit_FACETS
        tbl$InfitZSTD <- tbl$InfitZSTD_FACETS
        tbl$OutfitZSTD <- tbl$OutfitZSTD_FACETS
    }
    tbl$FitDfMethod <- dplyr::case_when(identical(fit_df_method, "facets") ~ "facets_wright_masters", 
        identical(fit_df_method, "both") ~ "engine_primary_facets_available", TRUE ~ "engine")
    tbl$FitZSTDTransform <- fit_zstd_transform_label(whexact)
    tbl$FitZSTDCap <- if (identical(fit_df_method, "engine")) {
        NA_real_
    }
    else {
        suppressWarnings(as.numeric(facets_zstd_cap))
    }
    if (identical(fit_df_method, "engine")) {
        drop_cols <- c(names(engine_cols), "DF_Infit_FACETS", "DF_Outfit_FACETS", "InfitZSTD_FACETS", 
            "OutfitZSTD_FACETS", "FitDfMethod", "FitZSTDTransform", "FitZSTDCap")
        tbl <- tbl[, setdiff(names(tbl), drop_cols), drop = FALSE]
    }
    tbl
}

mfrm_summarize_response_fit <- function(obs_df, whexact, fit_df_method, facets_zstd_cap) {
    out <- summarize(obs_df, Infit = sum(StdSq * Var * .Weight)/sum(Var * .Weight), Outfit = sum(StdSq * 
        .Weight)/sum(.Weight), DF_Infit = sum(Var * .Weight), DF_Outfit = sum(.Weight), N = sum(.Weight), 
        FACETSDenom_Infit = sum(.data$.FourthInfit), FACETSDenom_Outfit = sum(.data$.FourthOutfit), FitResponseRows = dplyr::n(), 
        FitAvailableRows = sum(.data$.FitAvailable), FitUnavailableRows = sum(!.data$.FitAvailable), 
        FitBoundaryRows = sum(.data$.FitBoundaryProxy), .groups = "drop")
    required <- c("Infit", "Outfit", "DF_Infit", "DF_Outfit")
    complete <- out$FitResponseRows > 0 & out$FitUnavailableRows == 0 & rowSums(!is.finite(as.matrix(out[required]))) == 
        0 & out$DF_Infit > 0 & out$DF_Outfit > 0
    complete[is.na(complete)] <- FALSE
    out[!complete, required] <- NA_real_
    for (stat in c("Infit", "Outfit")) {
        denom <- out[[paste0("FACETSDenom_", stat)]]
        df <- 2 * out[[paste0("DF_", stat)]]^2/denom
        df[!is.finite(denom) | denom <= 1e-12 | !is.finite(df)] <- NA_real_
        out[[paste0("DF_", stat, "_FACETS")]] <- df
        out[[paste0(stat, "ZSTD")]] <- zstd_from_mnsq(out[[stat]], out[[paste0("DF_", stat)]], whexact = whexact)
    }
    out$FitStatus <- ifelse(complete, "available_descriptive", "unavailable")
    out$FitReason <- ifelse(complete, "Descriptive mean squares; their calculation does not establish inferential validity.", 
        ifelse(out$FitResponseRows == 0, "No response rows are available.", ifelse(out$FitUnavailableRows > 
            0, "At least one response has unavailable standardized residuals, variance or weights; no partial-row fit statistic is reported.", 
            "Weighted sums are nonfinite or have a nonpositive denominator.")))
    out <- dplyr::relocate(select(out, -all_of(c("FACETSDenom_Infit", "FACETSDenom_Outfit"))), all_of(c("Infit", 
        "Outfit", "InfitZSTD", "OutfitZSTD", "DF_Infit", "DF_Outfit", "DF_Infit_FACETS", "DF_Outfit_FACETS", 
        "FitResponseRows", "FitAvailableRows", "FitUnavailableRows", "FitBoundaryRows", "FitStatus", 
        "FitReason")))
    out <- apply_fit_df_method(out, fit_df_method = fit_df_method, whexact = whexact, facets_zstd_cap = facets_zstd_cap)
    boundary <- out$FitBoundaryRows > 0L
    zstd <- grep("^(Infit|Outfit)ZSTD($|_)", names(out), value = TRUE)
    out[boundary, zstd] <- NA_real_
    out$FitReason[boundary] <- paste(out$FitReason[boundary], "ZSTD is unavailable: this scope includes JML optimizer proxies for infinite primary Person estimates; no rows were excluded.")
    for (stat in c("Infit", "Outfit")) {
        df <- out[[paste0("DF_", stat)]]
        small <- !boundary & is.finite(df) & df < 1
        out$FitReason[small] <- paste(out$FitReason[small], paste0(stat, " ZSTD is unavailable: the selected degrees of freedom are below 1."))
        if (identical(fit_df_method, "both")) {
            df <- out[[paste0("DF_", stat, "_FACETS")]]
            small <- !boundary & is.finite(df) & df < 1
            out$FitReason[small] <- paste(out$FitReason[small], paste0(stat, " FACETS-style ZSTD is unavailable: its degrees of freedom are below 1."))
        }
    }
    out
}

calc_overall_fit <- function(obs_df, whexact = FALSE, fit_df_method = "engine", facets_zstd_cap = 9) {
    select(mfrm_summarize_response_fit(mfrm_fit_observation_terms(obs_df), whexact, match_fit_df_method(fit_df_method), 
        facets_zstd_cap), -N)
}

calc_facet_fit <- function(obs_df, facet_cols, whexact = FALSE, fit_df_method = "engine", facets_zstd_cap = 9) {
    fit_df_method <- match_fit_df_method(fit_df_method)
    obs_df <- mfrm_fit_observation_terms(obs_df)
    purrr::map_dfr(facet_cols, function(facet) {
        dplyr::relocate(select(mutate(mfrm_summarize_response_fit(group_by(obs_df, .data[[facet]]), whexact, 
            fit_df_method, facets_zstd_cap), Facet = facet, Level = .data[[facet]]), -all_of(facet)), 
            Facet, Level, N, Infit, Outfit, InfitZSTD, OutfitZSTD, DF_Infit, DF_Outfit)
    })
}

calc_facet_se <- function(obs_df, facet_cols) {
    obs_df <- mutate(obs_df, .Weight = get_weights(obs_df))
    info_col <- if ("ScoreInformation" %in% names(obs_df)) 
        "ScoreInformation"
    else "Var"
    purrr::map_dfr(facet_cols, function(facet) {
        select(mutate(summarize(group_by(obs_df, .data[[facet]]), Info = sum(.data[[info_col]] * .Weight, 
            na.rm = TRUE), N = sum(.Weight, na.rm = TRUE), .groups = "drop"), Facet = facet, Level = .data[[facet]], 
            SE = ifelse(Info > 0, 1/sqrt(Info), NA_real_)), Facet, Level, N, SE)
    })
}

calc_bias_facet <- function(obs_df, facet_cols) {
    obs_df <- mutate(obs_df, .Weight = get_weights(obs_df))
    purrr::map_dfr(facet_cols, function(facet) {
        select(mutate(mutate(summarize(group_by(obs_df, .data[[facet]]), ObservedAverage = weighted_mean(Observed, 
            .Weight), ExpectedAverage = weighted_mean(Expected, .Weight), MeanResidual = weighted_mean(Residual, 
            .Weight), MeanStdResidual = weighted_mean(StdResidual, .Weight), MeanAbsStdResidual = weighted_mean(abs(StdResidual), 
            .Weight), ChiSq = sum((StdResidual^2) * .Weight, na.rm = TRUE), SE_Residual = {
            n_w <- sum(.Weight, na.rm = TRUE)
            ifelse(n_w > 0, sqrt(sum(Var * .Weight, na.rm = TRUE))/n_w, NA_real_)
        }, SE_StdResidual = {
            n_w <- sum(.Weight, na.rm = TRUE)
            ifelse(n_w > 0, 1/sqrt(n_w), NA_real_)
        }, N = sum(.Weight, na.rm = TRUE), .groups = "drop"), Facet = facet, Level = .data[[facet]]), 
            Bias = MeanResidual, DF = ifelse(N > 1, N - 1, NA_real_), t_Residual = ifelse(is.finite(SE_Residual) & 
                SE_Residual > 0, MeanResidual/SE_Residual, NA_real_), t_StdResidual = ifelse(is.finite(SE_StdResidual) & 
                SE_StdResidual > 0, MeanStdResidual/SE_StdResidual, NA_real_), p_Residual = ifelse(is.finite(DF) & 
                is.finite(t_Residual), 2 * stats::pt(-abs(t_Residual), df = DF), NA_real_), p_StdResidual = ifelse(is.finite(DF) & 
                is.finite(t_StdResidual), 2 * stats::pt(-abs(t_StdResidual), df = DF), NA_real_), ChiDf = DF, 
            ChiP = ifelse(is.finite(ChiSq) & is.finite(ChiDf) & ChiDf > 0, 1 - stats::pchisq(ChiSq, df = ChiDf), 
                NA_real_)), Facet, Level, N, ObservedAverage, ExpectedAverage, Bias, MeanResidual, MeanStdResidual, 
            MeanAbsStdResidual, ChiSq, ChiDf, ChiP, SE_Residual, t_Residual, p_Residual, SE_StdResidual, 
            t_StdResidual, p_StdResidual, DF)
    })
}

calc_bias_interactions <- function(obs_df, facet_cols, pairs = NULL, top_n = 20) {
    if (length(facet_cols) < 2) 
        return(tibble())
    obs_df <- mutate(obs_df, .Weight = get_weights(obs_df))
    if (is.null(pairs)) {
        combos <- combn(facet_cols, 2, simplify = FALSE)
    }
    else if (length(pairs) == 0) {
        return(tibble())
    }
    else {
        combos <- pairs
    }
    out <- purrr::map_dfr(combos, function(pair) {
        pair1 <- pair[1]
        pair2 <- pair[2]
        select(mutate(mutate(summarize(group_by(obs_df, .data[[pair1]], .data[[pair2]]), ObservedAverage = weighted_mean(Observed, 
            .Weight), ExpectedAverage = weighted_mean(Expected, .Weight), MeanResidual = weighted_mean(Residual, 
            .Weight), MeanStdResidual = weighted_mean(StdResidual, .Weight), MeanAbsStdResidual = weighted_mean(abs(StdResidual), 
            .Weight), ChiSq = sum((StdResidual^2) * .Weight, na.rm = TRUE), SE_Residual = {
            n_w <- sum(.Weight, na.rm = TRUE)
            ifelse(n_w > 0, sqrt(sum(Var * .Weight, na.rm = TRUE))/n_w, NA_real_)
        }, SE_StdResidual = {
            n_w <- sum(.Weight, na.rm = TRUE)
            ifelse(n_w > 0, 1/sqrt(n_w), NA_real_)
        }, N = sum(.Weight, na.rm = TRUE), .groups = "drop"), Pair = paste(pair1, "x", pair2), Level = paste(.data[[pair1]], 
            .data[[pair2]], sep = " | ")), Bias = MeanResidual, DF = ifelse(N > 1, N - 1, NA_real_), 
            t_Residual = ifelse(is.finite(SE_Residual) & SE_Residual > 0, MeanResidual/SE_Residual, NA_real_), 
            t_StdResidual = ifelse(is.finite(SE_StdResidual) & SE_StdResidual > 0, MeanStdResidual/SE_StdResidual, 
                NA_real_), p_Residual = ifelse(is.finite(DF) & is.finite(t_Residual), 2 * stats::pt(-abs(t_Residual), 
                df = DF), NA_real_), p_StdResidual = ifelse(is.finite(DF) & is.finite(t_StdResidual), 
                2 * stats::pt(-abs(t_StdResidual), df = DF), NA_real_), ChiDf = DF, ChiP = ifelse(is.finite(ChiSq) & 
                is.finite(ChiDf) & ChiDf > 0, 1 - stats::pchisq(ChiSq, df = ChiDf), NA_real_)), Pair, 
            Level, N, ObservedAverage, ExpectedAverage, Bias, MeanResidual, MeanStdResidual, MeanAbsStdResidual, 
            ChiSq, ChiDf, ChiP, SE_Residual, t_Residual, p_Residual, SE_StdResidual, t_StdResidual, p_StdResidual, 
            DF)
    })
    slice_head(select(arrange(mutate(out, AbsStd = abs(MeanStdResidual)), desc(AbsStd)), -AbsStd), n = top_n)
}

safe_cor <- function(x, y, w = NULL) {
    ok <- is.finite(x) & is.finite(y)
    if (is.null(w)) {
        if (!any(ok)) 
            return(NA_real_)
        x <- x[ok]
        y <- y[ok]
        if (length(unique(x)) < 2 || length(unique(y)) < 2) {
            return(NA_real_)
        }
        return(suppressWarnings(stats::cor(x, y, use = "complete.obs")))
    }
    ok <- ok & is.finite(w) & w > 0
    if (!any(ok)) 
        return(NA_real_)
    x <- x[ok]
    y <- y[ok]
    w <- w[ok]
    w_sum <- sum(w)
    if (w_sum <= 0) 
        return(NA_real_)
    mx <- sum(w * x)/w_sum
    my <- sum(w * y)/w_sum
    vx <- sum(w * (x - mx)^2)/w_sum
    vy <- sum(w * (y - my)^2)/w_sum
    if (vx <= 0 || vy <= 0) 
        return(NA_real_)
    cov <- sum(w * (x - mx) * (y - my))/w_sum
    cov/sqrt(vx * vy)
}

weighted_mean_safe <- function(x, w) {
    weighted_mean(x, w)
}

infer_default_rater_facet <- function(facet_names, fallback_first = TRUE) {
    facet_names <- as.character(facet_names)
    if (length(facet_names) == 0) 
        return(NULL)
    lowered <- tolower(facet_names)
    patterns <- c("rater", "judge", "grader", "reader", "scorer", "assessor", "evaluator")
    hits <- vapply(lowered, function(x) any(vapply(patterns, function(p) grepl(p, x, fixed = TRUE), logical(1))), 
        logical(1))
    if (any(hits)) {
        return(facet_names[which(hits)[1]])
    }
    if (isTRUE(fallback_first)) 
        facet_names[1]
    else NULL
}

calc_interrater_agreement <- function(obs_df, facet_cols, rater_facet, res = NULL) {
    if (is.null(obs_df) || nrow(obs_df) == 0) {
        return(list(summary = tibble(), pairs = tibble()))
    }
    if (is.null(rater_facet) || !rater_facet %in% facet_cols) {
        return(list(summary = tibble(), pairs = tibble()))
    }
    context_cols <- setdiff(facet_cols, rater_facet)
    if (length(context_cols) == 0) {
        return(list(summary = tibble(), pairs = tibble()))
    }
    obs_df$.context <- dplyr::group_indices(dplyr::group_by(obs_df, dplyr::across(dplyr::all_of(context_cols))))
    df <- select(obs_df, .context, !!rlang::sym(rater_facet), Observed, any_of("Weight"))
    df$.Weight <- get_weights(df)
    df <- summarize(group_by(df, .context, !!rlang::sym(rater_facet)), Score = if (all(is.finite(Observed))) 
        weighted_mean(Observed, .Weight)
    else NA_real_, Ratings = n(), .groups = "drop")
    if (nrow(df) == 0) {
        return(list(summary = tibble(), pairs = tibble()))
    }
    rater_chr <- ifelse(is.na(df[[rater_facet]]), "NA", as.character(df[[rater_facet]]))
    rater_cols <- unique(rater_chr)
    n_raters <- length(rater_cols)
    if (n_raters < 2L) {
        return(list(summary = tibble(), pairs = tibble()))
    }
    prob_map <- new.env(parent = emptyenv(), hash = TRUE)
    prob_map_size <- 0L
    if (!is.null(res)) {
        probs <- compute_prob_matrix(res)
        if (!is.null(probs) && nrow(probs) == nrow(obs_df)) {
            person <- res$facets$person
            primary <- is.finite(person$Estimate[match(as.character(obs_df$Person), as.character(person$Person))])
            for (facet in res$config$facet_names) {
                coef <- res$facets$others[res$facets$others$Facet == facet, , drop = FALSE]
                primary <- primary & is.finite(coef$Estimate[match(as.character(obs_df[[facet]]), as.character(coef$Level))])
            }
            if (isTRUE(res$config$model %in% c("PCM", "GPCM"))) {
                bad_steps <- unique(as.character(res$steps$StepFacet[!is.finite(res$steps$Estimate)]))
                primary <- primary & !as.character(obs_df[[res$config$step_facet]]) %in% bad_steps
            }
            else if (any(!is.finite(res$steps$Estimate))) 
                primary[] <- FALSE
            if (identical(res$config$model, "GPCM")) {
                slope <- res$slopes$Estimate[match(as.character(obs_df[[res$config$slope_facet]]), as.character(res$slopes$SlopeFacet))]
                primary <- primary & is.finite(slope) & slope > 0
            }
            prob_cols <- paste0(".p", seq_len(ncol(probs)))
            prob_df <- select(obs_df, .context, !!rlang::sym(rater_facet), any_of("Weight"))
            prob_df[prob_cols] <- probs
            prob_df$.Weight <- get_weights(prob_df)
            prob_df$.PrimaryAvailable <- primary
            prob_avg <- summarize(group_by(prob_df, .context, !!rlang::sym(rater_facet)), .PrimaryAvailable = all(.data$.PrimaryAvailable), 
                .Repeated = n() > 1L, across(all_of(prob_cols), ~if (n() == 1L) 
                  .x[1L]
                else NA_real_), .groups = "drop")
            if (nrow(prob_avg) > 0) {
                prob_avg_mat <- as.matrix(prob_avg[, prob_cols, drop = FALSE])
                ctx_vec <- as.character(prob_avg$.context)
                rater_vec <- as.character(prob_avg[[rater_facet]])
                for (i in seq_len(nrow(prob_avg))) {
                  key <- paste(ctx_vec[i], rater_vec[i], sep = "||")
                  assign(key, list(probability = prob_avg_mat[i, ], primary_available = prob_avg$.PrimaryAvailable[i], 
                    repeated = prob_avg$.Repeated[i]), envir = prob_map)
                }
                prob_map_size <- nrow(prob_avg)
            }
        }
    }
    r_id <- match(rater_chr, rater_cols)
    fin_mask <- is.finite(df$Score)
    r_fin <- r_id[fin_mask]
    ctx_fin <- as.integer(df$.context[fin_mask])
    sc_fin <- df$Score[fin_mask]
    ctx_tab <- if (length(ctx_fin) > 0L) 
        tabulate(ctx_fin)
    else integer(0)
    contexts_with_pairs <- sum(ctx_tab >= 2L)
    pair_mat_all <- utils::combn(n_raters, 2L)
    n_all_pairs <- ncol(pair_mat_all)
    r1_names <- rater_cols[pair_mat_all[1L, ]]
    r2_names <- rater_cols[pair_mat_all[2L, ]]
    n_vec <- integer(n_all_pairs)
    exact_cnt_vec <- integer(n_all_pairs)
    adj_cnt_vec <- integer(n_all_pairs)
    exp_exact_cnt_vec <- rep(NA_real_, n_all_pairs)
    exp_avail_vec <- integer(n_all_pairs)
    exp_unavail_vec <- integer(n_all_pairs)
    exp_reason_vec <- rep("no_matched_scores", n_all_pairs)
    exact_vec <- rep(NA_real_, n_all_pairs)
    exp_exact_vec <- rep(NA_real_, n_all_pairs)
    adj_vec <- rep(NA_real_, n_all_pairs)
    mean_diff_vec <- rep(NA_real_, n_all_pairs)
    mad_vec <- rep(NA_real_, n_all_pairs)
    corr_vec <- rep(NA_real_, n_all_pairs)
    if (contexts_with_pairs > 0L) {
        keep_multi <- ctx_tab[ctx_fin] >= 2L
        ctx_m <- ctx_fin[keep_multi]
        r_m <- r_fin[keep_multi]
        sc_m <- sc_fin[keep_multi]
        if (is.unsorted(ctx_m)) {
            ord <- order(ctx_m)
            ctx_m <- ctx_m[ord]
            r_m <- r_m[ord]
            sc_m <- sc_m[ord]
        }
        n_m <- length(ctx_m)
        run_ends <- c(which(ctx_m[-1L] != ctx_m[-n_m]), n_m)
        run_starts <- c(1L, run_ends[-length(run_ends)] + 1L)
        run_lens <- run_ends - run_starts + 1L
        total_co <- as.integer(sum(as.double(run_lens) * as.double(run_lens - 1L)/2))
        co_pid <- integer(total_co)
        co_ctx <- integer(total_co)
        co_v1 <- numeric(total_co)
        co_v2 <- numeric(total_co)
        pos <- 0L
        for (g in seq_along(run_starts)) {
            s_idx <- run_starts[g]
            m_len <- run_lens[g]
            c_val <- ctx_m[s_idx]
            for (a in seq_len(m_len - 1L)) {
                ia <- s_idx + a - 1L
                ra <- r_m[ia]
                va <- sc_m[ia]
                for (b in (a + 1L):m_len) {
                  ib <- s_idx + b - 1L
                  rb <- r_m[ib]
                  vb <- sc_m[ib]
                  pos <- pos + 1L
                  co_ctx[pos] <- c_val
                  if (ra < rb) {
                    co_pid[pos] <- as.integer((ra - 1) * n_raters - ((ra - 1) * ra)/2 + (rb - ra))
                    co_v1[pos] <- va
                    co_v2[pos] <- vb
                  }
                  else {
                    co_pid[pos] <- as.integer((rb - 1) * n_raters - ((rb - 1) * rb)/2 + (ra - rb))
                    co_v1[pos] <- vb
                    co_v2[pos] <- va
                  }
                }
            }
        }
        by_pid <- split(seq_len(pos), co_pid)
        for (nm in names(by_pid)) {
            pid <- as.integer(nm)
            rows_p <- by_pid[[nm]]
            n_ok <- length(rows_p)
            v1 <- co_v1[rows_p]
            v2 <- co_v2[rows_p]
            diff <- v1 - v2
            exact_count <- sum(diff == 0, na.rm = TRUE)
            contexts <- as.character(co_ctx[rows_p])
            expected_reasons <- rep("fitted_probabilities_unavailable", n_ok)
            exp_vals <- if (prob_map_size > 0L && n_ok > 0L) {
                tmp <- numeric(n_ok)
                kept <- 0L
                key1_vec <- paste(contexts, r1_names[pid], sep = "||")
                key2_vec <- paste(contexts, r2_names[pid], sep = "||")
                for (k in seq_len(n_ok)) {
                  p1 <- get0(key1_vec[k], envir = prob_map, inherits = FALSE)
                  p2 <- get0(key2_vec[k], envir = prob_map, inherits = FALSE)
                  if (is.null(p1) || is.null(p2)) 
                    next
                  if (!p1$primary_available || !p2$primary_available) {
                    expected_reasons[k] <- "primary_estimate_unavailable"
                    next
                  }
                  if (p1$repeated || p2$repeated) {
                    expected_reasons[k] <- "repeated_ratings"
                    next
                  }
                  p1 <- p1$probability
                  p2 <- p2$probability
                  if (any(!is.finite(p1)) || any(!is.finite(p2)) || any(p1 < 0 | p1 > 1) || any(p2 < 
                    0 | p2 > 1) || abs(sum(p1) - 1) > 1e-08 || abs(sum(p2) - 1) > 1e-08) 
                    next
                  kept <- kept + 1L
                  tmp[kept] <- sum(p1 * p2)
                  expected_reasons[k] <- "available"
                }
                if (kept > 0L) 
                  tmp[seq_len(kept)]
                else numeric(0)
            }
            else {
                numeric(0)
            }
            n_exp <- length(exp_vals)
            n_vec[pid] <- n_ok
            exact_cnt_vec[pid] <- exact_count
            adj_cnt_vec[pid] <- sum(abs(diff) <= 1, na.rm = TRUE)
            exp_exact_cnt_vec[pid] <- if (n_exp == n_ok) 
                sum(exp_vals)
            else NA_real_
            exp_avail_vec[pid] <- n_exp
            exp_unavail_vec[pid] <- n_ok - n_exp
            exp_reason_vec[pid] <- if (n_exp == n_ok) 
                "available"
            else paste(sort(unique(expected_reasons[expected_reasons != "available"])), collapse = ";")
            exact_vec[pid] <- exact_count/n_ok
            exp_exact_vec[pid] <- if (n_exp == n_ok) 
                mean(exp_vals)
            else NA_real_
            adj_vec[pid] <- mean(abs(diff) <= 1, na.rm = TRUE)
            mean_diff_vec[pid] <- mean(diff, na.rm = TRUE)
            mad_vec[pid] <- mean(abs(diff), na.rm = TRUE)
            corr_vec[pid] <- safe_cor(v1, v2)
        }
    }
    count_cast <- if (any(n_vec == 0L)) 
        as.numeric
    else as.integer
    pair_tbl <- tibble(Rater1 = r1_names, Rater2 = r2_names, N = count_cast(n_vec), OpportunityCount = count_cast(n_vec), 
        ExactCount = count_cast(exact_cnt_vec), ExpectedExactCount = exp_exact_cnt_vec, ExpectedAvailableContexts = exp_avail_vec, 
        ExpectedUnavailableContexts = exp_unavail_vec, ExpectedReason = exp_reason_vec, AdjacentCount = count_cast(adj_cnt_vec), 
        Exact = exact_vec, ExpectedExact = exp_exact_vec, Adjacent = adj_vec, MeanDiff = mean_diff_vec, 
        MAD = mad_vec, Corr = corr_vec)
    total_pairs <- sum(pair_tbl$N, na.rm = TRUE)
    total_exact <- sum(pair_tbl$Exact * pair_tbl$N, na.rm = TRUE)
    expected_available <- total_pairs > 0 && all(is.finite(pair_tbl$ExpectedExact[pair_tbl$N > 0]))
    total_expected <- if (expected_available) {
        sum(pair_tbl$ExpectedExact * pair_tbl$N, na.rm = TRUE)
    }
    else {
        NA_real_
    }
    summary_tbl <- tibble(RaterFacet = rater_facet, Raters = length(rater_cols), Pairs = nrow(pair_tbl), 
        AvailablePairs = sum(pair_tbl$N > 0), UnavailablePairs = sum(pair_tbl$N == 0), CorrelationPairs = sum(is.finite(pair_tbl$Corr)), 
        UnavailableCorrelationPairs = sum(!is.finite(pair_tbl$Corr)), RepeatedCells = sum(df$Ratings > 
            1L), ExpectedAvailableContexts = sum(pair_tbl$ExpectedAvailableContexts), ExpectedUnavailableContexts = sum(pair_tbl$ExpectedUnavailableContexts), 
        ExpectedReason = if (expected_available) 
            "available"
        else if (total_pairs == 0) 
            "no_matched_scores"
        else paste(sort(unique(unlist(strsplit(pair_tbl$ExpectedReason[pair_tbl$N > 0 & !is.finite(pair_tbl$ExpectedExact)], 
            ";", fixed = TRUE)))), collapse = ";"), Contexts = contexts_with_pairs, TotalPairs = total_pairs, 
        OpportunityCount = total_pairs, ExactAgreements = total_exact, ExpectedAgreements = ifelse(expected_available, 
            total_expected, NA_real_), ExactAgreement = ifelse(total_pairs > 0, total_exact/total_pairs, 
            NA_real_), ExpectedExactAgreement = ifelse(expected_available && total_pairs > 0, total_expected/total_pairs, 
            NA_real_), AgreementMinusExpected = ifelse(expected_available && total_pairs > 0, (total_exact - 
            total_expected)/total_pairs, NA_real_), AdjacentAgreements = sum(pair_tbl$AdjacentCount, 
            na.rm = TRUE), AdjacentAgreement = weighted_mean_safe(pair_tbl$Adjacent, pair_tbl$N), MeanAbsDiff = weighted_mean_safe(pair_tbl$MAD, 
            pair_tbl$N), MeanCorr = weighted_mean_safe(pair_tbl$Corr, pair_tbl$N))
    list(summary = summary_tbl, pairs = pair_tbl)
}

augment_interrater_with_precision <- function(agreement, reliability_tbl, rater_facet = NULL) {
    if (is.null(agreement) || !is.list(agreement)) 
        return(agreement)
    summary_tbl <- as.data.frame(agreement$summary %||% data.frame(), stringsAsFactors = FALSE)
    if (nrow(summary_tbl) == 0) 
        return(agreement)
    if (is.null(rater_facet) || !nzchar(as.character(rater_facet[1]))) {
        if ("RaterFacet" %in% names(summary_tbl)) {
            rater_facet <- as.character(summary_tbl$RaterFacet[1])
        }
    }
    else {
        rater_facet <- as.character(rater_facet[1])
    }
    rel_tbl <- as.data.frame(reliability_tbl %||% data.frame(), stringsAsFactors = FALSE)
    if (!"Facet" %in% names(rel_tbl) || !nzchar(rater_facet)) {
        agreement$summary <- summary_tbl
        return(agreement)
    }
    rel_row <- rel_tbl[as.character(rel_tbl$Facet) == rater_facet, , drop = FALSE]
    if (nrow(rel_row) == 0) {
        agreement$summary <- summary_tbl
        return(agreement)
    }
    summary_tbl$RaterSeparation <- suppressWarnings(as.numeric(rel_row$Separation[1]))
    summary_tbl$RaterStrata <- suppressWarnings(as.numeric(rel_row$Strata[1]))
    summary_tbl$RaterReliability <- suppressWarnings(as.numeric(rel_row$Reliability[1]))
    summary_tbl$RaterRealSeparation <- suppressWarnings(as.numeric(rel_row$RealSeparation[1]))
    summary_tbl$RaterRealReliability <- suppressWarnings(as.numeric(rel_row$RealReliability[1]))
    agreement$summary <- summary_tbl
    agreement
}

calc_ptmea <- function(obs_df, facet_cols) {
    if (length(facet_cols) == 0) 
        return(tibble())
    if (!"MeasureSum" %in% names(obs_df)) 
        stop("PTMEA requires the oriented MeasureSum; recreate diagnose_mfrm(fit).", call. = FALSE)
    obs_df <- mutate(obs_df, .Weight = get_weights(obs_df))
    purrr::map_dfr(facet_cols, function(facet) {
        select(mutate(summarize(group_by(obs_df, .data[[facet]]), PTMEA = safe_cor(Observed, MeasureSum, 
            w = .Weight), N = sum(.Weight, na.rm = TRUE), .groups = "drop"), Facet = facet, Level = .data[[facet]]), 
            Facet, Level, PTMEA, N)
    })
}

expected_score_from_eta <- function(eta, step_cum, rating_min) {
    if (!is.finite(eta) || length(step_cum) == 0) 
        return(NA_real_)
    probs <- category_prob_rsm(eta, step_cum)
    k_vals <- 0:(length(step_cum) - 1)
    rating_min + sum(probs * k_vals)
}

expected_score_from_eta_gpcm <- function(eta, step_cum, slope, rating_min) {
    if (!is.finite(eta) || length(step_cum) == 0) 
        return(NA_real_)
    if (!is.finite(slope) || slope <= 0) 
        return(NA_real_)
    k_vals <- 0:(length(step_cum) - 1)
    log_num <- slope * (k_vals * eta - step_cum)
    m <- max(log_num)
    if (!is.finite(m)) 
        return(NA_real_)
    probs <- exp(log_num - m)
    probs <- probs/sum(probs)
    rating_min + sum(probs * k_vals)
}

estimate_eta_from_target <- function(target, step_cum, rating_min, rating_max, slope = 1) {
    if (!is.finite(target) || length(step_cum) == 0) 
        return(NA_real_)
    if (target <= rating_min) 
        return(-Inf)
    if (target >= rating_max) 
        return(Inf)
    f <- function(eta) expected_score_from_eta_gpcm(eta, step_cum, slope, rating_min) - target
    lower <- -10
    upper <- 10
    f_low <- f(lower)
    f_up <- f(upper)
    if (!is.finite(f_low) || !is.finite(f_up)) 
        return(NA_real_)
    if (f_low * f_up > 0) {
        lower <- -20
        upper <- 20
        f_low <- f(lower)
        f_up <- f(upper)
        if (!is.finite(f_low) || !is.finite(f_up) || f_low * f_up > 0) 
            return(NA_real_)
    }
    uniroot(f, lower = lower, upper = upper, tol = 1e-10)$root
}

facet_anchor_status <- function(facet, levels, config) {
    spec <- if (facet == "Person") 
        config$theta_spec
    else config$facet_specs[[facet]]
    if (is.null(spec)) 
        return(rep("", length(levels)))
    anchors <- spec$anchors
    groups <- spec$groups
    status <- rep("", length(levels))
    if (!is.null(anchors)) {
        anchor_vals <- anchors[match(levels, names(anchors))]
        status[is.finite(anchor_vals)] <- "A"
    }
    if (!is.null(groups)) {
        group_vals <- groups[match(levels, names(groups))]
        status[status == "" & !is.na(group_vals) & group_vals != ""] <- "G"
    }
    status
}

calc_facets_report_tbls <- function(res, diagnostics, totalscore = TRUE, umean = 0, uscale = 1, udecimals = 2, 
    omit_unobserved = FALSE, xtreme = 0, xtreme_method = "display") {
    if (is.null(res) || is.null(diagnostics)) 
        return(list())
    obs_df <- diagnostics$obs
    measures <- diagnostics$measures
    if (nrow(obs_df) == 0 || nrow(measures) == 0) 
        return(list())
    prep <- res$prep
    config <- res$config
    rating_min <- prep$rating_min
    rating_max <- prep$rating_max
    sizes <- build_param_sizes(config)
    params <- expand_params(res$opt$par, sizes, config)
    theta_hat <- res$facets$person$Estimate
    reference_persons <- is.finite(theta_hat)
    person_mean_unbounded <- !any(reference_persons)
    theta_mean <- if (any(reference_persons)) 
        mean(theta_hat[reference_persons])
    else NA_real_
    facet_means <- purrr::map_dbl(config$facet_names, function(f) {
        mean(params$facets[[f]], na.rm = TRUE)
    })
    names(facet_means) <- config$facet_names
    facet_signs <- config$facet_signs
    if (is.null(facet_signs) || length(facet_signs) == 0) {
        facet_signs <- setNames(rep(-1, length(config$facet_names)), config$facet_names)
    }
    if (config$model == "RSM") {
        step_cum_common <- c(0, cumsum(params$steps))
        step_cum_mean <- step_cum_common
    }
    else {
        step_mat <- params$steps_mat
        if (is.null(step_mat) || length(step_mat) == 0) {
            step_cum_common <- numeric(0)
            step_cum_mean <- numeric(0)
        }
        else {
            step_mean <- colMeans(step_mat, na.rm = TRUE)
            step_cum_common <- t(apply(step_mat, 1, function(x) c(0, cumsum(x))))
            step_cum_mean <- c(0, cumsum(step_mean))
        }
    }
    facet_names <- c("Person", config$facet_names)
    facet_levels_all <- lapply(facet_names, function(facet) {
        if (facet == "Person") {
            prep$levels$Person
        }
        else {
            prep$levels[[facet]]
        }
    })
    names(facet_levels_all) <- facet_names
    extreme_levels <- purrr::map(facet_names, function(facet) {
        if (!facet %in% names(obs_df)) 
            return(character(0))
        pull(mutate(filter(summarize(group_by(obs_df, .data[[facet]]), MinScore = min(Observed, na.rm = TRUE), 
            MaxScore = max(Observed, na.rm = TRUE), .groups = "drop"), (MinScore == prep$rating_min & 
            MaxScore == prep$rating_min) | (MinScore == prep$rating_max & MaxScore == prep$rating_max)), 
            Level = as.character(.data[[facet]])), Level)
    })
    names(extreme_levels) <- facet_names
    retain_fixed_extremes <- identical(xtreme_method, "facets") || (identical(config$method, "JML") && 
        config$model %in% c("RSM", "PCM") && length(config$interaction_specs) == 0L)
    if (retain_fixed_extremes) 
        extreme_levels <- .mfrm_unanchored_extremes(res, obs_df)
    extreme_flags <- list()
    for (facet in facet_names) {
        if (facet %in% names(obs_df)) {
            extreme_flags[[facet]] <- obs_df[[facet]] %in% extreme_levels[[facet]]
        }
    }
    if (length(extreme_flags) > 0) {
        extreme_flag_df <- as_tibble(extreme_flags)
        extreme_count <- rowSums(extreme_flag_df, na.rm = TRUE)
    }
    else {
        extreme_count <- rep(0, nrow(obs_df))
    }
    out <- purrr::map(facet_names, function(facet) {
        if (!facet %in% names(obs_df)) 
            return(tibble())
        status_tbl <- select(mutate(summarize(group_by(obs_df, .data[[facet]]), MinScore = min(Observed, 
            na.rm = TRUE), MaxScore = max(Observed, na.rm = TRUE), TotalCountAll = n(), .groups = "drop"), 
            Level = as.character(.data[[facet]])), Level, MinScore, MaxScore, TotalCountAll)
        if (isTRUE(totalscore)) {
            score_source <- obs_df
        }
        else {
            flag <- extreme_flags[[facet]]
            if (is.null(flag)) {
                flag <- rep(FALSE, nrow(obs_df))
            }
            active_mask <- (extreme_count == 0) | ((extreme_count == 1) & flag)
            score_source <- obs_df[active_mask, , drop = FALSE]
        }
        score_tbl <- select(mutate(summarize(group_by(score_source, .data[[facet]]), TotalScore = sum(Observed, 
            na.rm = TRUE), TotalCount = n(), WeightdScore = sum(Observed * Weight, na.rm = TRUE), WeightdCount = sum(Weight, 
            na.rm = TRUE), ObservedAverage = ifelse(sum(Weight, na.rm = TRUE) > 0, sum(Observed * Weight, 
            na.rm = TRUE)/sum(Weight, na.rm = TRUE), NA_real_), .groups = "drop"), Level = as.character(.data[[facet]])), 
            Level, TotalScore, TotalCount, WeightdScore, WeightdCount, ObservedAverage)
        level_tbl <- tibble(Level = as.character(facet_levels_all[[facet]]))
        score_tbl <- mutate(left_join(level_tbl, score_tbl, by = "Level"), TotalScore = replace_na(TotalScore, 
            0), TotalCount = replace_na(TotalCount, 0), WeightdScore = replace_na(WeightdScore, 0), WeightdCount = replace_na(WeightdCount, 
            0), ObservedAverage = ifelse(WeightdCount > 0, ObservedAverage, NA_real_))
        meas_tbl <- select(mutate(filter(measures, Facet == facet), Level = as.character(Level)), Level, 
            Estimate, SE, ModelSE, RealSE, Infit, Outfit, InfitZSTD, OutfitZSTD, PTMEA, starts_with("PTMEAExpected"))
        tbl <- left_join(left_join(left_join(level_tbl, score_tbl, by = "Level"), status_tbl, by = "Level"), 
            meas_tbl, by = "Level")
        anchor_status <- facet_anchor_status(facet, tbl$Level, config)
        status <- dplyr::case_when(tbl$TotalCountAll == 0 ~ "No data", tbl$MinScore == tbl$MaxScore & 
            tbl$MinScore == rating_min ~ "Minimum", tbl$MinScore == tbl$MaxScore & tbl$MaxScore == rating_max ~ 
            "Maximum", tbl$TotalCountAll == 1 ~ "One datum", TRUE ~ "")
        if (retain_fixed_extremes) 
            status[anchor_status == "A" & status %in% c("Minimum", "Maximum")] <- ""
        sign_vec <- facet_signs[names(facet_means)]
        if (facet == "Person") {
            other_sum <- sum(sign_vec * facet_means, na.rm = TRUE)
            eta_m <- tbl$Estimate + other_sum
            eta_z <- tbl$Estimate
        }
        else {
            sign <- if (!is.null(facet_signs[[facet]])) 
                facet_signs[[facet]]
            else -1
            other_sum <- sum(sign_vec[names(facet_means) != facet] * facet_means[names(facet_means) != 
                facet], na.rm = TRUE)
            eta_m <- theta_mean + other_sum + sign * tbl$Estimate
            eta_z <- sign * tbl$Estimate
        }
        if (config$model %in% c("PCM", "GPCM") && !is.null(config$step_facet)) {
            step_levels <- prep$levels[[config$step_facet]]
            if (facet == config$step_facet && length(step_levels) > 0 && length(step_cum_common) > 0) {
                step_cum_list <- purrr::map(tbl$Level, function(lvl) {
                  idx <- match(lvl, step_levels)
                  if (is.na(idx) || idx < 1 || idx > nrow(step_cum_common)) {
                    step_cum_mean
                  }
                  else {
                    step_cum_common[idx, ]
                  }
                })
            }
            else {
                step_cum_list <- rep(list(step_cum_mean), nrow(tbl))
            }
        }
        else {
            step_cum_list <- rep(list(step_cum_common), nrow(tbl))
        }
        slope_facet <- config$slope_facet %||% config$step_facet
        if (config$model == "GPCM" && !is.null(slope_facet) && !is.null(params$slopes) && facet == slope_facet) {
            slope_levels <- prep$levels[[slope_facet]] %||% character(0)
            slopes_vec <- as.numeric(params$slopes)
            slope_list <- purrr::map_dbl(tbl$Level, function(lvl) {
                idx <- match(lvl, slope_levels)
                if (is.na(idx) || idx < 1L || idx > length(slopes_vec)) {
                  1
                }
                else {
                  slopes_vec[idx]
                }
            })
        }
        else {
            slope_list <- rep(1, nrow(tbl))
        }
        if (config$model == "GPCM") {
            fair_m <- purrr::pmap_dbl(list(eta_m, step_cum_list, slope_list), function(e, s, a) expected_score_from_eta_gpcm(e, 
                s, a, rating_min))
            fair_z <- purrr::pmap_dbl(list(eta_z, step_cum_list, slope_list), function(e, s, a) expected_score_from_eta_gpcm(e, 
                s, a, rating_min))
        }
        else {
            fair_m <- purrr::map2_dbl(eta_m, step_cum_list, ~expected_score_from_eta(.x, .y, rating_min))
            fair_z <- purrr::map2_dbl(eta_z, step_cum_list, ~expected_score_from_eta(.x, .y, rating_min))
        }
        if (identical(config$model, "PCM")) {
            pcm_fair <- function(eta) vapply(seq_len(nrow(tbl)), function(j) {
                rows <- which(as.character(score_source[[facet]]) == tbl$Level[j])
                if (!length(rows) || !is.finite(eta[j])) 
                  return(NA_real_)
                scale <- match(as.character(score_source[[config$step_facet]][rows]), prep$levels[[config$step_facet]])
                w <- get_weights(score_source)[rows]
                if (anyNA(scale) || any(!is.finite(w) | w < 0) || sum(w) <= 0) 
                  return(NA_real_)
                expected <- vapply(scale, function(k) expected_score_from_eta(eta[j], step_cum_common[k, 
                  ], rating_min), numeric(1))
                sum(w * expected)/sum(w)
            }, numeric(1))
            fair_m <- pcm_fair(eta_m)
            fair_z <- pcm_fair(eta_z)
        }
        display_xtreme <- if (identical(xtreme_method, "facets")) 
            0
        else xtreme
        xtreme_target <- ifelse(status == "Minimum", rating_min + display_xtreme, ifelse(status == "Maximum", 
            rating_max - display_xtreme, NA_real_))
        xtreme_eta <- purrr::pmap_dbl(list(xtreme_target, step_cum_list, slope_list), function(t, s, 
            a) {
            if (!is.finite(t) || display_xtreme <= 0) 
                return(NA_real_)
            estimate_eta_from_target(t, s, rating_min, rating_max, slope = a)
        })
        if (facet != "Person" && person_mean_unbounded) 
            xtreme_eta[] <- NA_real_
        xtreme_eta[anchor_status == "A"] <- NA_real_
        measure_logit <- tbl$Estimate
        if (any(is.finite(xtreme_eta))) {
            if (facet == "Person") {
                measure_logit <- ifelse(is.finite(xtreme_eta), xtreme_eta - other_sum, measure_logit)
            }
            else {
                sign <- if (!is.null(facet_signs[[facet]])) 
                  facet_signs[[facet]]
                else -1
                measure_logit <- ifelse(is.finite(xtreme_eta), (xtreme_eta - theta_mean - other_sum)/sign, 
                  measure_logit)
            }
        }
        adjusted_se <- rep(NA_real_, nrow(tbl))
        adjustment <- ifelse(is.finite(xtreme_eta), xtreme, 0)
        if (identical(xtreme_method, "facets")) {
            extrapolated <- .mfrm_extreme_report(res, obs_df, facet, tbl$Level, anchor_status, xtreme, 
                params)
            adjusted <- is.finite(extrapolated$measure)
            measure_logit[adjusted] <- extrapolated$measure[adjusted]
            xtreme_eta[adjusted] <- measure_logit[adjusted]
            adjusted_se <- extrapolated$se
            adjustment <- extrapolated$adjustment
            sign <- if (facet == "Person") 
                1
            else facet_signs[[facet]] %||% -1
            eta_m[adjusted] <- sign * measure_logit[adjusted] + other_sum + if (facet == "Person") 
                0
            else theta_mean
            eta_z[adjusted] <- sign * measure_logit[adjusted]
            if (config$model == "PCM") {
                fair_m[adjusted] <- pcm_fair(eta_m)[adjusted]
                fair_z[adjusted] <- pcm_fair(eta_z)[adjusted]
            }
            else {
                fair_m[adjusted] <- vapply(eta_m[adjusted], expected_score_from_eta, numeric(1), step_cum = step_cum_common, 
                  rating_min = rating_min)
                fair_z[adjusted] <- vapply(eta_z[adjusted], expected_score_from_eta, numeric(1), step_cum = step_cum_common, 
                  rating_min = rating_min)
            }
        }
        scale_factor <- ifelse(is.finite(uscale), uscale, 1)
        scale_origin <- ifelse(is.finite(umean), umean, 0)
        tbl <- arrange(transmute(mutate(tbl, Anchor = anchor_status, Status = status, FairM = fair_m, 
            FairZ = fair_z, FairMReference = if (facet == "Person") 
                "Mean of other facet measures"
            else if (person_mean_unbounded) 
                "Unavailable: no finite Person reference measures"
            else "Mean of finite fitted Person and other facet measures", FairMReferencePersons = sum(reference_persons), 
            FairMExcludedPersons = sum(!reference_persons), FairScoreBasis = if (config$model == "PCM") 
                "Weighted observation-scale expectations"
            else if (config$model == "RSM") 
                "Common rating-scale expectation"
            else "Native reference-slope expectation", PrimaryMeasure = as.numeric(Estimate) * scale_factor + 
                scale_origin, MeasureBasis = dplyr::case_when(is.finite(adjusted_se) ~ "FACETS total-score extrapolation", 
                is.finite(xtreme_eta) ~ "Extreme-score display only", is.finite(Estimate) ~ "Fitted estimate", 
                TRUE ~ "No finite fitted estimate"), ExtremeAdjustment = adjustment, MeasureSEBasis = ifelse(is.finite(adjusted_se), 
                "Conditional information at adjusted total; not original-MLE uncertainty", "Fitted measure or unavailable"), 
            Measure = as.numeric(ifelse(is.finite(measure_logit), measure_logit * scale_factor + scale_origin, 
                NA_real_)), .UnscaledModelSE = ModelSE, ModelSE = ifelse(is.finite(adjusted_se), abs(scale_factor) * 
                adjusted_se, ifelse(!is.finite(xtreme_eta) & is.finite(dplyr::coalesce(ModelSE, SE)), 
                abs(scale_factor) * dplyr::coalesce(ModelSE, SE), NA_real_)), RealSE = ifelse(is.finite(adjusted_se), 
                abs(scale_factor) * adjusted_se, ifelse(!is.finite(xtreme_eta) & is.finite(dplyr::coalesce(RealSE, 
                  .UnscaledModelSE, SE)), abs(scale_factor) * dplyr::coalesce(RealSE, .UnscaledModelSE * 
                  sqrt(pmax(dplyr::coalesce(Infit, 1), 1)), SE * sqrt(pmax(dplyr::coalesce(Infit, 1), 
                  1))), NA_real_)), Infit = ifelse(Status %in% c("Minimum", "Maximum"), NA_real_, Infit), 
            Outfit = ifelse(Status %in% c("Minimum", "Maximum"), NA_real_, Outfit), InfitZSTD = ifelse(Status %in% 
                c("Minimum", "Maximum"), NA_real_, InfitZSTD), OutfitZSTD = ifelse(Status %in% c("Minimum", 
                "Maximum"), NA_real_, OutfitZSTD)), TotalScore, TotalCount, WeightdScore, WeightdCount, 
            ObservedAverage, FairM, FairZ, FairMReference = .data$FairMReference, FairMReferencePersons, 
            FairMExcludedPersons, FairScoreBasis, Measure, PrimaryMeasure = .data$PrimaryMeasure, MeasureBasis = .data$MeasureBasis, 
            ExtremeAdjustment = .data$ExtremeAdjustment, MeasureSEBasis = .data$MeasureSEBasis, ModelSE, 
            RealSE, InfitMnSq = Infit, InfitZStd = InfitZSTD, OutfitMnSq = Outfit, OutfitZStd = OutfitZSTD, 
            PtMeaCorr = PTMEA, dplyr::across(dplyr::starts_with("PTMEAExpected")), Anchor, Status, Level, 
            TotalCountAll), desc(Measure), desc(TotalCount))
        if (isTRUE(omit_unobserved)) {
            tbl <- filter(tbl, TotalCountAll > 0)
        }
        select(tbl, -TotalCountAll)
    })
    names(out) <- facet_names
    out
}

format_facets_report_gt <- function(tbl, facet, decimals = 2, totalscore = TRUE, reference = c("both", 
    "mean", "zero"), label_style = c("both", "native", "legacy")) {
    reference <- match.arg(reference)
    label_style <- match.arg(label_style)
    if (is.null(tbl) || nrow(tbl) == 0) {
        return(data.frame(Message = "No facet report available.", stringsAsFactors = FALSE))
    }
    out <- as.data.frame(tbl, stringsAsFactors = FALSE)
    label_map <- c(TotalScore = if (isTRUE(totalscore)) "Total Score" else "Obsvd Score", TotalCount = if (isTRUE(totalscore)) "Total Count" else "Obsvd Count", 
        WeightdScore = "Weightd Score", WeightdCount = "Weightd Count", ObservedAverage = "Obsvd Average", 
        FairM = "Fair(M) Average", FairZ = "Fair(Z) Average", FairMSE = "Fair(M) S.E.", FairM_CI_Lower = "Fair(M) CI Lower", 
        FairM_CI_Upper = "Fair(M) CI Upper", FairM_CI_Level = "Fair(M) CI Level", FairM_SE_Method = "Fair(M) S.E. Method", 
        FairM_SE_Status = "Fair(M) S.E. Status", FairM_SE_Detail = "Fair(M) S.E. Detail", FairZSE = "Fair(Z) S.E.", 
        FairZ_CI_Lower = "Fair(Z) CI Lower", FairZ_CI_Upper = "Fair(Z) CI Upper", FairZ_CI_Level = "Fair(Z) CI Level", 
        FairZ_SE_Method = "Fair(Z) S.E. Method", FairZ_SE_Status = "Fair(Z) S.E. Status", FairZ_SE_Detail = "Fair(Z) S.E. Detail", 
        Measure = "Measure", ModelSE = "Model S.E.", RealSE = "Real S.E.", InfitMnSq = "Infit MnSq", 
        InfitZStd = "Infit ZStd", OutfitMnSq = "Outfit MnSq", OutfitZStd = "Outfit ZStd", PtMeaCorr = "PtMea Corr", 
        Anchor = "Anch", Status = "Status", Level = "Element")
    keep <- intersect(names(out), names(label_map))
    names(out)[match(keep, names(out))] <- unname(label_map[keep])
    if ("Element" %in% names(out)) {
        out <- out[, c(setdiff(names(out), "Element"), "Element"), drop = FALSE]
    }
    count_cols <- intersect(c("Total Score", "Total Count"), names(out))
    for (col in count_cols) out[[col]] <- round(as.numeric(out[[col]]), digits = 0)
    value_cols <- intersect(c("Weightd Score", "Weightd Count", "Obsvd Average", "Fair(M) Average", "Fair(Z) Average", 
        "Measure", "PrimaryMeasure", "Model S.E.", "Real S.E.", "Fair(M) S.E.", "Fair(M) CI Lower", "Fair(M) CI Upper", 
        "Fair(M) CI Level", "Fair(Z) S.E.", "Fair(Z) CI Lower", "Fair(Z) CI Upper", "Fair(Z) CI Level", 
        "Infit MnSq", "Infit ZStd", "Outfit MnSq", "Outfit ZStd", "PtMea Corr", "PTMEAExpected", "PTMEAExpectedAsymptotic"), 
        names(out))
    for (col in value_cols) out[[col]] <- round(as.numeric(out[[col]]), digits = decimals)
    if ("Obsvd Average" %in% names(out) && !"ObservedAverage" %in% names(out)) {
        out$ObservedAverage <- out[["Obsvd Average"]]
    }
    if ("Fair(M) Average" %in% names(out) && !"AdjustedAverage" %in% names(out)) {
        out$AdjustedAverage <- out[["Fair(M) Average"]]
    }
    if ("Fair(Z) Average" %in% names(out) && !"StandardizedAdjustedAverage" %in% names(out)) {
        out$StandardizedAdjustedAverage <- out[["Fair(Z) Average"]]
    }
    if ("Fair(M) S.E." %in% names(out) && !"AdjustedAverageSE" %in% names(out)) {
        out$AdjustedAverageSE <- out[["Fair(M) S.E."]]
    }
    if ("Fair(M) CI Lower" %in% names(out) && !"AdjustedAverageCI_Lower" %in% names(out)) {
        out$AdjustedAverageCI_Lower <- out[["Fair(M) CI Lower"]]
    }
    if ("Fair(M) CI Upper" %in% names(out) && !"AdjustedAverageCI_Upper" %in% names(out)) {
        out$AdjustedAverageCI_Upper <- out[["Fair(M) CI Upper"]]
    }
    if ("Fair(M) CI Level" %in% names(out) && !"AdjustedAverageCI_Level" %in% names(out)) {
        out$AdjustedAverageCI_Level <- out[["Fair(M) CI Level"]]
    }
    if ("Fair(M) S.E. Method" %in% names(out) && !"AdjustedAverageSEMethod" %in% names(out)) {
        out$AdjustedAverageSEMethod <- out[["Fair(M) S.E. Method"]]
    }
    if ("Fair(M) S.E. Status" %in% names(out) && !"AdjustedAverageSEStatus" %in% names(out)) {
        out$AdjustedAverageSEStatus <- out[["Fair(M) S.E. Status"]]
    }
    if ("Fair(M) S.E. Detail" %in% names(out) && !"AdjustedAverageSEDetail" %in% names(out)) {
        out$AdjustedAverageSEDetail <- out[["Fair(M) S.E. Detail"]]
    }
    if ("Fair(Z) S.E." %in% names(out) && !"StandardizedAdjustedAverageSE" %in% names(out)) {
        out$StandardizedAdjustedAverageSE <- out[["Fair(Z) S.E."]]
    }
    if ("Fair(Z) CI Lower" %in% names(out) && !"StandardizedAdjustedAverageCI_Lower" %in% names(out)) {
        out$StandardizedAdjustedAverageCI_Lower <- out[["Fair(Z) CI Lower"]]
    }
    if ("Fair(Z) CI Upper" %in% names(out) && !"StandardizedAdjustedAverageCI_Upper" %in% names(out)) {
        out$StandardizedAdjustedAverageCI_Upper <- out[["Fair(Z) CI Upper"]]
    }
    if ("Fair(Z) CI Level" %in% names(out) && !"StandardizedAdjustedAverageCI_Level" %in% names(out)) {
        out$StandardizedAdjustedAverageCI_Level <- out[["Fair(Z) CI Level"]]
    }
    if ("Fair(Z) S.E. Method" %in% names(out) && !"StandardizedAdjustedAverageSEMethod" %in% names(out)) {
        out$StandardizedAdjustedAverageSEMethod <- out[["Fair(Z) S.E. Method"]]
    }
    if ("Fair(Z) S.E. Status" %in% names(out) && !"StandardizedAdjustedAverageSEStatus" %in% names(out)) {
        out$StandardizedAdjustedAverageSEStatus <- out[["Fair(Z) S.E. Status"]]
    }
    if ("Fair(Z) S.E. Detail" %in% names(out) && !"StandardizedAdjustedAverageSEDetail" %in% names(out)) {
        out$StandardizedAdjustedAverageSEDetail <- out[["Fair(Z) S.E. Detail"]]
    }
    if ("Model S.E." %in% names(out) && !"ModelBasedSE" %in% names(out)) {
        out$ModelBasedSE <- out[["Model S.E."]]
    }
    if ("Real S.E." %in% names(out) && !"FitAdjustedSE" %in% names(out)) {
        out$FitAdjustedSE <- out[["Real S.E."]]
    }
    if (identical(reference, "mean")) {
        drop_cols <- intersect(c("Fair(Z) Average", "StandardizedAdjustedAverage", "Fair(Z) S.E.", "Fair(Z) CI Lower", 
            "Fair(Z) CI Upper", "Fair(Z) CI Level", "Fair(Z) S.E. Method", "Fair(Z) S.E. Status", "Fair(Z) S.E. Detail", 
            "StandardizedAdjustedAverageSE", "StandardizedAdjustedAverageCI_Lower", "StandardizedAdjustedAverageCI_Upper", 
            "StandardizedAdjustedAverageCI_Level", "StandardizedAdjustedAverageSEMethod", "StandardizedAdjustedAverageSEStatus", 
            "StandardizedAdjustedAverageSEDetail"), names(out))
        out <- out[, setdiff(names(out), drop_cols), drop = FALSE]
    }
    else if (identical(reference, "zero")) {
        drop_cols <- intersect(c("Fair(M) Average", "AdjustedAverage", "Fair(M) S.E.", "Fair(M) CI Lower", 
            "Fair(M) CI Upper", "Fair(M) CI Level", "Fair(M) S.E. Method", "Fair(M) S.E. Status", "Fair(M) S.E. Detail", 
            "AdjustedAverageSE", "AdjustedAverageCI_Lower", "AdjustedAverageCI_Upper", "AdjustedAverageCI_Level", 
            "AdjustedAverageSEMethod", "AdjustedAverageSEStatus", "AdjustedAverageSEDetail"), names(out))
        out <- out[, setdiff(names(out), drop_cols), drop = FALSE]
    }
    if (identical(label_style, "native")) {
        drop_cols <- intersect(c("Obsvd Average", "Fair(M) Average", "Fair(Z) Average", "Fair(M) S.E.", 
            "Fair(M) CI Lower", "Fair(M) CI Upper", "Fair(M) CI Level", "Fair(M) S.E. Method", "Fair(M) S.E. Status", 
            "Fair(M) S.E. Detail", "Fair(Z) S.E.", "Fair(Z) CI Lower", "Fair(Z) CI Upper", "Fair(Z) CI Level", 
            "Fair(Z) S.E. Method", "Fair(Z) S.E. Status", "Fair(Z) S.E. Detail", "Model S.E.", "Real S.E."), 
            names(out))
        out <- out[, setdiff(names(out), drop_cols), drop = FALSE]
    }
    else if (identical(label_style, "legacy")) {
        drop_cols <- intersect(c("ObservedAverage", "AdjustedAverage", "StandardizedAdjustedAverage", 
            "AdjustedAverageSE", "AdjustedAverageCI_Lower", "AdjustedAverageCI_Upper", "AdjustedAverageCI_Level", 
            "AdjustedAverageSEMethod", "AdjustedAverageSEStatus", "AdjustedAverageSEDetail", "StandardizedAdjustedAverageSE", 
            "StandardizedAdjustedAverageCI_Lower", "StandardizedAdjustedAverageCI_Upper", "StandardizedAdjustedAverageCI_Level", 
            "StandardizedAdjustedAverageSEMethod", "StandardizedAdjustedAverageSEStatus", "StandardizedAdjustedAverageSEDetail", 
            "ModelBasedSE", "FitAdjustedSE"), names(out))
        out <- out[, setdiff(names(out), drop_cols), drop = FALSE]
    }
    attr(out, "facet") <- facet
    attr(out, "totalscore") <- isTRUE(totalscore)
    attr(out, "reference") <- reference
    attr(out, "label_style") <- label_style
    out
}

compute_fair_average_value_from_par <- function(res, par, facet, level, metric = c("FairM", "FairZ")) {
    metric <- match.arg(metric)
    config <- res$config
    prep <- res$prep
    if (!identical(config$model, "GPCM")) 
        return(NA_real_)
    facet <- as.character(facet[1])
    level <- as.character(level[1])
    if (identical(facet, "Person") || !facet %in% config$facet_names) {
        return(NA_real_)
    }
    sizes <- build_param_sizes(config)
    params <- expand_params(par, sizes, config)
    facet_levels <- as.character(prep$levels[[facet]] %||% character(0))
    facet_idx <- match(level, facet_levels)
    if (is.na(facet_idx) || facet_idx < 1L) 
        return(NA_real_)
    theta_hat <- res$facets$person$Estimate
    theta_mean <- if (any(is.finite(theta_hat))) 
        mean(theta_hat[is.finite(theta_hat)])
    else NA_real_
    facet_means <- purrr::map_dbl(config$facet_names, function(f) {
        vals <- params$facets[[f]]
        if (length(vals) == 0L) 
            return(0)
        m <- mean(vals, na.rm = TRUE)
        if (is.finite(m)) 
            m
        else 0
    })
    names(facet_means) <- config$facet_names
    facet_signs <- config$facet_signs
    if (is.null(facet_signs) || length(facet_signs) == 0L) {
        facet_signs <- stats::setNames(rep(-1, length(config$facet_names)), config$facet_names)
    }
    sign_vec <- suppressWarnings(as.numeric(facet_signs[names(facet_means)]))
    sign_vec[!is.finite(sign_vec)] <- -1
    names(sign_vec) <- names(facet_means)
    sign <- suppressWarnings(as.numeric(facet_signs[[facet]] %||% -1))
    if (!is.finite(sign)) 
        sign <- -1
    estimate <- params$facets[[facet]][facet_idx]
    if (!is.finite(estimate)) 
        return(NA_real_)
    other_sum <- sum(sign_vec[names(facet_means) != facet] * facet_means[names(facet_means) != facet], 
        na.rm = TRUE)
    eta <- if (identical(metric, "FairM")) {
        theta_mean + other_sum + sign * estimate
    }
    else {
        sign * estimate
    }
    if (!is.finite(eta)) 
        return(NA_real_)
    step_mat <- params$steps_mat
    if (is.null(step_mat) || length(step_mat) == 0L) 
        return(NA_real_)
    step_profile <- colMeans(step_mat, na.rm = TRUE)
    step_facet <- config$step_facet %||% NA_character_
    if (!is.na(step_facet) && identical(facet, step_facet)) {
        step_levels <- as.character(prep$levels[[step_facet]] %||% character(0))
        step_idx <- match(level, step_levels)
        if (!is.na(step_idx) && step_idx >= 1L && step_idx <= nrow(step_mat)) {
            step_profile <- step_mat[step_idx, ]
        }
    }
    if (!all(is.finite(step_profile))) 
        return(NA_real_)
    step_cum <- c(0, cumsum(step_profile))
    slope <- 1
    slope_facet <- config$slope_facet %||% config$step_facet
    if (!is.null(slope_facet) && identical(facet, slope_facet) && !is.null(params$slopes)) {
        slope_levels <- as.character(prep$levels[[slope_facet]] %||% character(0))
        slope_idx <- match(level, slope_levels)
        if (!is.na(slope_idx) && slope_idx >= 1L && slope_idx <= length(params$slopes)) {
            slope <- params$slopes[slope_idx]
        }
    }
    expected_score_from_eta_gpcm(eta = eta, step_cum = step_cum, slope = slope, rating_min = prep$rating_min)
}

finite_difference_gradient <- function(fn, par, rel_step = 1e-05) {
    par <- as.numeric(par %||% numeric(0))
    if (length(par) == 0L) 
        return(numeric(0))
    grad <- rep(NA_real_, length(par))
    base <- tryCatch(fn(par), error = function(e) NA_real_)
    base <- suppressWarnings(as.numeric(base[1]))
    for (j in seq_along(par)) {
        h <- rel_step * max(1, abs(par[j]))
        par_p <- par
        par_m <- par
        par_p[j] <- par_p[j] + h
        par_m[j] <- par_m[j] - h
        f_p <- tryCatch(fn(par_p), error = function(e) NA_real_)
        f_m <- tryCatch(fn(par_m), error = function(e) NA_real_)
        f_p <- suppressWarnings(as.numeric(f_p[1]))
        f_m <- suppressWarnings(as.numeric(f_m[1]))
        if (is.finite(f_p) && is.finite(f_m)) {
            grad[j] <- (f_p - f_m)/(2 * h)
        }
        else if (is.finite(f_p) && is.finite(base)) {
            grad[j] <- (f_p - base)/h
        }
        else if (is.finite(f_m) && is.finite(base)) {
            grad[j] <- (base - f_m)/h
        }
    }
    grad
}

add_gpcm_fair_average_delta_se <- function(raw_tbls, res, covariance = NULL, ci_level = 0.95) {
    add_unavailable_columns <- function(tbl, status, detail) {
        if (is.null(tbl) || nrow(tbl) == 0L) 
            return(tbl)
        for (prefix in c("FairM", "FairZ")) {
            tbl[[paste0(prefix, "SE")]] <- NA_real_
            tbl[[paste0(prefix, "_CI_Lower")]] <- NA_real_
            tbl[[paste0(prefix, "_CI_Upper")]] <- NA_real_
            tbl[[paste0(prefix, "_CI_Level")]] <- ci_level
            tbl[[paste0(prefix, "_SE_Method")]] <- "not available"
            tbl[[paste0(prefix, "_SE_Status")]] <- status
            tbl[[paste0(prefix, "_SE_Detail")]] <- detail
        }
        tbl
    }
    if (!identical(res$config$model, "GPCM")) {
        return(raw_tbls)
    }
    covariance <- covariance %||% compute_mml_parameter_covariance(res)
    if (!covariance$status %in% c("ok", "regularized") || is.null(covariance$cov)) {
        return(lapply(raw_tbls, add_unavailable_columns, status = covariance$status, detail = covariance$detail))
    }
    par <- as.numeric(res$opt$par %||% numeric(0))
    cov_mat <- symmetrize_matrix(covariance$cov)
    z <- stats::qnorm((1 - ci_level)/2, lower.tail = FALSE)
    rating_min <- suppressWarnings(as.numeric(res$prep$rating_min %||% NA_real_))
    rating_max <- suppressWarnings(as.numeric(res$prep$rating_max %||% NA_real_))
    se_method <- if (identical(covariance$status, "regularized")) {
        "Structural delta method (MML observed information; regularized Hessian)"
    }
    else {
        "Structural delta method (MML observed information)"
    }
    se_detail <- paste("Propagates the structural covariance of facet, step, and slope", "parameters; MML person EAP estimates are conditioned on rather than", 
        "included in the Hessian.")
    caution <- mfrm_mml_information_caution(covariance)
    if (length(caution)) 
        se_detail <- paste(se_detail, paste(caution, collapse = " "))
    compute_one <- function(facet, level, estimate, metric) {
        if (!is.finite(estimate)) {
            return(list(se = NA_real_, lower = NA_real_, upper = NA_real_, status = "not available", 
                detail = "Fair-average estimate is not finite."))
        }
        if (identical(facet, "Person")) {
            return(list(se = NA_real_, lower = NA_real_, upper = NA_real_, status = "not available", 
                detail = paste("Person rows are not assigned structural fair-average SEs", "because MML person EAPs are not part of the structural", 
                  "observed-information Hessian.")))
        }
        fn <- function(p) {
            compute_fair_average_value_from_par(res = res, par = p, facet = facet, level = level, metric = metric)
        }
        grad <- finite_difference_gradient(fn, par)
        if (length(grad) != ncol(cov_mat) || !all(is.finite(grad))) {
            return(list(se = NA_real_, lower = NA_real_, upper = NA_real_, status = "not available", 
                detail = "The complete finite-difference gradient was not available."))
        }
        var <- as.numeric(t(grad) %*% cov_mat %*% grad)
        if (is.finite(var) && var < 0 && abs(var) < 1e-10) 
            var <- 0
        if (!is.finite(var) || var < 0) {
            return(list(se = NA_real_, lower = NA_real_, upper = NA_real_, status = "not available", 
                detail = "Delta-method variance was not positive."))
        }
        se <- sqrt(var)
        lower <- estimate - z * se
        upper <- estimate + z * se
        if (is.finite(rating_min)) 
            lower <- max(lower, rating_min)
        if (is.finite(rating_max)) 
            upper <- min(upper, rating_max)
        list(se = se, lower = lower, upper = upper, status = covariance$status, detail = se_detail)
    }
    out <- lapply(names(raw_tbls), function(facet) {
        tbl <- raw_tbls[[facet]]
        if (is.null(tbl) || nrow(tbl) == 0L) 
            return(tbl)
        facet_chr <- as.character(facet)
        for (prefix in c("FairM", "FairZ")) {
            estimate <- suppressWarnings(as.numeric(tbl[[prefix]]))
            vals <- lapply(seq_len(nrow(tbl)), function(i) {
                compute_one(facet = facet_chr, level = as.character(tbl$Level[i]), estimate = estimate[i], 
                  metric = prefix)
            })
            tbl[[paste0(prefix, "SE")]] <- vapply(vals, `[[`, numeric(1), "se")
            tbl[[paste0(prefix, "_CI_Lower")]] <- vapply(vals, `[[`, numeric(1), "lower")
            tbl[[paste0(prefix, "_CI_Upper")]] <- vapply(vals, `[[`, numeric(1), "upper")
            tbl[[paste0(prefix, "_CI_Level")]] <- ci_level
            tbl[[paste0(prefix, "_SE_Method")]] <- se_method
            tbl[[paste0(prefix, "_SE_Status")]] <- vapply(vals, `[[`, character(1), "status")
            tbl[[paste0(prefix, "_SE_Detail")]] <- vapply(vals, `[[`, character(1), "detail")
        }
        tbl
    })
    stats::setNames(out, names(raw_tbls))
}

validate_fair_measure_basis <- function(bundle) {
    method <- bundle$settings$xtreme_method %||% "display"
    if (length(method) != 1L || is.na(method) || !method %in% c("display", "facets")) 
        stop("Invalid saved extreme-score convention; recreate fair_average_table().", call. = FALSE)
    has_facets <- any(vapply(bundle$raw_by_facet, function(tbl) any(tbl$MeasureBasis == "FACETS total-score extrapolation", 
        na.rm = TRUE), logical(1)))
    if (has_facets && !identical(method, "facets")) 
        stop("Missing or inconsistent extreme-score convention; recreate fair_average_table().", call. = FALSE)
    if (any(vapply(bundle$raw_by_facet, function(tbl) {
        nrow(tbl) > 0L && !all(c("PrimaryMeasure", "MeasureBasis", "ExtremeAdjustment", "FairMReference") %in% 
            names(tbl))
    }, logical(1)))) {
        stop(paste("This saved table does not retain the fitted-measure and mean-reference basis.", "Recreate fair_average_table(fit, ...) with the original settings; no model refit is needed."), 
            call. = FALSE)
    }
    invisible(TRUE)
}

mfrmr_mml_withheld_fair_average <- function(fit) {
    boundary <- mfrmr_mml_population_boundary(fit$prep, fit$config)
    if (is.null(boundary)) 
        return(NULL)
    list(raw_by_facet = list(), by_facet = list(), stacked = tibble(), available = FALSE, status = boundary$status, 
        reason = boundary$reason)
}

calc_fair_average_bundle <- function(res, diagnostics, facets = NULL, totalscore = TRUE, umean = 0, uscale = 1, 
    udecimals = 2, reference = c("both", "mean", "zero"), label_style = c("both", "native", "legacy"), 
    omit_unobserved = FALSE, xtreme = 0, fair_se = FALSE, ci_level = 0.95, xtreme_method = "display") {
    withheld <- mfrmr_mml_withheld_fair_average(res)
    if (!is.null(withheld)) 
        return(withheld)
    reference <- match.arg(reference)
    label_style <- match.arg(label_style)
    raw_tbls <- calc_facets_report_tbls(res = res, diagnostics = diagnostics, totalscore = totalscore, 
        umean = umean, uscale = uscale, udecimals = udecimals, omit_unobserved = omit_unobserved, xtreme = xtreme, 
        xtreme_method = xtreme_method)
    if (is.null(raw_tbls) || length(raw_tbls) == 0) {
        return(list(raw_by_facet = list(), by_facet = list(), stacked = tibble()))
    }
    keep_names <- names(raw_tbls)
    if (!is.null(facets)) {
        keep_names <- intersect(keep_names, as.character(facets))
    }
    if (length(keep_names) == 0) {
        return(list(raw_by_facet = list(), by_facet = list(), stacked = tibble()))
    }
    raw_tbls <- raw_tbls[keep_names]
    if (isTRUE(fair_se)) {
        raw_tbls <- add_gpcm_fair_average_delta_se(raw_tbls = raw_tbls, res = res, covariance = NULL, 
            ci_level = ci_level)
        raw_tbls <- lapply(raw_tbls, function(tbl) {
            tbl$FairCIEligible <- rep(FALSE, nrow(tbl))
            available <- rep(FALSE, nrow(tbl))
            metrics <- switch(reference, mean = "FairM", zero = "FairZ", c("FairM", "FairZ"))
            for (metric in metrics) {
                cols <- paste0(metric, c("_CI_Lower", "_CI_Upper"))
                if (all(cols %in% names(tbl))) 
                  available <- available | (is.finite(tbl[[cols[1]]]) & is.finite(tbl[[cols[2]]]))
            }
            tbl$FairCIReportingUse <- ifelse(available, "diagnostic_only", "unavailable")
            tbl
        })
    }
    by_facet <- lapply(names(raw_tbls), function(facet) {
        tbl <- raw_tbls[[facet]]
        if (is.null(tbl) || nrow(tbl) == 0) {
            return(data.frame())
        }
        format_facets_report_gt(tbl = tbl, facet = facet, decimals = udecimals, totalscore = totalscore, 
            reference = reference, label_style = label_style)
    })
    names(by_facet) <- names(raw_tbls)
    by_facet <- by_facet[vapply(by_facet, nrow, integer(1)) > 0]
    stacked <- if (length(by_facet) == 0) {
        tibble()
    }
    else {
        select(dplyr::bind_rows(lapply(names(by_facet), function(facet) {
            df <- by_facet[[facet]]
            df$Facet <- facet
            df
        })), "Facet", everything())
    }
    list(raw_by_facet = raw_tbls, by_facet = by_facet, stacked = stacked)
}


marginal_probability_rows <- function(probability) {
    probability <- as.matrix(probability)
    rowSums(!is.finite(probability) | probability < 0 | probability > 1) == 0L & abs(rowSums(probability) - 
        1) <= sqrt(.Machine$double.eps)
}

marginal_flag_coverage <- function(flag, screen) {
    flag <- as.logical(flag)
    classified <- sum(!is.na(flag))
    data.frame(Screen = screen, Total = length(flag), Classified = classified, Unclassified = sum(is.na(flag)), 
        Flagged = if (classified) 
            sum(flag, na.rm = TRUE)
        else NA_integer_)
}

validate_marginal_coverage <- function(bundle) {
    if (isTRUE(bundle$available) && !identical(bundle$coverage_version, 1L)) {
        stop(paste("This saved marginal-fit result lacks classification coverage.", "Recreate diagnostics with diagnose_mfrm(fit, diagnostic_mode = \"both\") and the original settings."), 
            call. = FALSE)
    }
    invisible(bundle)
}

compute_mml_expected_category_diagnostics <- function(res, include_p_geq = FALSE) {
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    model <- as.character(res$config$model %||% res$summary$Model[1] %||% NA_character_)
    if (!identical(method, "MML")) {
        return(list(available = FALSE, reason = "Strict marginal diagnostics currently require an MML fit."))
    }
    if (!model %in% c("RSM", "PCM", "GPCM")) {
        return(list(available = FALSE, reason = "Strict marginal diagnostics are currently implemented only for RSM, PCM, and GPCM."))
    }
    prep <- res$prep
    config <- res$config
    idx <- build_indices(prep, step_facet = config$step_facet, slope_facet = config$slope_facet, interaction_specs = config$interaction_specs)
    sizes <- build_param_sizes(config)
    params <- expand_params(res$opt$par, sizes, config)
    quad_points <- max(1L, as.integer(config$estimation_control$quad_points %||% 15L))
    quad <- gauss_hermite_normal(quad_points)
    base_eta <- compute_base_eta(idx, params, config)
    logprob_bundle <- mfrm_mml_logprob_bundle(idx = idx, config = config, quad = quad, params = params, 
        base_eta = base_eta, include_probs = TRUE)
    posterior_bundle <- mfrm_mml_posterior_bundle(logprob_bundle)
    expected_bundle <- mfrm_mml_expected_category_bundle(logprob_bundle = logprob_bundle, posterior_bundle = posterior_bundle, 
        include_p_geq = include_p_geq)
    weights <- idx$weight
    if (is.null(weights) || length(weights) == 0L) {
        weights <- rep(1, nrow(prep$data))
    }
    list(available = TRUE, prep = prep, config = config, idx = idx, params = params, quad = quad, logprob_bundle = logprob_bundle, 
        posterior_bundle = posterior_bundle, expected_bundle = expected_bundle, weights = weights, observed_cat = idx$score_k + 
            prep$rating_min, categories = seq(prep$rating_min, prep$rating_max))
}

summarize_marginal_fit_grid <- function(group_df, observed_cat, posterior_prob, weights, categories, 
    abs_z_warn = 2, rmsd_warn = 0.05) {
    n <- length(observed_cat)
    if (is.null(group_df) || ncol(as.data.frame(group_df)) == 0L) {
        group_df <- data.frame(Scope = rep("All", n), stringsAsFactors = FALSE)
    }
    else {
        group_df <- as.data.frame(group_df, stringsAsFactors = FALSE)
    }
    if (nrow(group_df) != n) {
        stop("`group_df` must have one row per observation.", call. = FALSE)
    }
    posterior_prob <- as.matrix(posterior_prob)
    if (!identical(dim(posterior_prob), c(n, length(categories))) || length(weights) != n) {
        stop("Probabilities and weights must match the observations and categories.", call. = FALSE)
    }
    if (!n) 
        return(list(cell_stats = tibble(), summary_stats = tibble()))
    valid_probability <- marginal_probability_rows(posterior_prob)
    group_cols <- names(group_df)
    group_key <- do.call(paste, c(lapply(group_df[group_cols], function(x) ifelse(is.na(x), "<NA>", as.character(x))), 
        sep = "\r"))
    split_idx <- split(seq_len(n), group_key, drop = TRUE)
    exemplar_idx <- vapply(split_idx, `[`, integer(1), 1)
    group_index_tbl <- group_df[exemplar_idx, group_cols, drop = FALSE]
    rownames(group_index_tbl) <- NULL
    n_groups <- length(split_idx)
    k_cat <- length(categories)
    total_cells <- n_groups * k_cat
    obs_n_out <- integer(total_cells)
    avail_n_out <- integer(total_cells)
    unavail_n_out <- integer(total_cells)
    grp_cnt_out <- numeric(total_cells)
    obs_cnt_out <- numeric(total_cells)
    exp_cnt_out <- numeric(total_cells)
    var_cnt_out <- numeric(total_cells)
    for (i in seq_len(n_groups)) {
        idx_g <- split_idx[[i]]
        probs_g <- posterior_prob[idx_g, , drop = FALSE]
        w_g <- weights[idx_g]
        weight_ok <- is.finite(w_g) & w_g >= 0
        active <- !weight_ok | w_g > 0
        observed_ok <- is.finite(observed_cat[idx_g]) & observed_cat[idx_g] %in% categories
        usable <- weight_ok & (!active | (observed_ok & valid_probability[idx_g]))
        observed_complete <- all(weight_ok & (!active | observed_ok))
        expected_complete <- all(weight_ok & (!active | valid_probability[idx_g]))
        total_w <- if (all(weight_ok)) 
            sum(w_g)
        else NA_real_
        base <- (i - 1L) * k_cat
        slots <- base + seq_len(k_cat)
        obs_n_out[slots] <- length(idx_g)
        avail_n_out[slots] <- sum(usable)
        unavail_n_out[slots] <- sum(!usable)
        grp_cnt_out[slots] <- total_w
        if (observed_complete) {
            obs_sub <- observed_cat[idx_g]
            for (j in seq_len(k_cat)) {
                obs_cnt_out[base + j] <- sum(w_g[active & obs_sub == categories[j]])
            }
        }
        else {
            obs_cnt_out[slots] <- NA_real_
        }
        if (expected_complete) {
            w_act <- w_g[active]
            w2_act <- w_act^2
            probs_act <- probs_g[active, , drop = FALSE]
            for (j in seq_len(k_cat)) {
                pj <- probs_act[, j]
                exp_cnt_out[base + j] <- sum(w_act * pj)
                var_cnt_out[base + j] <- sum(w2_act * pj * pmax(1 - pj, 0))
            }
        }
        else {
            exp_cnt_out[slots] <- NA_real_
            var_cnt_out[slots] <- NA_real_
        }
    }
    resid_cnt_out <- obs_cnt_out - exp_cnt_out
    w_pos <- is.finite(grp_cnt_out) & grp_cnt_out > 0
    obs_prop_out <- rep(NA_real_, total_cells)
    exp_prop_out <- rep(NA_real_, total_cells)
    obs_prop_out[w_pos] <- obs_cnt_out[w_pos]/grp_cnt_out[w_pos]
    exp_prop_out[w_pos] <- exp_cnt_out[w_pos]/grp_cnt_out[w_pos]
    prop_diff_out <- obs_prop_out - exp_prop_out
    sq_prop_diff_out <- prop_diff_out^2
    v_pos <- is.finite(var_cnt_out) & var_cnt_out > 0
    std_resid_out <- rep(NA_real_, total_cells)
    std_resid_out[v_pos] <- resid_cnt_out[v_pos]/sqrt(var_cnt_out[v_pos])
    flagged_z_out <- rep(NA, total_cells)
    sr_fin <- is.finite(std_resid_out)
    flagged_z_out[sr_fin] <- abs(std_resid_out[sr_fin]) >= abs_z_warn
    grp_rep <- rep(seq_len(n_groups), each = k_cat)
    cell_stats <- bind_cols(group_index_tbl[grp_rep, , drop = FALSE], tibble(Category = rep(categories, 
        times = n_groups), Observations = obs_n_out, AvailableObservations = avail_n_out, UnavailableObservations = unavail_n_out, 
        GroupCount = grp_cnt_out, ObservedCount = obs_cnt_out, ExpectedCount = exp_cnt_out, VarianceCount = var_cnt_out, 
        ResidualCount = resid_cnt_out, ObservedProp = obs_prop_out, ExpectedProp = exp_prop_out, PropDiff = prop_diff_out, 
        SquaredPropDiff = sq_prop_diff_out, StdResidual = std_resid_out, FlaggedAbsZ = flagged_z_out))
    rownames(cell_stats) <- NULL
    summary_stats <- mutate(summarize(group_by(cell_stats, across(all_of(group_cols))), GroupCount = dplyr::first(.data$GroupCount), 
        Observations = dplyr::first(.data$Observations), AvailableObservations = dplyr::first(.data$AvailableObservations), 
        UnavailableObservations = dplyr::first(.data$UnavailableObservations), ObservedCountTotal = sum(.data$ObservedCount), 
        ExpectedCountTotal = sum(.data$ExpectedCount), RMSD = if (all(is.finite(.data$SquaredPropDiff))) 
            sqrt(mean(.data$SquaredPropDiff))
        else NA_real_, Cells = dplyr::n(), ClassifiedCells = sum(!is.na(.data$FlaggedAbsZ)), UnclassifiedCells = sum(is.na(.data$FlaggedAbsZ)), 
        MaxAbsStdResidual = if (all(!is.finite(.data$StdResidual))) {
            NA_real_
        }
        else {
            max(abs(.data$StdResidual), na.rm = TRUE)
        }, FlaggedCellCount = if (any(!is.na(.data$FlaggedAbsZ))) 
            sum(.data$FlaggedAbsZ, na.rm = TRUE)
        else NA_integer_, .groups = "drop"), FlaggedRMSD = ifelse(is.finite(.data$RMSD), .data$RMSD >= 
        rmsd_warn, NA), Flagged = ifelse(.data$FlaggedCellCount > 0, TRUE, ifelse(.data$UnclassifiedCells > 
        0, NA, FALSE)) | .data$FlaggedRMSD)
    list(cell_stats = cell_stats, summary_stats = summary_stats)
}

build_marginal_fit_guidance <- function(pairwise_available = FALSE) {
    rows <- list(tibble(Component = "first_order_category_counts", StatisticLabel = "strict marginal category residual", 
        LiteratureSeries = "limited_information_inspired_marginal_screen", PrimaryRole = "category / facet screening", 
        InferenceTier = "exploratory", SupportsFormalInference = FALSE, FormalInferenceEligible = FALSE, 
        PrimaryReportingEligible = FALSE, ClassificationSystem = "screening", ReportingUse = "screening_only", 
        InterpretationNote = "Expected counts condition on the same responses. Residual scales omit cross-response covariance and calibration uncertainty; use flags for exploratory review, not formal inference."))
    rows[[length(rows) + 1L]] <- tibble(Component = "pairwise_local_dependence", StatisticLabel = "strict pairwise agreement residual", 
        LiteratureSeries = if (isTRUE(pairwise_available)) {
            "agreement_screen_informed_by_generalized_residual_logic"
        }
        else {
            "agreement_screen_informed_by_generalized_residual_logic_not_available"
        }, PrimaryRole = "local dependence follow-up", InferenceTier = "exploratory", SupportsFormalInference = FALSE, 
        FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, ClassificationSystem = "screening", 
        ReportingUse = "screening_only", InterpretationNote = if (isTRUE(pairwise_available)) {
            "Use as an exploratory local-dependence follow-up after first-order marginal screening; this is informed by generalized-residual logic but is not a formal Haberman-Sinharay generalized residual test."
        }
        else {
            "Reserved for exploratory local-dependence follow-up when pairwise comparisons are available."
        })
    rows[[length(rows) + 1L]] <- tibble(Component = "posterior_predictive_follow_up", StatisticLabel = "posterior predictive follow-up", 
        LiteratureSeries = "posterior_predictive_model_check_follow_up", PrimaryRole = "misfit corroboration / practical-significance follow-up", 
        InferenceTier = "exploratory", SupportsFormalInference = FALSE, FormalInferenceEligible = FALSE, 
        PrimaryReportingEligible = FALSE, ClassificationSystem = "screening", ReportingUse = "screening_only", 
        InterpretationNote = "mfrmr does not compute posterior predictive checks. If they are obtained from external Bayesian software, use them only to corroborate strict marginal flags and assess practical significance.")
    bind_rows(rows)
}

build_diagnostic_basis_guide <- function(diagnostic_mode = c("legacy", "marginal_fit", "both"), marginal_fit = NULL) {
    diagnostic_mode <- match.arg(diagnostic_mode, c("legacy", "marginal_fit", "both"))
    legacy_requested <- diagnostic_mode %in% c("legacy", "both")
    marginal_requested <- diagnostic_mode %in% c("marginal_fit", "both")
    marginal_available <- is.list(marginal_fit) && isTRUE(marginal_fit$available)
    pairwise_available <- marginal_available && is.list(marginal_fit$pairwise) && isTRUE(marginal_fit$pairwise$available)
    tibble(DiagnosticPath = c("legacy_residual_fit", "strict_marginal_fit", "strict_pairwise_local_dependence", 
        "posterior_predictive_follow_up"), Component = c("element_residual_fit", "first_order_category_counts", 
        "pairwise_local_dependence", "posterior_predictive_follow_up"), Status = c(if (legacy_requested) "computed" else "available_but_not_requested", 
        if (marginal_requested && marginal_available) {
            "computed"
        } else if (marginal_requested) {
            "requested_not_available"
        } else {
            "not_requested"
        }, if (marginal_requested && pairwise_available) {
            "computed"
        } else if (marginal_requested && marginal_available) {
            "not_available_for_run"
        } else if (marginal_requested) {
            "requested_not_available"
        } else {
            "not_requested"
        }, "not_available"), Basis = c("plugin_residuals_and_eap_tables", "latent_integrated_first_order_counts", 
        "latent_integrated_second_order_agreement", "posterior_predictive_replication"), PrimaryStatistics = c("Infit / Outfit / ZSTD / PTMEA / residual QC bundles", 
        "category residuals / standardized residuals / RMSD", "exact and adjacent agreement residuals", 
        "replicated-data discrepancy checks"), ReportingUse = c("legacy_compatibility_screen", "screening_only", 
        "screening_only", "screening_only"), InterpretationNote = c("Legacy fit statistics use saved MML EAPs or JML optimizer coordinates, not latent-integrated marginal evidence. ConQuest parameter fit additionally aggregates through the response design and averages over posterior distributions; these row statistics are not equivalent. Inspect obs$PersonMeasureBasis, obs$ResponseReason and fit$FitUnavailableRows; incomplete mean-square scopes are unavailable.", 
        "Category expectations integrate over the Person posterior conditioned on the same responses, with fitted calibration fixed; inspect classification coverage before interpreting this exploratory screen.", 
        "Strict pairwise local-dependence checks are exploratory follow-ups to first-order marginal flags, not standalone inferential tests.", 
        "Posterior predictive checks are not computed by mfrmr; use external Bayesian software when this corroborating analysis is required."))
}

calc_marginal_pairwise_bundle <- function(expected_core, abs_z_warn = 2, exact_gap_warn = 0.1, adjacent_gap_warn = 0.1) {
    prep <- expected_core$prep
    config <- expected_core$config
    prob_list <- expected_core$logprob_bundle$prob_list
    obs_posterior <- expected_core$posterior_bundle$obs_posterior
    observed_cat <- expected_core$observed_cat
    weights <- expected_core$weights
    n <- length(observed_cat)
    k_cat <- length(expected_core$categories)
    if (length(config$facet_names) == 0L || length(prob_list) == 0L || n == 0L) {
        return(list(available = FALSE, reason = "No facet-wise pairwise contexts were available for strict second-order diagnostics."))
    }
    adjacent_mask <- abs(row(matrix(0, k_cat, k_cat)) - col(matrix(0, k_cat, k_cat))) <= 1L
    adjacent_cells <- which(adjacent_mask, arr.ind = TRUE)
    valid_posterior <- marginal_probability_rows(obs_posterior)
    valid_probability <- Reduce(`&`, lapply(prob_list, marginal_probability_rows))
    obs_cat_valid <- is.finite(observed_cat) & (observed_cat %in% expected_core$categories)
    w_nonneg_fin <- is.finite(weights) & (weights >= 0)
    combn_cache <- vector("list", 16L)
    facet_chunks <- vector("list", length(config$facet_names))
    chunk_count <- 0L
    for (facet in config$facet_names) {
        context_cols <- c("Person", setdiff(config$facet_names, facet))
        if (!all(context_cols %in% names(prep$data)) || !facet %in% names(prep$data)) {
            next
        }
        facet_levels <- as.character(prep$data[[facet]])
        level_rank <- match(facet_levels, sort(unique(facet_levels), method = "radix"))
        context_df <- prep$data[, context_cols, drop = FALSE]
        context_df[] <- lapply(context_df, function(x) ifelse(is.na(x), "<NA>", as.character(x)))
        group_key <- do.call(paste, c(unname(context_df), sep = "\r"))
        split_idx <- split(seq_len(n), group_key, drop = TRUE)
        grp_lens <- lengths(split_idx)
        active_grps <- which(grp_lens >= 2L)
        if (length(active_grps) == 0L) 
            next
        cap <- as.integer(sum(as.double(grp_lens[active_grps]) * as.double(grp_lens[active_grps] - 1L)/2))
        if (cap == 0L) 
            next
        c_l1 <- character(cap)
        c_l2 <- character(cap)
        c_ri <- integer(cap)
        c_rj <- integer(cap)
        c_pw <- numeric(cap)
        c_eval <- logical(cap)
        c_obs_ex <- numeric(cap)
        c_obs_adj <- numeric(cap)
        cur <- 0L
        for (g_idx in active_grps) {
            idx_g <- split_idx[[g_idx]]
            m_len <- length(idx_g)
            level_vals <- facet_levels[idx_g]
            if (length(unique(level_vals)) < 2L) 
                next
            if (m_len <= length(combn_cache)) {
                pair_mat <- combn_cache[[m_len]]
                if (is.null(pair_mat)) {
                  pair_mat <- utils::combn(m_len, 2L)
                  combn_cache[[m_len]] <- pair_mat
                }
            }
            else {
                pair_mat <- utils::combn(m_len, 2L)
            }
            if (length(pair_mat) == 0L) 
                next
            same_posterior <- all(valid_posterior[idx_g]) && all(obs_posterior[idx_g, , drop = FALSE] == 
                rep(obs_posterior[idx_g[1L], ], each = m_len))
            for (col_idx in seq_len(ncol(pair_mat))) {
                row_i <- idx_g[pair_mat[1L, col_idx]]
                row_j <- idx_g[pair_mat[2L, col_idx]]
                level_i <- facet_levels[row_i]
                level_j <- facet_levels[row_j]
                if (!nzchar(level_i) || !nzchar(level_j) || identical(level_i, level_j)) 
                  next
                ri_rk <- level_rank[row_i]
                rj_rk <- level_rank[row_j]
                if (is.na(ri_rk) || is.na(rj_rk)) {
                  lp <- sort(c(level_i, level_j), method = "radix")
                  lv1 <- lp[1L]
                  lv2 <- lp[2L]
                }
                else if (ri_rk < rj_rk) {
                  lv1 <- level_i
                  lv2 <- level_j
                }
                else {
                  lv1 <- level_j
                  lv2 <- level_i
                }
                pair_weight <- weights[row_i] * weights[row_j]
                if (is.finite(pair_weight) && pair_weight == 0) 
                  next
                if (!w_nonneg_fin[row_i] || !w_nonneg_fin[row_j] || !is.finite(pair_weight)) {
                  pair_weight <- NA_real_
                }
                posterior_ok <- same_posterior || (valid_posterior[row_i] && valid_posterior[row_j] && 
                  isTRUE(all.equal(obs_posterior[row_i, ], obs_posterior[row_j, ], tolerance = sqrt(.Machine$double.eps))))
                observed_ok <- obs_cat_valid[row_i] && obs_cat_valid[row_j]
                obs_exact <- if (observed_ok) 
                  as.numeric(observed_cat[row_i] == observed_cat[row_j])
                else NA_real_
                obs_adjacent <- if (observed_ok) 
                  as.numeric(abs(observed_cat[row_i] - observed_cat[row_j]) <= 1)
                else NA_real_
                cur <- cur + 1L
                c_l1[cur] <- lv1
                c_l2[cur] <- lv2
                c_ri[cur] <- row_i
                c_rj[cur] <- row_j
                c_pw[cur] <- pair_weight
                c_eval[cur] <- posterior_ok && valid_probability[row_i] && valid_probability[row_j]
                c_obs_ex[cur] <- obs_exact
                c_obs_adj[cur] <- obs_adjacent
            }
        }
        if (cur > 0L) {
            keep <- seq_len(cur)
            chunk_count <- chunk_count + 1L
            facet_chunks[[chunk_count]] <- list(Facet = rep(facet, cur), Level1 = c_l1[keep], Level2 = c_l2[keep], 
                row_i = c_ri[keep], row_j = c_rj[keep], PairWeight = c_pw[keep], eval_ok = c_eval[keep], 
                obs_exact = c_obs_ex[keep], obs_adjacent = c_obs_adj[keep])
        }
    }
    if (chunk_count == 0L) {
        return(list(available = FALSE, reason = "No within-context pairwise comparisons were available for strict second-order diagnostics."))
    }
    facet_chunks <- facet_chunks[seq_len(chunk_count)]
    facet_all <- unlist(lapply(facet_chunks, `[[`, "Facet"), use.names = FALSE)
    level1_all <- unlist(lapply(facet_chunks, `[[`, "Level1"), use.names = FALSE)
    level2_all <- unlist(lapply(facet_chunks, `[[`, "Level2"), use.names = FALSE)
    row_i_all <- unlist(lapply(facet_chunks, `[[`, "row_i"), use.names = FALSE)
    row_j_all <- unlist(lapply(facet_chunks, `[[`, "row_j"), use.names = FALSE)
    pw_all <- unlist(lapply(facet_chunks, `[[`, "PairWeight"), use.names = FALSE)
    eval_ok_all <- unlist(lapply(facet_chunks, `[[`, "eval_ok"), use.names = FALSE)
    obs_exact_all <- unlist(lapply(facet_chunks, `[[`, "obs_exact"), use.names = FALSE)
    obs_adj_all <- unlist(lapply(facet_chunks, `[[`, "obs_adjacent"), use.names = FALSE)
    n_total_pairs <- length(row_i_all)
    exp_exact_all <- rep(NA_real_, n_total_pairs)
    exp_adjacent_all <- rep(NA_real_, n_total_pairs)
    eval_idx <- which(eval_ok_all)
    if (length(eval_idx) > 0L) {
        if (isTRUE(getOption("mfrmr.use_cpp11_backend", TRUE)) && mfrm_cpp11_backend_available()) {
            cpp_pair <- mfrm_cpp_marginal_pairwise_expectations(prob_list = prob_list, obs_posterior = obs_posterior, 
                row_i = row_i_all[eval_idx], row_j = row_j_all[eval_idx], adj_col1 = as.integer(adjacent_cells[, 
                  1L]), adj_col2 = as.integer(adjacent_cells[, 2L]))
            exp_exact_all[eval_idx] <- cpp_pair$exp_exact
            exp_adjacent_all[eval_idx] <- cpp_pair$exp_adjacent
        }
        else {
            used_rows <- unique(c(row_i_all[eval_idx], row_j_all[eval_idx]))
            row_probs <- vector("list", n)
            for (r in used_rows) {
                row_probs[[r]] <- matrix(vapply(prob_list, function(prob) prob[r, ], numeric(k_cat)), 
                  nrow = k_cat)
            }
            adj1 <- adjacent_cells[, 1L]
            adj2 <- adjacent_cells[, 2L]
            for (pos in eval_idx) {
                ri <- row_i_all[pos]
                rj <- row_j_all[pos]
                prob_i <- row_probs[[ri]]
                prob_j <- row_probs[[rj]]
                posterior <- obs_posterior[ri, ]
                exact_q <- colSums(prob_i * prob_j)
                adjacent_q <- colSums(prob_i[adj1, , drop = FALSE] * prob_j[adj2, , drop = FALSE])
                exp_exact_all[pos] <- sum(posterior * exact_q)
                exp_adjacent_all[pos] <- sum(posterior * adjacent_q)
            }
        }
    }
    usable_all <- is.finite(pw_all) & is.finite(exp_exact_all) & is.finite(exp_adjacent_all) & is.finite(obs_exact_all) & 
        is.finite(obs_adj_all)
    pair_rows_df <- tibble(Facet = facet_all, Level1 = level1_all, Level2 = level2_all, PairWeight = pw_all, 
        Available = usable_all, ObservedExactCount = pw_all * obs_exact_all, ExpectedExactCount = pw_all * 
            exp_exact_all, ExactVarianceCount = (pw_all^2) * exp_exact_all * pmax(1 - exp_exact_all, 
            0), ObservedAdjacentCount = pw_all * obs_adj_all, ExpectedAdjacentCount = pw_all * exp_adjacent_all, 
        AdjacentVarianceCount = (pw_all^2) * exp_adjacent_all * pmax(1 - exp_adjacent_all, 0), SquaredExactDiff = (obs_exact_all - 
            exp_exact_all)^2, SquaredAdjacentDiff = (obs_adj_all - exp_adjacent_all)^2)
    pair_stats <- mutate(mutate(summarize(group_by(pair_rows_df, .data$Facet, .data$Level1, .data$Level2), 
        LevelPairCount = dplyr::n(), AvailableContextPairs = sum(.data$Available), UnavailableContextPairs = sum(!.data$Available), 
        OpportunityWeight = sum(.data$PairWeight), ObservedExactCount = sum(.data$ObservedExactCount), 
        ExpectedExactCount = sum(.data$ExpectedExactCount), ExactVarianceCount = sum(.data$ExactVarianceCount), 
        ObservedAdjacentCount = sum(.data$ObservedAdjacentCount), ExpectedAdjacentCount = sum(.data$ExpectedAdjacentCount), 
        AdjacentVarianceCount = sum(.data$AdjacentVarianceCount), ExactRMSD = sqrt(stats::weighted.mean(.data$SquaredExactDiff, 
            .data$PairWeight)), AdjacentRMSD = sqrt(stats::weighted.mean(.data$SquaredAdjacentDiff, .data$PairWeight)), 
        .groups = "drop"), ExactAgreement = ifelse(.data$OpportunityWeight > 0, .data$ObservedExactCount/.data$OpportunityWeight, 
        NA_real_), ExpectedExactAgreement = ifelse(.data$OpportunityWeight > 0, .data$ExpectedExactCount/.data$OpportunityWeight, 
        NA_real_), ExactGap = .data$ExactAgreement - .data$ExpectedExactAgreement, ExactStdResidual = ifelse(is.finite(.data$ExactVarianceCount) & 
        .data$ExactVarianceCount > 0, (.data$ObservedExactCount - .data$ExpectedExactCount)/sqrt(.data$ExactVarianceCount), 
        NA_real_), AdjacentAgreement = ifelse(.data$OpportunityWeight > 0, .data$ObservedAdjacentCount/.data$OpportunityWeight, 
        NA_real_), ExpectedAdjacentAgreement = ifelse(.data$OpportunityWeight > 0, .data$ExpectedAdjacentCount/.data$OpportunityWeight, 
        NA_real_), AdjacentGap = .data$AdjacentAgreement - .data$ExpectedAdjacentAgreement, AdjacentStdResidual = ifelse(is.finite(.data$AdjacentVarianceCount) & 
        .data$AdjacentVarianceCount > 0, (.data$ObservedAdjacentCount - .data$ExpectedAdjacentCount)/sqrt(.data$AdjacentVarianceCount), 
        NA_real_), FlaggedExact = ifelse(is.finite(.data$ExactStdResidual), abs(.data$ExactStdResidual) >= 
        abs_z_warn, NA) | ifelse(is.finite(.data$ExactGap), abs(.data$ExactGap) >= exact_gap_warn, NA), 
        FlaggedAdjacent = ifelse(is.finite(.data$AdjacentStdResidual), abs(.data$AdjacentStdResidual) >= 
            abs_z_warn, NA) | ifelse(is.finite(.data$AdjacentGap), abs(.data$AdjacentGap) >= adjacent_gap_warn, 
            NA), Flagged = .data$FlaggedExact | .data$FlaggedAdjacent), InferenceTier = "exploratory", 
        SupportsFormalInference = FALSE, FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, 
        ClassificationSystem = "screening", ReportingUse = "screening_only", StatisticLabel = "strict pairwise agreement residual", 
        LiteratureSeries = "agreement_screen_informed_by_generalized_residual_logic")
    facet_summary <- mutate(summarize(group_by(pair_stats, .data$Facet), LevelPairs = dplyr::n(), ContextPairs = sum(.data$LevelPairCount), 
        AvailableContextPairs = sum(.data$AvailableContextPairs), UnavailableContextPairs = sum(.data$UnavailableContextPairs), 
        ClassifiedLevelPairs = sum(!is.na(.data$Flagged)), UnclassifiedLevelPairs = sum(is.na(.data$Flagged)), 
        AvailableExactResiduals = sum(is.finite(.data$ExactStdResidual)), AvailableAdjacentResiduals = sum(is.finite(.data$AdjacentStdResidual)), 
        MeanAbsExactGap = stats::weighted.mean(abs(.data$ExactGap), .data$OpportunityWeight), MeanAbsAdjacentGap = stats::weighted.mean(abs(.data$AdjacentGap), 
            .data$OpportunityWeight), MaxAbsExactStdResidual = if (all(!is.finite(.data$ExactStdResidual))) {
            NA_real_
        }
        else {
            max(abs(.data$ExactStdResidual), na.rm = TRUE)
        }, MaxAbsAdjacentStdResidual = if (all(!is.finite(.data$AdjacentStdResidual))) {
            NA_real_
        }
        else {
            max(abs(.data$AdjacentStdResidual), na.rm = TRUE)
        }, OpportunityWeight = sum(.data$OpportunityWeight), FlaggedLevelPairs = if (any(!is.na(.data$Flagged))) 
            sum(.data$Flagged, na.rm = TRUE)
        else NA_integer_, .groups = "drop"), InferenceTier = "exploratory", SupportsFormalInference = FALSE, 
        FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, ClassificationSystem = "screening", 
        ReportingUse = "screening_only", StatisticLabel = "strict pairwise agreement residual", LiteratureSeries = "agreement_screen_informed_by_generalized_residual_logic")
    top_pairs <- slice_head(arrange(mutate(pair_stats, AbsExactStdResidual = abs(.data$ExactStdResidual), 
        AbsAdjacentStdResidual = abs(.data$AdjacentStdResidual)), desc(.data$AbsExactStdResidual), desc(.data$AbsAdjacentStdResidual), 
        desc(abs(.data$ExactGap)), desc(abs(.data$AdjacentGap))), n = 20)
    nonunit_weights <- any(abs(weights - 1) > sqrt(.Machine$double.eps), na.rm = TRUE)
    list(available = TRUE, coverage = marginal_flag_coverage(pair_stats$Flagged, "Level pairs"), pair_stats = pair_stats, 
        facet_summary = facet_summary, top_pairs = top_pairs, thresholds = list(abs_z_warn = abs_z_warn, 
            exact_gap_warn = exact_gap_warn, adjacent_gap_warn = adjacent_gap_warn), notes = c("Strict second-order diagnostics compare observed and posterior-integrated expected exact/adjacent agreement within Person x remaining-facets contexts.", 
            "These agreement screens are informed by generalized-residual logic but are not formal Haberman-Sinharay generalized residual tests.", 
            if (isTRUE(nonunit_weights)) {
                "Pairwise opportunity counts use the product of row weights."
            } else {
                "Pairwise opportunity counts are unweighted row-pair counts."
            }))
}

calc_marginal_fit_bundle <- function(res, abs_z_warn = 2, rmsd_warn = 0.05) {
    expected_core <- compute_mml_expected_category_diagnostics(res)
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    model <- as.character(res$config$model %||% res$summary$Model[1] %||% NA_character_)
    if (!isTRUE(expected_core$available)) {
        return(list(available = FALSE, summary = tibble(Available = FALSE, Method = method, Model = model, 
            Basis = "latent_integrated_first_order_counts", Reason = as.character(expected_core$reason %||% 
                "Marginal fit diagnostics were not available.")), thresholds = list(abs_z_warn = abs_z_warn, 
            rmsd_warn = rmsd_warn), notes = as.character(expected_core$reason %||% "Marginal fit diagnostics were not available.")))
    }
    n <- length(expected_core$observed_cat)
    weights <- expected_core$weights
    posterior_prob <- expected_core$expected_bundle$posterior_prob
    categories <- expected_core$categories
    prep <- expected_core$prep
    config <- expected_core$config
    overall <- summarize_marginal_fit_grid(group_df = data.frame(CellType = rep("overall", n), Scope = rep("All", 
        n), stringsAsFactors = FALSE), observed_cat = expected_core$observed_cat, posterior_prob = posterior_prob, 
        weights = weights, categories = categories, abs_z_warn = abs_z_warn, rmsd_warn = rmsd_warn)
    step_or_scale <- summarize_marginal_fit_grid(group_df = data.frame(CellType = rep("step_facet", n), 
        StepFacet = if (config$model %in% c("PCM", "GPCM")) {
            as.character(prep$data[[config$step_facet]])
        }
        else {
            rep("Common", n)
        }, stringsAsFactors = FALSE), observed_cat = expected_core$observed_cat, posterior_prob = posterior_prob, 
        weights = weights, categories = categories, abs_z_warn = abs_z_warn, rmsd_warn = rmsd_warn)
    facet_parts <- lapply(config$facet_names, function(facet) {
        summarize_marginal_fit_grid(group_df = data.frame(CellType = rep("facet_level", n), Facet = rep(facet, 
            n), Level = as.character(prep$data[[facet]]), stringsAsFactors = FALSE), observed_cat = expected_core$observed_cat, 
            posterior_prob = posterior_prob, weights = weights, categories = categories, abs_z_warn = abs_z_warn, 
            rmsd_warn = rmsd_warn)
    })
    facet_level <- list(cell_stats = bind_rows(lapply(facet_parts, `[[`, "cell_stats")), summary_stats = bind_rows(lapply(facet_parts, 
        `[[`, "summary_stats")))
    pairwise <- calc_marginal_pairwise_bundle(expected_core = expected_core, abs_z_warn = abs_z_warn)
    guidance_tbl <- build_marginal_fit_guidance(pairwise_available = isTRUE(pairwise$available))
    top_cells <- slice_head(arrange(mutate(bind_rows(step_or_scale$cell_stats, facet_level$cell_stats), 
        AbsStdResidual = abs(.data$StdResidual)), desc(.data$AbsStdResidual), desc(abs(.data$PropDiff))), 
        n = 20)
    overall_summary <- slice_head(overall$summary_stats, n = 1)
    coverage <- bind_rows(marginal_flag_coverage(overall$cell_stats$FlaggedAbsZ, "Overall categories"), 
        marginal_flag_coverage(step_or_scale$summary_stats$Flagged, "Step/scale groups"), marginal_flag_coverage(facet_level$summary_stats$Flagged, 
            "Facet levels"), marginal_flag_coverage(pairwise$pair_stats$Flagged, "Level pairs"))
    summary_tbl <- tibble(Available = TRUE, Method = method, Model = model, Basis = "latent_integrated_first_order_counts", 
        ObservationCount = n, CategoryCount = length(categories), OverallRMSD = overall_summary$RMSD[1] %||% 
            NA_real_, OverallMaxAbsStdResidual = overall_summary$MaxAbsStdResidual[1] %||% NA_real_, 
        StepGroupsFlagged = coverage$Flagged[2], FacetLevelsFlagged = coverage$Flagged[3], PairwiseAvailable = isTRUE(pairwise$available), 
        PairwiseFlaggedLevelPairs = if (isTRUE(pairwise$available)) {
            coverage$Flagged[4]
        }
        else {
            NA_integer_
        }, PosteriorPredictiveFollowUp = "not_available", InferenceTier = "exploratory", SupportsFormalInference = FALSE, 
        FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, ClassificationSystem = "screening", 
        ReportingUse = "screening_only", StatisticLabel = "strict marginal fit screen", LiteratureSeries = if (isTRUE(pairwise$available)) {
            "limited_information_inspired_marginal_screen + agreement_screen_informed_by_generalized_residual_logic"
        }
        else {
            "limited_information_inspired_marginal_screen"
        }, InterpretationBasis = "latent_integrated", FollowUpRecommendation = "Use as screening evidence and corroborate with companion diagnostics, model comparisons, and substantive design review.")
    list(available = TRUE, coverage_version = 1L, coverage = coverage, summary = summary_tbl, overall = overall, 
        step_or_scale = step_or_scale, facet_level = facet_level, pairwise = pairwise, guidance = guidance_tbl, 
        top_cells = top_cells, thresholds = list(abs_z_warn = abs_z_warn, rmsd_warn = rmsd_warn), notes = c("Expected counts integrate over Person posteriors conditioned on the same observed responses, with fitted calibration held fixed.", 
            "Residual scaling uses weighted Bernoulli variances; it omits cross-response covariance and calibration-parameter uncertainty. Cutoffs are descriptive review rules, not calibrated tests.", 
            "Unavailable cells, groups and level pairs remain in coverage totals; no overall all-clear follows from available rows alone.", 
            "The implemented summary covers overall, step-facet/scale, facet-level category residuals, and pairwise local-dependence checks.", 
            "Posterior predictive checks are not computed by mfrmr; use external Bayesian software when that additional analysis is required."))
}



make_union_find <- function(nodes) {
    unique_nodes <- unique(as.character(nodes))
    n_nodes <- length(unique_nodes)
    parent_int <- seq_len(n_nodes)
    idx_env <- new.env(hash = TRUE, parent = emptyenv(), size = max(16L, n_nodes * 2L))
    nonempty <- which(!is.na(unique_nodes) & nzchar(unique_nodes))
    for (i in nonempty) {
        assign(unique_nodes[i], i, envir = idx_env)
    }
    lookup_idx <- function(x) {
        if (length(x) != 1L || is.na(x)) 
            return(0L)
        x_chr <- as.character(x)
        if (!nzchar(x_chr)) 
            return(match(x_chr, unique_nodes, nomatch = 0L))
        get0(x_chr, envir = idx_env, inherits = FALSE, ifnotfound = 0L)
    }
    find_idx <- function(i) {
        root <- i
        repeat {
            pr <- parent_int[root]
            if (pr == root) 
                break
            root <- pr
        }
        cur <- i
        while (parent_int[cur] != root) {
            nxt <- parent_int[cur]
            parent_int[cur] <<- root
            cur <- nxt
        }
        root
    }
    find_root <- function(x) {
        idx <- lookup_idx(x)
        if (idx == 0L) 
            return(NA_character_)
        unique_nodes[find_idx(idx)]
    }
    union_nodes <- function(a, b) {
        ia <- lookup_idx(a)
        ib <- lookup_idx(b)
        if (ia == 0L || ib == 0L) 
            return(NULL)
        ra <- find_idx(ia)
        rb <- find_idx(ib)
        if (ra == rb) 
            return(NULL)
        parent_int[rb] <<- ra
        invisible(NULL)
    }
    union_pairs <- function(from_vec, to_vec) {
        ia_vec <- match(as.character(from_vec), unique_nodes, nomatch = 0L)
        ib_vec <- match(as.character(to_vec), unique_nodes, nomatch = 0L)
        for (k in seq_along(ia_vec)) {
            ia <- ia_vec[k]
            ib <- ib_vec[k]
            if (ia == 0L || ib == 0L) 
                next
            ra <- find_idx(ia)
            rb <- find_idx(ib)
            if (ra != rb) 
                parent_int[rb] <<- ra
        }
        invisible(NULL)
    }
    find_many <- function(x_vec) {
        idx_vec <- match(as.character(x_vec), unique_nodes, nomatch = 0L)
        out <- rep(NA_character_, length(idx_vec))
        ok <- which(idx_vec > 0L)
        for (k in ok) {
            out[k] <- unique_nodes[find_idx(idx_vec[k])]
        }
        out
    }
    list(find = find_root, union = union_nodes, union_pairs = union_pairs, find_many = find_many)
}

calc_subsets <- function(obs_df, facet_cols) {
    if (is.null(obs_df) || nrow(obs_df) == 0 || length(facet_cols) == 0) {
        return(list(summary = tibble(), nodes = tibble()))
    }
    df <- select(obs_df, all_of(facet_cols))
    df <- df[stats::complete.cases(df), , drop = FALSE]
    if (nrow(df) == 0) {
        return(list(summary = tibble(), nodes = tibble()))
    }
    node_labels <- do.call(rbind, lapply(facet_cols, function(facet) {
        levels <- unique(as.character(df[[facet]]))
        data.frame(Facet = rep(facet, length(levels)), Level = levels)
    }))
    nodes <- make.unique(paste(node_labels$Facet, node_labels$Level, sep = ":"))
    node_columns <- lapply(facet_cols, function(facet) {
        at <- which(node_labels$Facet == facet)
        nodes[at[match(as.character(df[[facet]]), node_labels$Level[at])]]
    })
    if (length(nodes) == 0) {
        return(list(summary = tibble(), nodes = tibble()))
    }
    uf <- make_union_find(nodes)
    if (length(facet_cols) >= 2L) {
        base_nodes <- node_columns[[1L]]
        other_node_columns <- node_columns[-1L]
        other_node_matrix <- do.call(cbind, other_node_columns)
        edge_pairs <- data.frame(From = rep(base_nodes, each = length(other_node_columns)), To = as.vector(t(other_node_matrix)), 
            stringsAsFactors = FALSE)
        edge_pairs <- edge_pairs[!duplicated(edge_pairs), , drop = FALSE]
        uf$union_pairs(edge_pairs$From, edge_pairs$To)
    }
    comp_ids <- setNames(uf$find_many(nodes), nodes)
    comp_levels <- unique(comp_ids)
    comp_index <- setNames(seq_along(comp_levels), comp_levels)
    node_tbl <- tibble(Node = nodes, Component = comp_ids, Subset = comp_index[comp_ids], Facet = node_labels$Facet, 
        Level = node_labels$Level)
    facet_counts <- tidyr::pivot_wider(summarize(group_by(node_tbl, Subset, Facet), Levels = n_distinct(Level), 
        .groups = "drop"), names_from = Facet, values_from = Levels, values_fill = 0)
    first_nodes <- node_columns[[1L]]
    unique_first_nodes <- unique(first_nodes)
    unique_first_subsets <- unname(comp_index[uf$find_many(unique_first_nodes)])
    row_subset <- as.integer(unique_first_subsets[match(first_nodes, unique_first_nodes)])
    obs_counts <- count(tibble(Subset = row_subset), Subset, name = "Observations")
    summary_tbl <- arrange(mutate(left_join(facet_counts, obs_counts, by = "Subset"), Observations = replace_na(Observations, 
        0)), desc(Observations))
    list(summary = summary_tbl, nodes = node_tbl)
}



get_extreme_levels <- function(obs_df, facet_names, rating_min, rating_max) {
    out <- list()
    for (facet in facet_names) {
        if (!facet %in% names(obs_df)) {
            out[[facet]] <- character(0)
            next
        }
        stat <- summarize(group_by(obs_df, .data[[facet]]), MinScore = min(Observed, na.rm = TRUE), MaxScore = max(Observed, 
            na.rm = TRUE), .groups = "drop")
        extreme <- filter(stat, (MinScore == rating_min & MaxScore == rating_min) | (MinScore == rating_max & 
            MaxScore == rating_max))
        out[[facet]] <- as.character(extreme[[facet]])
    }
    out
}

mfrm_bias_has_error <- function(x) {
    is.character(x) && length(x) > 0L && !is.na(x[1]) && isTRUE(nzchar(x[1]))
}

mfrm_make_bias_nll <- function(ctx, eta_sub, score_k_sub, weight_sub = NULL, step_idx_sub = NULL, slope_idx_sub = NULL) {
    if (ctx$model == "RSM") {
        return(function(b) -loglik_rsm(eta_sub + b, score_k_sub, ctx$step_cum, weight = weight_sub))
    }
    if (identical(ctx$model, "GPCM")) {
        return(function(b) -loglik_gpcm(eta_sub + b, score_k_sub, ctx$step_cum_mat, criterion_idx = step_idx_sub, 
            slopes = ctx$slopes_full, slope_idx = slope_idx_sub, weight = weight_sub))
    }
    function(b) -loglik_pcm(eta_sub + b, score_k_sub, ctx$step_cum_mat, step_idx_sub, weight = weight_sub)
}

mfrm_safe_bias_nll_value <- function(nll, b) {
    val <- tryCatch(nll(b), error = function(e) NA_real_)
    val <- suppressWarnings(as.numeric(val[1]))
    if (is.finite(val)) 
        val
    else NA_real_
}

mfrm_profile_bias_ci <- function(nll, estimate, nll_min, max_abs, level = 0.95) {
    empty <- list(lower = NA_real_, upper = NA_real_, level = level, status = "not available")
    if (!is.finite(estimate) || !is.finite(nll_min) || !is.finite(max_abs) || max_abs <= 0 || !is.finite(level) || 
        level <= 0 || level >= 1) {
        return(empty)
    }
    cutoff <- stats::qchisq(level, df = 1)
    target <- function(b) {
        val <- mfrm_safe_bias_nll_value(nll, b)
        if (!is.finite(val)) 
            return(NA_real_)
        2 * (val - nll_min) - cutoff
    }
    root_side <- function(bound) {
        if (abs(bound - estimate) <= sqrt(.Machine$double.eps)) {
            return(list(value = bound, status = "limited by search range"))
        }
        target_bound <- target(bound)
        if (!is.finite(target_bound)) {
            return(list(value = NA_real_, status = "not available"))
        }
        if (target_bound <= 0) {
            return(list(value = bound, status = "limited by search range"))
        }
        lo <- min(bound, estimate)
        hi <- max(bound, estimate)
        root <- tryCatch(stats::uniroot(function(z) target(z), lower = lo, upper = hi, tol = 1e-08)$root, 
            error = function(e) NA_real_)
        if (is.finite(root)) {
            list(value = root, status = "ok")
        }
        else {
            list(value = NA_real_, status = "not available")
        }
    }
    lower <- root_side(-abs(max_abs))
    upper <- root_side(abs(max_abs))
    statuses <- unique(c(lower$status, upper$status))
    status <- if (all(statuses == "ok")) {
        "ok"
    }
    else {
        paste(statuses, collapse = "; ")
    }
    list(lower = lower$value, upper = upper$value, level = level, status = status)
}

mfrm_bias_probabilities <- function(ctx, eta, step_idx_sub, slope_idx_sub) {
    if (ctx$model == "RSM") 
        return(category_prob_rsm(eta, ctx$step_cum))
    if (ctx$model == "GPCM") 
        return(category_prob_gpcm(eta, ctx$step_cum_mat, criterion_idx = step_idx_sub, slopes = ctx$slopes_full, 
            slope_idx = slope_idx_sub))
    category_prob_pcm(eta, ctx$step_cum_mat, step_idx_sub)
}

mfrm_estimate_bias_for_group <- function(idx_rows, ctx) {
    eta_sub <- ctx$eta_base[idx_rows]
    score_k_sub <- ctx$score_k[idx_rows]
    weight_sub <- if (!is.null(ctx$weight)) 
        ctx$weight[idx_rows]
    else NULL
    step_idx_sub <- if (!is.null(ctx$step_idx)) 
        ctx$step_idx[idx_rows]
    else NULL
    slope_idx_sub <- if (!is.null(ctx$slope_idx)) 
        ctx$slope_idx[idx_rows]
    else NULL
    nll <- mfrm_make_bias_nll(ctx, eta_sub, score_k_sub, weight_sub, step_idx_sub, slope_idx_sub)
    opt <- tryCatch(optimize(nll, interval = c(-ctx$max_abs, ctx$max_abs)), error = function(e) e)
    if (inherits(opt, "error")) {
        return(list(value = NA_real_, error = conditionMessage(opt)))
    }
    if (!is.finite(opt$minimum) || !is.finite(opt$objective)) 
        return(list(value = NA_real_, error = "The bounded cell likelihood is nonfinite."))
    w <- weight_sub %||% rep(1, length(idx_rows))
    a <- if (ctx$model == "GPCM") 
        ctx$slopes_full[slope_idx_sub]
    else rep(1, length(idx_rows))
    score <- function(b) {
        p <- mfrm_bias_probabilities(ctx, eta_sub + b, step_idx_sub, slope_idx_sub)
        sum(w * a * (score_k_sub - as.vector(p %*% (seq_len(ncol(p)) - 1L))))
    }
    end_score <- c(score(-ctx$max_abs), score(ctx$max_abs))
    if (any(!is.finite(end_score)) || !any(w > 0)) 
        return(list(value = NA_real_, error = "The complete cell score is unavailable."))
    max_cat <- ctx$rating_max - ctx$rating_min
    lower <- end_score[1L] < 0 || all(score_k_sub[w > 0] == 0)
    upper <- end_score[2L] > 0 || all(score_k_sub[w > 0] == max_cat)
    extreme_low <- all(score_k_sub[w > 0] == 0)
    extreme_high <- all(score_k_sub[w > 0] == max_cat)
    if (ctx$xtreme > 0 && (extreme_low || extreme_high)) {
        correction <- ctx$xtreme * min(w[w > 0])
        adjusted_score <- function(b) score(b) + if (extreme_low) 
            correction
        else -correction
        endpoints <- c(adjusted_score(-ctx$max_abs), adjusted_score(ctx$max_abs))
        if (all(is.finite(endpoints)) && endpoints[1L] > 0 && endpoints[2L] < 0) {
            estimate <- stats::uniroot(adjusted_score, c(-ctx$max_abs, ctx$max_abs), tol = 1e-10)$root
            return(list(value = estimate, status = "extreme_adjusted", primary = if (extreme_low) -Inf else Inf, 
                adjustment = correction, error = NULL))
        }
    }
    list(value = if (lower) -ctx$max_abs else if (upper) ctx$max_abs else opt$minimum, status = if (lower) "lower_search_boundary" else if (upper) "upper_search_boundary" else "interior", 
        error = NULL)
}

mfrm_bias_iteration_metrics <- function(groups, bias_map, bias_error_map, obs_df, ctx) {
    max_resid <- 0
    max_resid_pct <- NA_real_
    has_w <- "Weight" %in% names(obs_df)
    for (key in names(groups)) {
        idx_rows <- groups[[key]]$idx
        bias <- bias_map[[key]]
        if (!is.finite(bias) || mfrm_bias_has_error(bias_error_map[[key]])) 
            next
        eta_sub <- ctx$eta_base[idx_rows] + ifelse(is.finite(bias), bias, 0)
        step_idx_sub <- if (!is.null(ctx$step_idx)) 
            ctx$step_idx[idx_rows]
        else NULL
        slope_idx_sub <- if (!is.null(ctx$slope_idx)) 
            ctx$slope_idx[idx_rows]
        else NULL
        probs <- mfrm_bias_probabilities(ctx, eta_sub, step_idx_sub, slope_idx_sub)
        k_vals <- 0:(ncol(probs) - 1)
        expected_score <- ctx$rating_min + as.vector(probs %*% k_vals)
        obs_score <- obs_df$Observed[idx_rows]
        if (has_w) {
            w <- obs_df$Weight[idx_rows]
            obs_score <- obs_score * w
            expected_score <- expected_score * w
        }
        obs_sum <- sum(obs_score, na.rm = TRUE)
        exp_sum <- sum(expected_score, na.rm = TRUE)
        resid_sum <- obs_sum - exp_sum
        if (abs(resid_sum) >= abs(max_resid)) {
            max_resid <- resid_sum
            max_resid_pct <- ifelse(exp_sum != 0, resid_sum/exp_sum * 100, NA_real_)
        }
    }
    list(max_resid = max_resid, max_resid_pct = max_resid_pct, max_resid_categories = NA_real_)
}

mfrm_build_bias_cell_record <- function(seq_id, key, g, state, obs_df, selected_facets, level_map, meas_map, 
    se_map, meta, ctx) {
    idx_rows <- g$idx
    levels <- g$levels
    bias_hat <- state$bias_map[[key]]
    bias_error <- state$bias_error_map[[key]]
    bias_ok <- is.finite(bias_hat) && !mfrm_bias_has_error(bias_error)
    bias_status <- state$bias_status_map[[key]]
    screen_status <- "failed"
    screen_reason <- bias_error %||% "The cell estimate is unavailable."
    info <- NA_real_
    fit_stats <- data.frame(Infit = NA_real_, Outfit = NA_real_, FitResponseRows = length(idx_rows), 
        FitAvailableRows = 0L, FitUnavailableRows = length(idx_rows), FitStatus = "unavailable", FitReason = "The cell estimate is unavailable.")
    eta_sub <- ctx$eta_base[idx_rows]
    score_k_sub <- ctx$score_k[idx_rows]
    weight_sub <- if (!is.null(ctx$weight)) 
        ctx$weight[idx_rows]
    else rep(1, length(idx_rows))
    step_idx_sub <- if (!is.null(ctx$step_idx)) 
        ctx$step_idx[idx_rows]
    else NULL
    slope_idx_sub <- if (!is.null(ctx$slope_idx)) 
        ctx$slope_idx[idx_rows]
    else NULL
    fit_row <- NULL
    if (bias_ok) {
        probs <- mfrm_bias_probabilities(ctx, eta_sub + bias_hat, step_idx_sub, slope_idx_sub)
        k_vals <- 0:(ncol(probs) - 1)
        expected_k <- as.vector(probs %*% k_vals)
        var_k <- mfrm_category_variance(probs, k_vals, expected_k)
        resid_k <- score_k_sub - expected_k
        fit_var <- ifelse(var_k > 1e-10, var_k, NA_real_)
        fit_row <- data.frame(.BiasCell = seq_id, StdSq = resid_k^2/fit_var, Var = fit_var, Weight = weight_sub)
        info_var <- var_k
        if (identical(ctx$model, "GPCM")) {
            slope_obs_sub <- if (!is.null(slope_idx_sub) && !is.null(ctx$slopes_full)) {
                as.numeric(ctx$slopes_full[slope_idx_sub])
            }
            else {
                rep(NA_real_, length(var_k))
            }
            info_var <- ifelse(is.finite(slope_obs_sub) & slope_obs_sub > 0, (slope_obs_sub^2) * var_k, 
                NA_real_)
        }
        info <- if (all(is.finite(info_var) & info_var >= 0 & is.finite(weight_sub) & weight_sub >= 0)) 
            sum(info_var * weight_sub)
        else NA_real_
        interior <- identical(bias_status, "interior")
        extrapolated <- identical(bias_status, "extreme_adjusted")
        screen_ok <- (interior || extrapolated) && is.finite(info) && info > 0
        se <- if (screen_ok) 
            1/sqrt(info)
        else NA_real_
        screen_status <- if (extrapolated && screen_ok) 
            "available_extreme_adjustment"
        else if (!interior) 
            "search_boundary"
        else if (screen_ok) 
            "available_conditional"
        else "unavailable_information"
        screen_reason <- if (extrapolated) 
            paste("Finite reporting value and conditional information use a corrected extreme total.", 
                "The original cell MLE is infinite; tail areas are extrapolated screening summaries, not regular-MLE inference.", 
                "The correction can reverse the sign relative to the observed-minus-baseline difference; inspect PrimaryBias and Obs-Exp Average.")
        else if (!interior) 
            paste("The point maximizes the likelihood at a search bound; it is not an interior cell estimate.", 
                "SE and screening tail areas are withheld. Review max_abs and extreme response patterns.")
        else if (screen_ok) 
            "Conditional information uses all cell rows; calibration and Person uncertainty are excluded."
        else "The complete cell information is unavailable or nonpositive; no subset-based SE is reported."
        infit <- fit_stats$Infit
        outfit <- fit_stats$Outfit
    }
    else {
        expected_k <- rep(NA_real_, length(score_k_sub))
        se <- NA_real_
        infit <- NA_real_
        outfit <- NA_real_
    }
    lr_chisq <- NA_real_
    lr_df <- NA_real_
    lr_prob <- NA_real_
    profile_ci <- list(lower = NA_real_, upper = NA_real_, level = 0.95, status = "not available")
    likelihood_basis <- NA_character_
    if (bias_ok && identical(bias_status, "interior") && identical(ctx$model, "GPCM")) {
        nll_sub <- mfrm_make_bias_nll(ctx, eta_sub, score_k_sub, weight_sub, step_idx_sub, slope_idx_sub)
        nll_hat <- mfrm_safe_bias_nll_value(nll_sub, bias_hat)
        nll_null <- mfrm_safe_bias_nll_value(nll_sub, 0)
        if (is.finite(nll_hat) && is.finite(nll_null)) {
            lr_chisq <- max(0, 2 * (nll_null - nll_hat))
            lr_df <- 1
            lr_prob <- stats::pchisq(lr_chisq, df = lr_df, lower.tail = FALSE)
            profile_ci <- mfrm_profile_bias_ci(nll = nll_sub, estimate = bias_hat, nll_min = nll_hat, 
                max_abs = ctx$max_abs, level = 0.95)
            likelihood_basis <- paste("conditional profile likelihood for one additive GPCM bias shift;", 
                "theta, steps, slopes, and other facet estimates held fixed")
        }
    }
    if (bias_ok && !identical(bias_status, "interior")) 
        profile_ci$status <- "unavailable at search boundary"
    obs_slice <- obs_df[idx_rows, , drop = FALSE]
    w_obs <- if ("Weight" %in% names(obs_slice)) 
        obs_slice$Weight
    else rep(1, nrow(obs_slice))
    obs_score <- sum(obs_slice$Observed * w_obs, na.rm = TRUE)
    after_bias_expected <- if (bias_ok) 
        sum((ctx$rating_min + expected_k) * w_obs)
    else NA_real_
    exp_score <- if (all(is.finite(obs_slice$Expected))) 
        sum(obs_slice$Expected * w_obs)
    else NA_real_
    obs_count <- sum(w_obs, na.rm = TRUE)
    obs_exp_avg <- ifelse(obs_count > 0 && is.finite(exp_score), (obs_score - exp_score)/obs_count, NA_real_)
    n_obs <- nrow(obs_slice)
    df_raw <- if (is.finite(obs_count)) 
        obs_count - 1
    else NA_real_
    df_t <- if (is.finite(df_raw) && df_raw > 0) 
        df_raw
    else NA_real_
    t_val <- ifelse(is.finite(bias_hat) && is.finite(se) && se > 0, bias_hat/se, NA_real_)
    p_val <- if (is.finite(t_val) && is.finite(df_t)) 
        2 * stats::pt(-abs(t_val), df = df_t)
    else NA_real_
    probability_status <- if (!is.finite(df_t)) 
        "unavailable_df"
    else if (!is.finite(t_val)) 
        "unavailable_statistic"
    else if (!is.finite(p_val)) 
        "unavailable_numerical"
    else if (identical(bias_status, "extreme_adjusted")) 
        "available_extreme_adjustment"
    else "available_conditional"
    probability_reason <- switch(probability_status, unavailable_df = "Frequency-weighted count minus one is nonpositive or unavailable; no Student reference exists.", 
        unavailable_statistic = "The bias estimate or its conditional information SE does not provide a finite statistic.", 
        unavailable_numerical = "The Student tail calculation did not return a finite probability.", 
        available_extreme_adjustment = "The tail uses a corrected extreme total; it is not inference for the original infinite MLE.", 
        "The tail conditions on the fitted calibration; count-minus-one is a screening approximation, not a calibrated test.")
    row <- list(Sq = seq_id, `Observd Score` = obs_score, `Expctd Score` = exp_score, `Observd Count` = obs_count, 
        `Obs-Exp Average` = obs_exp_avg, ExpectedScoreBasis = "Main-analysis expectations before the cell shift", 
        AfterBiasExpectedScore = after_bias_expected, AfterBiasObsExpAverage = if (obs_count > 0) (obs_score - 
            after_bias_expected)/obs_count else NA_real_, `Bias Size` = bias_hat, PrimaryBias = state$bias_primary_map[[key]], 
        ExtremeAdjustment = state$bias_adjustment_map[[key]], S.E. = se, t = t_val, d.f. = df_t, Prob. = p_val, 
        InferenceTier = "screening", SupportsFormalInference = FALSE, FormalInferenceEligible = FALSE, 
        PrimaryReportingEligible = FALSE, ReportingUse = "screening_only", SEBasis = if (identical(bias_status, 
            "extreme_adjusted")) "Conditional information at corrected extreme total; not original-MLE uncertainty" else "conditional plug-in information", 
        DFBasis = "frequency-weighted observed count minus 1 approximation", DFUnrounded = df_raw, DFDisplay = if (ctx$model %in% 
            c("RSM", "PCM")) floor(round(df_t, 10) + 0.5) else df_t, StatisticLabel = "screening t", 
        ProbabilityMetric = "screening tail area", ProbabilityReference = "Two-sided Student t at continuous count-minus-one df; calibration held fixed", 
        ProbabilityStatus = probability_status, ProbabilityReason = probability_reason, Infit = infit, 
        Outfit = outfit, ObsN = n_obs, OptimizationStatus = if (bias_ok) "ok" else "failed", OptimizationDetail = if (bias_ok) NA_character_ else bias_error, 
        BiasStatus = bias_status, ConditionalInformation = info, ScreenStatus = screen_status, ScreenReason = screen_reason, 
        FitResponseRows = fit_stats$FitResponseRows, FitAvailableRows = fit_stats$FitAvailableRows, FitUnavailableRows = fit_stats$FitUnavailableRows, 
        FitStatus = fit_stats$FitStatus, FitReason = fit_stats$FitReason, InteractionFacets = meta$label, 
        InteractionOrder = meta$order, InteractionMode = meta$mode)
    if (identical(ctx$model, "GPCM")) {
        row$`LR ChiSq` <- lr_chisq
        row$`LR d.f.` <- lr_df
        row$`LR Prob.` <- lr_prob
        row$`Profile CI Lower` <- profile_ci$lower
        row$`Profile CI Upper` <- profile_ci$upper
        row$`Profile CI Level` <- profile_ci$level
        row$`Profile CI Status` <- profile_ci$status
        row$`Likelihood Basis` <- likelihood_basis
    }
    for (j in seq_along(selected_facets)) {
        facet_j <- selected_facets[j]
        level_j <- as.character(levels[[facet_j]])
        index_j <- match(level_j, level_map[[facet_j]])
        row[[paste0("Facet", j)]] <- facet_j
        row[[paste0("Facet", j, "_Level")]] <- level_j
        row[[paste0("Facet", j, "_Index")]] <- ifelse(is.na(index_j), NA_real_, index_j)
        row[[paste0("Facet", j, "_Measure")]] <- meas_map[[facet_j]][[level_j]]
        row[[paste0("Facet", j, "_SE")]] <- se_map[[facet_j]][[level_j]]
    }
    if (meta$order >= 2) {
        row$FacetA <- row$Facet1
        row$FacetA_Level <- row$Facet1_Level
        row$FacetA_Index <- row$Facet1_Index
        row$FacetA_Measure <- row$Facet1_Measure
        row$FacetA_SE <- row$Facet1_SE
        row$FacetB <- row$Facet2
        row$FacetB_Level <- row$Facet2_Level
        row$FacetB_Index <- row$Facet2_Index
        row$FacetB_Measure <- row$Facet2_Measure
        row$FacetB_SE <- row$Facet2_SE
    }
    list(row = tibble::as_tibble(row), fit_row = fit_row)
}

estimate_bias_interaction <- function(res, diagnostics, facet_a = NULL, facet_b = NULL, interaction_facets = NULL, 
    max_abs = 10, omit_extreme = TRUE, max_iter = 4, tol = 0.001, xtreme = 0) {
    if (is.null(res) || is.null(diagnostics)) 
        return(list())
    obs_df <- diagnostics$obs
    if (is.null(obs_df) || nrow(obs_df) == 0) 
        return(list())
    facet_names <- c("Person", res$config$facet_names)
    selected_facets <- if (!is.null(interaction_facets)) {
        as.character(interaction_facets)
    }
    else if (!is.null(facet_a) && !is.null(facet_b)) {
        c(as.character(facet_a[1]), as.character(facet_b[1]))
    }
    else {
        character(0)
    }
    selected_facets <- selected_facets[!is.na(selected_facets) & nzchar(selected_facets)]
    selected_facets <- unique(selected_facets)
    if (length(selected_facets) < 2 || !all(selected_facets %in% facet_names) || !all(selected_facets %in% 
        names(obs_df))) {
        return(list())
    }
    prep <- res$prep
    config <- res$config
    sizes <- build_param_sizes(config)
    params <- expand_params(res$opt$par, sizes, config)
    idx <- build_indices(prep, step_facet = config$step_facet, slope_facet = config$slope_facet, interaction_specs = config$interaction_specs)
    theta_hat <- if (config$method == "JML") 
        params$theta
    else mfrm_saved_person_estimates(res)
    eta_base <- compute_eta(idx, params, config, theta_override = theta_hat)
    slope_idx <- if (identical(config$model, "GPCM")) 
        idx$slope_idx %||% idx$step_idx
    else NULL
    slopes_full <- if (identical(config$model, "GPCM")) 
        as.numeric(params$slopes)
    else NULL
    step_cum <- if (config$model == "RSM") 
        c(0, cumsum(params$steps))
    else NULL
    step_cum_mat <- if (config$model == "RSM") 
        NULL
    else t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
    ctx <- list(model = config$model, eta_base = eta_base, score_k = idx$score_k, weight = idx$weight, 
        step_idx = idx$step_idx, slope_idx = slope_idx, step_cum = step_cum, step_cum_mat = step_cum_mat, 
        slopes_full = slopes_full, rating_min = prep$rating_min, rating_max = prep$rating_max, max_abs = max_abs, 
        xtreme = xtreme)
    if (omit_extreme) {
        extreme_levels <- get_extreme_levels(obs_df, selected_facets, prep$rating_min, prep$rating_max)
        if (identical(config$method, "JML") && config$model %in% c("RSM", "PCM") && !length(config$interaction_specs)) {
            for (f in names(extreme_levels)) extreme_levels[[f]] <- extreme_levels[[f]][facet_anchor_status(f, 
                extreme_levels[[f]], config) != "A"]
        }
    }
    else {
        extreme_levels <- list()
    }
    eligible_main <- rep(TRUE, nrow(obs_df))
    if (xtreme > 0) {
        extreme_levels <- .mfrm_unanchored_extremes(res, obs_df)
        for (f in facet_names) eligible_main <- eligible_main & !as.character(obs_df[[f]]) %in% extreme_levels[[f]]
        eligible_main <- eligible_main & is.finite(res$facets$person$Estimate[match(as.character(obs_df$Person), 
            as.character(res$facets$person$Person))])
    }
    measures <- diagnostics$measures
    meas_map <- list()
    se_map <- list()
    if (!is.null(measures) && nrow(measures) > 0) {
        for (i in seq_len(nrow(measures))) {
            facet <- as.character(measures$Facet[i])
            level <- as.character(measures$Level[i])
            meas_map[[facet]][[level]] <- measures$Estimate[i]
            se_map[[facet]][[level]] <- measures$SE[i]
        }
    }
    level_map <- stats::setNames(lapply(facet_names, function(facet) {
        if (facet == "Person") 
            as.character(prep$levels$Person)
        else as.character(prep$levels[[facet]])
    }), facet_names)
    interaction_parts <- stats::setNames(lapply(selected_facets, function(f) as.character(obs_df[[f]])), 
        selected_facets)
    group_codes <- lapply(interaction_parts, function(x) as.integer(factor(x)))
    group_keys <- do.call(interaction, c(group_codes, list(drop = TRUE, sep = ":", lex.order = TRUE)))
    group_indices <- split(seq_len(nrow(obs_df)), group_keys)
    groups <- list()
    for (key in names(group_indices)) {
        idx_rows <- group_indices[[key]]
        if (xtreme > 0) 
            idx_rows <- idx_rows[eligible_main[idx_rows]]
        if (length(idx_rows) == 0) 
            next
        lvl_vals <- stats::setNames(vapply(interaction_parts, function(x) x[idx_rows[1L]], character(1)), 
            selected_facets)
        if (isTRUE(omit_extreme)) {
            is_extreme <- vapply(selected_facets, function(f) {
                lvl_vals[[f]] %in% (extreme_levels[[f]] %||% character(0))
            }, logical(1))
            if (any(is_extreme)) 
                next
        }
        groups[[as.character(key)]] <- list(levels = lvl_vals, idx = idx_rows)
    }
    if (length(groups) == 0) 
        return(list())
    orientation_review <- audit_interaction_orientation(config, selected_facets)
    bias_map <- stats::setNames(as.list(rep(0, length(groups))), names(groups))
    bias_error_map <- stats::setNames(as.list(rep(NA_character_, length(groups))), names(groups))
    bias_status_map <- stats::setNames(as.list(rep("unavailable", length(groups))), names(groups))
    bias_primary_map <- bias_map
    bias_adjustment_map <- bias_map
    iter_rows <- list()
    for (it in seq_len(max_iter)) {
        max_change_abs <- 0
        max_change_signed <- 0
        changes <- numeric(0)
        for (key in names(groups)) {
            bias_result <- mfrm_estimate_bias_for_group(groups[[key]]$idx, ctx)
            bias_hat <- bias_result$value
            prev <- bias_map[[key]]
            if (is.finite(bias_hat) && is.finite(prev)) {
                delta <- bias_hat - prev
                if (abs(delta) >= max_change_abs) {
                  max_change_abs <- abs(delta)
                  max_change_signed <- delta
                }
                changes <- c(changes, abs(delta))
            }
            else {
                changes <- c(changes, NA_real_)
            }
            bias_map[[key]] <- bias_hat
            bias_status_map[[key]] <- bias_result$status %||% "unavailable"
            bias_primary_map[[key]] <- bias_result$primary %||% bias_hat
            bias_adjustment_map[[key]] <- bias_result$adjustment %||% 0
            bias_error_map[[key]] <- if (mfrm_bias_has_error(bias_result$error)) 
                bias_result$error
            else NA_character_
        }
        resid_info <- mfrm_bias_iteration_metrics(groups, bias_map, bias_error_map, obs_df, ctx)
        iter_rows[[it]] <- tibble(Iteration = it, MaxScoreResidual = resid_info$max_resid, MaxScoreResidualPct = resid_info$max_resid_pct, 
            MaxScoreResidualCategories = resid_info$max_resid_categories, MaxLogitChange = max_change_signed, 
            BiasCells = sum(changes > tol, na.rm = TRUE))
        if (max_change_abs < tol) 
            break
    }
    interaction_label <- paste(selected_facets, collapse = " x ")
    interaction_order <- length(selected_facets)
    interaction_mode <- ifelse(interaction_order > 2, "higher_order", "pairwise")
    meta <- list(label = interaction_label, order = interaction_order, mode = interaction_mode)
    state <- list(bias_map = bias_map, bias_error_map = bias_error_map, bias_status_map = bias_status_map, 
        bias_primary_map = bias_primary_map, bias_adjustment_map = bias_adjustment_map)
    rows <- vector("list", length(groups))
    fit_rows <- list()
    seq_id <- 1
    for (key in names(groups)) {
        rec <- mfrm_build_bias_cell_record(seq_id = seq_id, key = key, g = groups[[key]], state = state, 
            obs_df = obs_df, selected_facets = selected_facets, level_map = level_map, meas_map = meas_map, 
            se_map = se_map, meta = meta, ctx = ctx)
        rows[[seq_id]] <- rec$row
        if (!is.null(rec$fit_row)) 
            fit_rows[[seq_id]] <- rec$fit_row
        seq_id <- seq_id + 1
    }
    bias_tbl <- bind_rows(rows)
    if (nrow(bias_tbl) == 0) 
        return(list())
    if (length(fit_rows)) {
        grouped_fit <- calc_facet_fit(bind_rows(fit_rows), ".BiasCell")
        at <- match(bias_tbl$Sq, grouped_fit$Level)
        retained <- !is.na(at)
        columns <- c("Infit", "Outfit", "FitResponseRows", "FitAvailableRows", "FitUnavailableRows", 
            "FitStatus", "FitReason")
        bias_tbl[retained, columns] <- grouped_fit[at[retained], columns]
    }
    numeric_cols <- c("Observd Score", "Expctd Score", "Observd Count", "Obs-Exp Average", "Bias Size", 
        "S.E.")
    pop_sd <- function(x) {
        x <- x[is.finite(x)]
        if (length(x) == 0) 
            return(NA_real_)
        m <- mean(x)
        sqrt(mean((x - m)^2))
    }
    summary_tbl <- mutate(bind_rows(summarize(bias_tbl, across(all_of(numeric_cols), ~mean(.x, na.rm = TRUE))), 
        summarize(bias_tbl, across(all_of(numeric_cols), ~pop_sd(.x))), summarize(bias_tbl, across(all_of(numeric_cols), 
            ~stats::sd(.x, na.rm = TRUE)))), Statistic = c(paste0("Mean (Count: ", nrow(bias_tbl), ")"), 
        "S.D. (Population)", "S.D. (Sample)"), InteractionFacets = interaction_label, InteractionOrder = interaction_order, 
        InteractionMode = interaction_mode, MixedSign = orientation_review$mixed_sign, .before = 1)
    se_bias <- bias_tbl$S.E.
    bias_vals <- bias_tbl$`Bias Size`
    w_chi <- ifelse(is.finite(se_bias) & se_bias > 0, 1/(se_bias^2), NA_real_)
    ok <- is.finite(w_chi) & is.finite(bias_vals)
    fixed_chi <- if (all(ok) && sum(ok) >= 2) 
        sum(w_chi * bias_vals^2)
    else NA_real_
    fixed_df <- if (is.finite(fixed_chi)) 
        nrow(bias_tbl)
    else NA_real_
    fixed_prob <- if (is.finite(fixed_chi) && is.finite(fixed_df) && fixed_df > 0) 
        stats::pchisq(fixed_chi, df = fixed_df, lower.tail = FALSE)
    else NA_real_
    optimization_failures <- purrr::imap_dfr(groups, function(g, key) {
        err <- bias_error_map[[key]]
        if (!mfrm_bias_has_error(err)) 
            return(tibble::tibble())
        out <- tibble::tibble(InteractionKey = key, Error = err)
        for (facet_j in selected_facets) out[[facet_j]] <- as.character(g$levels[[facet_j]])
        out
    })
    chi_tbl <- tibble(FixedChiSq = fixed_chi, FixedDF = fixed_df, FixedProb = fixed_prob, InferenceTier = "screening", 
        SupportsFormalInference = FALSE, FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, 
        ReportingUse = "screening_only", TestBasis = "conditional plug-in zero-reference screen", Cells = nrow(bias_tbl), 
        AvailableCells = sum(ok), Status = if (is.finite(fixed_chi)) 
            "available_screening"
        else "unavailable", Reason = if (is.finite(fixed_chi)) 
            "Conditional all-zero screen; not a formal joint interaction test."
        else "At least two cells and complete cell estimates and SEs are required; no selected-subset screen is reported.", 
        InteractionFacets = interaction_label, InteractionOrder = interaction_order, InteractionMode = interaction_mode)
    list(calculation_version = 2L, facet_a = selected_facets[1], facet_b = selected_facets[2], interaction_facets = selected_facets, 
        interaction_order = interaction_order, interaction_mode = interaction_mode, table = bias_tbl, 
        summary = summary_tbl, chi_sq = chi_tbl, iteration = bind_rows(iter_rows), orientation_review = orientation_review$table, 
        mixed_sign = orientation_review$mixed_sign, direction_note = orientation_review$direction_note, 
        recommended_action = orientation_review$recommended_action, inference_tier = "screening", optimization_failures = optimization_failures)
}

calc_bias_pairwise <- function(bias_tbl, target_facet, context_facet, orientation_review = NULL, df_method = c("facets", 
    "classical")) {
    df_method <- match.arg(df_method)
    if (is.null(bias_tbl) || nrow(bias_tbl) == 0) 
        return(tibble())
    if ("InteractionOrder" %in% names(bias_tbl)) {
        ord <- suppressWarnings(as.numeric(bias_tbl$InteractionOrder[1]))
        if (is.finite(ord) && ord != 2) 
            return(tibble())
    }
    use_a <- bias_tbl$FacetA[1] == target_facet
    use_b <- bias_tbl$FacetB[1] == target_facet
    if (!(use_a || use_b)) 
        return(tibble())
    target_prefix <- if (use_a) 
        "FacetA"
    else "FacetB"
    context_prefix <- if (use_a) 
        "FacetB"
    else "FacetA"
    target_sign <- NA_real_
    if (is.data.frame(orientation_review) && all(c("Facet", "Sign") %in% names(orientation_review))) {
        signs <- orientation_review$Sign[which(orientation_review$Facet == target_facet)]
        if (length(signs) == 1L && signs %in% c(-1, 1)) 
            target_sign <- as.numeric(signs)
    }
    sub <- filter(bias_tbl, .data[[context_prefix]] %in% context_facet)
    if (nrow(sub) == 0) 
        sub <- bias_tbl
    rows <- list()
    for (tgt_level in unique(sub[[paste0(target_prefix, "_Level")]])) {
        group_df <- filter(sub, .data[[paste0(target_prefix, "_Level")]] == tgt_level)
        contexts <- unique(group_df[[paste0(context_prefix, "_Level")]])
        if (length(contexts) < 2) 
            next
        ctx_pairs <- combn(contexts, 2, simplify = FALSE)
        for (pair in ctx_pairs) {
            c1 <- pair[1]
            c2 <- pair[2]
            r1 <- slice(filter(group_df, .data[[paste0(context_prefix, "_Level")]] == c1), 1)
            r2 <- slice(filter(group_df, .data[[paste0(context_prefix, "_Level")]] == c2), 1)
            tgt_measure <- r1[[paste0(target_prefix, "_Measure")]]
            tgt_se <- r1[[paste0(target_prefix, "_SE")]]
            tgt_index <- r1[[paste0(target_prefix, "_Index")]]
            bias1 <- r1$`Bias Size`
            bias2 <- r2$`Bias Size`
            bias_se1 <- r1$S.E.
            bias_se2 <- r2$S.E.
            local1 <- ifelse(is.finite(tgt_measure) & is.finite(bias1), tgt_measure + bias1/target_sign, 
                NA_real_)
            local2 <- ifelse(is.finite(tgt_measure) & is.finite(bias2), tgt_measure + bias2/target_sign, 
                NA_real_)
            se1 <- ifelse(is.finite(bias_se1) & bias_se1 > 0, bias_se1, NA_real_)
            se2 <- ifelse(is.finite(bias_se2) & bias_se2 > 0, bias_se2, NA_real_)
            contrast <- ifelse(is.finite(local1) & is.finite(local2), (bias1 - bias2)/target_sign, NA_real_)
            se_scale <- max(se1, se2)
            relative_variances <- (c(se1, se2)/se_scale)^2
            se_contrast <- ifelse(is.finite(se1) & is.finite(se2), se_scale * sqrt(sum(relative_variances)), 
                NA_real_)
            t_val <- ifelse(is.finite(contrast) & is.finite(se_contrast) & se_contrast > 0, contrast/se_contrast, 
                NA_real_)
            n1 <- r1$`Observd Count`
            n2 <- r2$`Observd Count`
            df_raw <- NA_real_
            if (identical(df_method, "classical")) {
                df_raw <- welch_satterthwaite_df(relative_variances, c(n1 - 1, n2 - 1))
            }
            else if (all(is.finite(c(n1, n2))) && min(n1, n2) > 1) {
                df_raw <- welch_satterthwaite_df(relative_variances, c(n1 + 1, n2 + 1)) * ((n1 + n2 - 
                  2)/(n1 + n2 + 2))
            }
            df_t <- if (identical(df_method, "facets")) {
                floor(round(df_raw, 10L))
            }
            else df_raw
            if (!is.finite(df_t) || df_t <= 0) 
                df_t <- NA_real_
            p_val <- ifelse(is.finite(t_val) & is.finite(df_t) & df_t > 0, 2 * stats::pt(-abs(t_val), 
                df = df_t), NA_real_)
            screen_reason <- if (!is.finite(target_sign)) {
                "Target orientation is unavailable; recreate estimate_bias() from the saved fit and matching diagnostics."
            }
            else if (!is.finite(contrast)) {
                "Finite local target measures are required."
            }
            else if (!is.finite(t_val)) {
                "Both conditional bias SEs must be finite and positive."
            }
            else if (!is.finite(df_t)) {
                "Both weighted counts must exceed one and yield positive reference df."
            }
            else NA_character_
            rows[[length(rows) + 1]] <- tibble(Target = tgt_level, TargetSign = target_sign, `Target N` = tgt_index, 
                `Target Measure` = tgt_measure, `Target S.E.` = tgt_se, Context1 = c1, `Context1 N` = r1[[paste0(context_prefix, 
                  "_Index")]], `Local Measure1` = local1, SE1 = se1, `Obs-Exp Avg1` = r1$`Obs-Exp Average`, 
                Count1 = r1$`Observd Count`, ObsN1 = r1$ObsN, Context2 = c2, `Context2 N` = r2[[paste0(context_prefix, 
                  "_Index")]], `Local Measure2` = local2, SE2 = se2, `Obs-Exp Avg2` = r2$`Obs-Exp Average`, 
                Count2 = r2$`Observd Count`, ObsN2 = r2$ObsN, Contrast = contrast, SE = se_contrast, 
                t = t_val, d.f. = df_t, Prob. = p_val, InferenceTier = "screening", SupportsFormalInference = FALSE, 
                FormalInferenceEligible = FALSE, PrimaryReportingEligible = FALSE, ReportingUse = "screening_only", 
                CalculationVersion = 3L, ScreenStatus = if (is.na(screen_reason)) 
                  "available_conditional"
                else "unavailable", ScreenReason = screen_reason, ContrastBasis = "local target measure in Context1 minus Context2, oriented by TargetSign", 
                LocalSEBasis = "conditional cell information; baseline calibration held fixed", SEBasis = "combined conditional bias SEs; cross-cell covariance and calibration uncertainty omitted", 
                DFUnrounded = df_raw, DFMethod = df_method, StatisticLabel = "Bias-contrast Welch screening t", 
                ProbabilityMetric = "screening tail area", DFBasis = if (df_method == "facets") 
                  "FACETS 4.5.0 modified Rasch-Welch using weighted counts; df rounded down"
                else "classical Welch-Satterthwaite using weighted-count minus 1 in each cell")
        }
    }
    bind_rows(rows)
}

extract_anchor_tables <- function(config) {
    facet_names <- c("Person", config$facet_names)
    anchor_tbl <- purrr::map_dfr(facet_names, function(facet) {
        spec <- if (facet == "Person") 
            config$theta_spec
        else config$facet_specs[[facet]]
        anchors <- spec$anchors
        if (is.null(anchors)) 
            return(tibble())
        df <- filter(tibble(Facet = facet, Level = names(anchors), Anchor = as.numeric(anchors)), is.finite(Anchor))
        if (nrow(df) == 0) 
            return(tibble())
        mutate(df, Source = ifelse(facet %in% config$dummy_facets, "Dummy facet", "Anchor"))
    })
    group_tbl <- purrr::map_dfr(facet_names, function(facet) {
        spec <- if (facet == "Person") 
            config$theta_spec
        else config$facet_specs[[facet]]
        groups <- spec$groups
        if (is.null(groups)) 
            return(tibble())
        df <- filter(tibble(Facet = facet, Level = names(groups), Group = as.character(groups)), !is.na(Group), 
            Group != "")
        if (nrow(df) == 0) 
            return(tibble())
        group_values <- spec$group_values
        mutate(df, GroupValue = ifelse(Group %in% names(group_values), group_values[Group], NA_real_))
    })
    list(anchors = anchor_tbl, groups = group_tbl)
}

calc_facets_chisq <- function(measure_df) {
    if (is.null(measure_df) || nrow(measure_df) == 0) 
        return(tibble())
    fixed_facets <- unique(measure_df$Facet[which(measure_df[["Fixed"]] %in% TRUE)])
    measure_df$SE[measure_df$Facet %in% fixed_facets] <- NA_real_
    mutate(select(ungroup(mutate(rowwise(mutate(summarize(group_by(measure_df, Facet), Levels = n(), 
        EligibleLevels = sum(is.finite(Estimate) & is.finite(SE) & SE > 0), ExcludedLevels = Levels - 
            EligibleLevels, MeanMeasure = mean(Estimate, na.rm = TRUE), SD = sd(Estimate, na.rm = TRUE), 
        EstimateVec = list(Estimate), SEVec = list(SE), FixedChiSq = {
            w <- ifelse(is.finite(SE) & SE > 0, 1/(SE^2), NA_real_)
            d <- Estimate
            ok <- is.finite(w) & is.finite(d)
            if (sum(ok) < 2) 
                NA_real_
            else {
                centered <- d[ok] - d[ok][1]
                center <- sum(w[ok] * centered)/sum(w[ok])
                sum(w[ok] * (centered - center)^2)
            }
        }, FixedDF = pmax(EligibleLevels - 1, 0), RandomVar = {
            d <- Estimate
            se2 <- SE^2
            ok <- is.finite(d) & is.finite(se2) & se2 > 0
            if (sum(ok) < 2) 
                NA_real_
            else (sum((d[ok] - mean(d[ok]))^2)/(sum(ok) - 1)) - (sum(se2[ok])/sum(ok))
        }, .groups = "drop"), FixedProb = ifelse(is.finite(FixedChiSq) & FixedDF > 0, stats::pchisq(FixedChiSq, 
        df = FixedDF, lower.tail = FALSE), NA_real_), RandomVar = ifelse(is.finite(RandomVar) & RandomVar > 
        0, RandomVar, NA_real_))), RandomChiSq = {
        if (!is.finite(RandomVar) || RandomVar <= 0) {
            NA_real_
        }
        else {
            d <- unlist(EstimateVec)
            se <- unlist(SEVec)
            w <- ifelse(is.finite(se) & se > 0, 1/(RandomVar + se^2), NA_real_)
            ok <- is.finite(w) & is.finite(d)
            if (sum(ok) < 2) 
                NA_real_
            else {
                centered <- d[ok] - d[ok][1]
                center <- sum(w[ok] * centered)/sum(w[ok])
                sum(w[ok] * (centered - center)^2)
            }
        }
    }, RandomDF = pmax(EligibleLevels - 2, 0), RandomProb = ifelse(is.finite(RandomChiSq) & RandomDF > 
        0, stats::pchisq(RandomChiSq, df = RandomDF, lower.tail = FALSE), NA_real_))), -EstimateVec, 
        -SEVec), InferenceTier = "screening", SupportsFormalInference = FALSE, StatisticBasis = "Diagonal-SE heterogeneity screen; covariance not propagated")
}

build_param_slices <- function(sizes) {
    out <- list()
    idx <- 1L
    for (nm in names(sizes)) {
        k <- as.integer(sizes[[nm]] %||% 0L)
        if (k > 0L) {
            out[[nm]] <- idx:(idx + k - 1L)
            idx <- idx + k
        }
        else {
            out[[nm]] <- integer(0)
        }
    }
    out
}

constraint_jacobian <- function(spec) {
    n_levels <- length(spec$levels %||% character(0))
    n_params <- as.integer(spec$n_params %||% 0L)
    out <- matrix(0, nrow = n_levels, ncol = n_params)
    rownames(out) <- as.character(spec$levels %||% character(0))
    if (n_levels == 0L || n_params == 0L) {
        return(out)
    }
    for (i in seq_len(n_levels)) {
        unit <- numeric(n_levels)
        unit[i] <- 1
        out[i, ] <- constraint_grad_project(unit, spec)
    }
    out
}

sum_zero_jacobian <- function(n_levels) {
    n_levels <- as.integer(n_levels %||% 0L)
    n_params <- sum_zero_param_count(n_levels)
    out <- matrix(0, nrow = max(n_levels, 0L), ncol = n_params)
    if (n_levels <= 1L || n_params == 0L) {
        return(out)
    }
    out[seq_len(n_params), seq_len(n_params)] <- diag(n_params)
    out[n_levels, ] <- -1
    out
}

block_diag_sum_zero_jacobian <- function(n_blocks, n_levels) {
    n_blocks <- as.integer(n_blocks %||% 0L)
    n_levels <- as.integer(n_levels %||% 0L)
    one <- sum_zero_jacobian(n_levels)
    n_params <- ncol(one)
    out <- matrix(0, nrow = max(n_blocks, 0L) * max(n_levels, 0L), ncol = max(n_blocks, 0L) * n_params)
    if (n_blocks <= 0L || n_levels <= 0L || n_params == 0L) {
        return(out)
    }
    for (i in seq_len(n_blocks)) {
        row_idx <- ((i - 1L) * n_levels + 1L):(i * n_levels)
        col_idx <- ((i - 1L) * n_params + 1L):(i * n_params)
        out[row_idx, col_idx] <- one
    }
    out
}

symmetrize_matrix <- function(mat) {
    if (is.null(mat)) 
        return(NULL)
    (mat + t(mat))/2
}

invert_information_matrix <- function(info_mat) {
    if (is.null(info_mat)) {
        return(list(cov = NULL, regularized = FALSE, rank = 0L))
    }
    info_mat <- suppressWarnings(as.matrix(info_mat))
    if (!is.numeric(info_mat) || length(info_mat) == 0L || any(!is.finite(info_mat))) {
        return(list(cov = NULL, regularized = FALSE, rank = 0L))
    }
    info_mat <- symmetrize_matrix(info_mat)
    eig <- tryCatch(eigen(info_mat, symmetric = TRUE), error = function(e) NULL)
    if (is.null(eig)) {
        return(list(cov = NULL, regularized = FALSE, rank = 0L))
    }
    values <- eig$values
    max_val <- suppressWarnings(max(abs(values), na.rm = TRUE))
    tol <- if (is.finite(max_val) && max_val > 0) {
        max_val * sqrt(.Machine$double.eps)
    }
    else {
        sqrt(.Machine$double.eps)
    }
    rank <- sum(values > tol)
    regularized <- any(values <= tol)
    safe_values <- pmax(values, tol)
    cov_mat <- eig$vectors %*% diag(1/safe_values, nrow = length(safe_values)) %*% t(eig$vectors)
    cov_mat <- symmetrize_matrix(cov_mat)
    list(cov = cov_mat, regularized = regularized, rank = rank)
}

mfrm_refine_mml_information <- function(par, fn, gr, hessian) {
    summary <- data.frame(Verified = FALSE, RelativeChange = NA_real_, InverseResidual = NA_real_, CurvatureScaledGradient = NA_real_, 
        Detail = "Information refinement did not complete.")
    refined <- hessian
    result <- tryCatch({
        h1 <- stats::optimHess(par, fn, gr, control = list(ndeps = rep(1e-04, length(par))))
        h2 <- stats::optimHess(par, fn, gr, control = list(ndeps = rep(1e-05, length(par))))
        coarse <- symmetrize_matrix((100 * h1 - hessian)/99)
        refined <- symmetrize_matrix((100 * h2 - h1)/99)
        if (!all(is.finite(c(coarse, refined)))) 
            stop("Refined information was nonfinite.")
        coarse_root <- tryCatch(chol(coarse), error = function(e) NULL)
        root <- tryCatch(chol(refined), error = function(e) NULL)
        if (is.null(coarse_root) || is.null(root)) 
            stop("Refined information is not consistently positive definite.")
        inverse_root <- backsolve(root, diag(length(par)))
        summary$RelativeChange <- norm(crossprod(inverse_root, (refined - coarse) %*% inverse_root), 
            "2")
        covariance <- chol2inv(root)
        residual <- refined %*% covariance - diag(length(par))
        summary$InverseResidual <- max(norm(residual, "I"), norm(residual, "1"))
        summary$CurvatureScaledGradient <- sqrt(sum(forwardsolve(t(root), gr(par))^2))
        summary$Verified <- all(is.finite(unlist(summary[2:4]))) && summary$RelativeChange <= 0.001 && 
            summary$InverseResidual <= 1e-06 && summary$CurvatureScaledGradient <= 1e-04 && all(is.finite(covariance))
        summary$Detail <- if (summary$Verified) {
            paste("Ill-conditioned information: an unregularized inverse passed numerical", "refinement, inversion and scaled-gradient checks. Weak information can", 
                "still make Wald intervals unreliable; review interval width, boundary", "proximity and quadrature sensitivity.")
        }
        else {
            sprintf(paste("Ill-conditioned information did not pass refinement, inversion or scaled-gradient checks:", 
                "relative curvature change %.3g (limit 1e-3), inverse residual %.3g (limit 1e-6),", "standardized Newton displacement %.3g (limit 1e-4). Ordinary inference remains unavailable."), 
                summary$RelativeChange, summary$InverseResidual, summary$CurvatureScaledGradient)
        }
        if (summary$Verified) 
            covariance
        else NULL
    }, error = function(e) {
        summary$Detail <<- paste("Information refinement failed:", conditionMessage(e), "Ordinary inference remains unavailable.")
        NULL
    })
    list(cov = result, hessian = refined, review = summary)
}

mfrm_mml_information_caution <- function(information) {
    review <- information$solution_information$inverse_review
    if (identical(information$status, "ok") && isTRUE(review$Verified)) {
        return(review$Detail)
    }
    character()
}

compute_mml_parameter_covariance <- function(res, retained_matrices = 0L, solution_tolerance = NULL) {
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    if (!identical(method, "MML")) {
        return(list(cov = NULL, hessian = NULL, sizes = build_param_sizes(res$config), param_slices = build_param_slices(build_param_sizes(res$config)), 
            status = "not_applicable", detail = "MML observed-information covariance is only computed for MML fits.", 
            regularized = FALSE, rank = 0L))
    }
    if (is.null(res$opt$par) || length(res$opt$par) == 0L) {
        sizes <- build_param_sizes(res$config)
        return(list(cov = NULL, hessian = NULL, sizes = sizes, param_slices = build_param_slices(sizes), 
            status = "fallback", detail = "Optimized parameter vector was not available; observed-information covariance was not computed.", 
            regularized = FALSE, rank = 0L))
    }
    config <- res$config
    sizes <- build_param_sizes(config)
    p <- sum(unlist(sizes))
    identification <- mfrm_mml_inference_identification(res, sizes)
    if (isTRUE(identification$excluded)) {
        return(list(cov = NULL, hessian = NULL, sizes = sizes, param_slices = build_param_slices(sizes), 
            status = "unavailable", regularized = FALSE, rank = NA_integer_, detail = identification$detail, 
            identification = identification, solution_information = list(status = "unavailable", detail = identification$detail)))
    }
    budget <- getOption("mfrmr.max_information_bytes", 256 * 1024^2)
    if (!is.numeric(budget) || is.complex(budget) || length(budget) != 1L || !is.finite(budget) || budget <= 
        0) {
        stop("Option mfrmr.max_information_bytes must be one finite positive byte count.", call. = FALSE)
    }
    if (!is.numeric(retained_matrices) || is.complex(retained_matrices) || length(retained_matrices) != 
        1L || !is.finite(retained_matrices) || retained_matrices < 0 || retained_matrices != floor(retained_matrices)) {
        stop("`retained_matrices` must be a nonnegative integer.", call. = FALSE)
    }
    workspace <- (8 + retained_matrices) * 8 * as.double(p)^2
    if (workspace > budget || length(res$opt$par) != p || any(!is.finite(res$opt$par))) {
        return(list(cov = NULL, hessian = NULL, sizes = sizes, param_slices = build_param_slices(sizes), 
            status = "unavailable", regularized = FALSE, rank = 0L, detail = if (workspace > budget) paste0("Joint-information matrix workspace estimate (", 
                format(workspace, scientific = FALSE), " bytes) exceeds option mfrmr.max_information_bytes (", 
                format(budget, scientific = FALSE), " bytes). No matrix was allocated.") else "The retained parameter vector is non-finite or has the wrong dimension."))
    }
    idx <- build_indices(res$prep, step_facet = config$step_facet, slope_facet = config$slope_facet, 
        interaction_specs = config$interaction_specs, gpcm_spec = config$gpcm_spec)
    quad_points <- max(1L, as.integer(config$estimation_control$quad_points %||% 15L))
    quad <- gauss_hermite_normal(quad_points)
    cache <- make_param_cache(sizes, config, idx, is_mml = TRUE)
    fn <- function(par, idx, config, sizes, quad) {
        cache$ensure(par)
        mfrm_loglik_mml_cached(cache, idx, config, quad)
    }
    gr <- function(par, idx, config, sizes, quad) {
        cache$ensure(par)
        mfrm_grad_mml_cached(cache, idx, config, sizes, quad)
    }
    if (mfrmr_adaptive_integration(config)) {
        evaluator <- make_mfrm_direct_evaluator("MML", cache, idx, config, sizes, quad)
        fn <- function(par, idx, config, sizes, quad) evaluator$value(par)
        gr <- function(par, idx, config, sizes, quad) evaluator$gradient(par)
    }
    evaluation <- NULL
    if (!is.null(solution_tolerance)) {
        evaluation <- tryCatch(list(objective = fn(res$opt$par, idx, config, sizes, quad), gradient = gr(res$opt$par, 
            idx, config, sizes, quad)), error = function(e) NULL)
        objective <- res$opt$value
        finite_scalar <- function(x) is.numeric(x) && !is.complex(x) && length(x) == 1L && is.finite(x)
        if (!is.null(evaluation) && finite_scalar(objective) && finite_scalar(evaluation$objective) && 
            length(evaluation$gradient) == p && all(is.finite(evaluation$gradient))) {
            reason <- if (abs(evaluation$objective - objective) > 1e-10 * max(1, abs(objective))) {
                "The retained objective does not match reevaluation at the supplied data and parameters."
            }
            else if (max(abs(evaluation$gradient)) > solution_tolerance) {
                "The reevaluated MML gradient exceeds the numerical convergence tolerance."
            }
            else NULL
            if (!is.null(reason)) 
                return(list(cov = NULL, hessian = NULL, sizes = sizes, param_slices = build_param_slices(sizes), 
                  status = "unavailable", regularized = FALSE, rank = 0L, detail = reason, solution_information = list(status = "rejected_local_solution", 
                    detail = reason)))
        }
    }
    hess <- tryCatch(stats::optimHess(par = res$opt$par, fn = fn, gr = gr, idx = idx, config = config, 
        sizes = sizes, quad = quad), error = function(e) e)
    if (inherits(hess, "error") || is.null(hess)) {
        msg <- if (inherits(hess, "error")) 
            conditionMessage(hess)
        else "Unknown Hessian error."
        return(list(cov = NULL, hessian = NULL, sizes = sizes, param_slices = build_param_slices(sizes), 
            status = "fallback", detail = paste0("Observed-information Hessian was unavailable; covariance was not computed. ", 
                msg), regularized = FALSE, rank = 0L))
    }
    inv_info <- invert_information_matrix(hess)
    inverse_review <- NULL
    if (isTRUE(inv_info$regularized) && isTRUE(min(eigen(symmetrize_matrix(hess), symmetric = TRUE, only.values = TRUE)$values) > 
        0)) {
        refinement_workspace <- (20 + retained_matrices) * 8 * as.double(p)^2
        if (refinement_workspace > budget) {
            refined <- list(cov = NULL, hessian = hess, review = data.frame(Verified = FALSE, RelativeChange = NA_real_, 
                InverseResidual = NA_real_, CurvatureScaledGradient = NA_real_, Detail = paste0("Information refinement workspace estimate (", 
                  format(refinement_workspace, scientific = FALSE), " bytes) exceeds option mfrmr.max_information_bytes (", 
                  format(budget, scientific = FALSE), " bytes). Ordinary inference remains unavailable.")))
        }
        else {
            refined <- mfrm_refine_mml_information(res$opt$par, function(p) fn(p, idx, config, sizes, 
                quad), function(p) gr(p, idx, config, sizes, quad), hess)
        }
        hess <- refined$hessian
        inverse_review <- refined$review
        inv_info <- list(cov = refined$cov, regularized = FALSE, rank = if (isTRUE(inverse_review$Verified)) length(res$opt$par) else 0L)
    }
    solution_information <- tryCatch({
        eig <- eigen(symmetrize_matrix(hess), symmetric = TRUE, only.values = TRUE)$values
        if (is.null(evaluation)) 
            evaluation <- list(gradient = gr(res$opt$par, idx, config, sizes, quad), objective = fn(res$opt$par, 
                idx, config, sizes, quad))
        list(status = "evaluated_diagnostic_only", free_dimension = length(res$opt$par), inverse_review = inverse_review, 
            gradient = evaluation$gradient, evaluation_summary = data.frame(ReevaluatedObjective = evaluation$objective, 
                GradientMaxAbs = max(abs(evaluation$gradient))), eigenvalue_summary = data.frame(Smallest = min(eig), 
                AbsoluteScale = max(abs(eig))))
    }, error = function(e) list(status = "unavailable", detail = conditionMessage(e)))
    cov_free <- inv_info$cov
    if (is.null(cov_free)) {
        return(list(cov = NULL, hessian = hess, solution_information = solution_information, sizes = sizes, 
            param_slices = build_param_slices(sizes), status = "fallback", detail = inverse_review$Detail %||% 
                "Observed-information matrix could not be inverted; covariance was not computed.", regularized = FALSE, 
            rank = inv_info$rank))
    }
    detail <- if (isTRUE(inverse_review$Verified)) {
        inverse_review$Detail
    }
    else if (isTRUE(inv_info$regularized)) {
        "MML parameter covariance uses the observed information of the marginal log-likelihood; a near-singular Hessian was regularized during inversion."
    }
    else {
        "MML parameter covariance uses the observed information of the marginal log-likelihood."
    }
    list(cov = cov_free, solution_information = solution_information, hessian = hess, sizes = sizes, 
        param_slices = build_param_slices(sizes), status = if (isTRUE(inv_info$regularized)) "regularized" else "ok", 
        detail = detail, regularized = isTRUE(inv_info$regularized), rank = inv_info$rank)
}

covariance_diag_se <- function(cov_mat) {
    if (is.null(cov_mat)) 
        return(numeric(0))
    diag_var <- diag(symmetrize_matrix(cov_mat))
    diag_var[diag_var < 0 & abs(diag_var) < 1e-10] <- 0
    ifelse(diag_var >= 0, sqrt(diag_var), NA_real_)
}

compute_mml_facet_model_se <- function(res, covariance = NULL) {
    covariance <- covariance %||% compute_mml_parameter_covariance(res)
    if (!covariance$status %in% c("ok", "regularized") || is.null(covariance$cov)) {
        return(list(table = tibble(), status = covariance$status, detail = covariance$detail))
    }
    config <- res$config
    cov_free <- covariance$cov
    param_slices <- covariance$param_slices
    facet_tbl <- purrr::map_dfr(config$facet_names, function(facet) {
        spec <- config$facet_specs[[facet]]
        levels <- as.character(spec$levels %||% res$prep$levels[[facet]] %||% character(0))
        slice <- param_slices[[facet]] %||% integer(0)
        if (length(levels) == 0L) {
            return(tibble(Facet = character(0), Level = character(0), ModelSE = numeric(0)))
        }
        if (length(slice) == 0L || is.null(spec) || (spec$n_params %||% 0L) == 0L) {
            return(tibble(Facet = facet, Level = levels, ModelSE = NA_real_))
        }
        jac <- constraint_jacobian(spec)
        cov_block <- cov_free[slice, slice, drop = FALSE]
        cov_expanded <- symmetrize_matrix(jac %*% cov_block %*% t(jac))
        tibble(Facet = facet, Level = levels, ModelSE = covariance_diag_se(cov_expanded))
    })
    detail <- if (identical(covariance$status, "regularized")) {
        "MML facet ModelSE values use the observed information of the marginal log-likelihood; a near-singular Hessian was regularized during inversion."
    }
    else {
        "MML facet ModelSE values use the observed information of the marginal log-likelihood."
    }
    if (isTRUE(covariance$solution_information$inverse_review$Verified)) {
        detail <- paste(detail, covariance$solution_information$inverse_review$Detail)
    }
    list(table = facet_tbl, status = covariance$status, detail = detail)
}

compute_mml_structural_parameter_se <- function(res, covariance = NULL, ci_level = 0.95) {
    step_tbl <- as.data.frame(res$steps %||% tibble(), stringsAsFactors = FALSE)
    slope_tbl <- as.data.frame(res$slopes %||% tibble(), stringsAsFactors = FALSE)
    if (identical(res$config$model, "GPCM") && identical(res$config$method, "MML") && nrow(slope_tbl)) {
        slope_tbl$PrimaryEstimate <- slope_tbl$PrimaryEstimate %||% rep(NA_real_, nrow(slope_tbl))
        slope_tbl$PrimaryLogEstimate <- slope_tbl$PrimaryLogEstimate %||% rep(NA_real_, nrow(slope_tbl))
        slope_tbl$ParameterStatus <- slope_tbl$ParameterStatus %||% rep("not_evaluated", nrow(slope_tbl))
        slope_tbl$PrimaryEstimateBasis <- slope_tbl$PrimaryEstimateBasis %||% rep("no_primary_value_applicable_audit_incomplete", 
            nrow(slope_tbl))
        previous <- slope_tbl$ParameterStatus %in% "finite_local_solution"
        slope_tbl$PrimaryEstimate[previous] <- slope_tbl$PrimaryLogEstimate[previous] <- NA_real_
        slope_tbl$ParameterStatus[previous] <- "not_evaluated"
        slope_tbl$PrimaryEstimateBasis[previous] <- "no_primary_value_applicable_audit_incomplete"
        if ("FixedLatentSDPrimaryEstimate" %in% names(slope_tbl)) {
            slope_tbl$FixedLatentSDPrimaryEstimate[previous] <- NA_real_
        }
    }
    covariance <- covariance %||% compute_mml_parameter_covariance(res)
    z <- stats::qnorm((1 - ci_level)/2, lower.tail = FALSE)
    add_unavailable <- function(tbl, kind) {
        if (!is.data.frame(tbl) || nrow(tbl) == 0L) 
            return(tbl)
        tbl$SE <- NA_real_
        tbl$CI_Lower <- NA_real_
        tbl$CI_Upper <- NA_real_
        tbl$CI_Level <- ci_level
        tbl$SE_Method <- if (identical(covariance$status, "not_applicable")) {
            "not applicable"
        }
        else {
            "not available"
        }
        tbl$SE_Status <- covariance$status
        tbl$SE_Detail <- covariance$detail
        if (identical(kind, "step") && !is.null(res$config$step_constraint_map)) {
            tbl$CIEligible <- FALSE
            tbl$CIUse <- "unavailable"
        }
        if (identical(kind, "slope")) {
            tbl$LogSE <- NA_real_
            tbl$LogCI_Lower <- NA_real_
            tbl$LogCI_Upper <- NA_real_
            tbl$SEEligible <- FALSE
            tbl$CIEligible <- FALSE
            tbl$UncertaintyEligibility <- "not_eligible_covariance"
            tbl$CIUse <- "unavailable"
            tbl$InferenceBasis <- "mml_joint_information_log_wald"
            tbl$InferenceReview <- covariance$detail
        }
        tbl
    }
    if (!covariance$status %in% c("ok", "regularized") || is.null(covariance$cov)) {
        return(list(steps = add_unavailable(step_tbl, "step"), slopes = add_unavailable(slope_tbl, "slope"), 
            summary = tibble(Component = c("steps", "slopes"), Available = FALSE, Status = covariance$status, 
                Detail = covariance$detail), status = covariance$status, detail = covariance$detail))
    }
    config <- res$config
    cov_free <- covariance$cov
    param_slices <- covariance$param_slices
    status <- covariance$status
    se_method <- if (identical(status, "regularized")) {
        "Observed information (MML; regularized Hessian)"
    }
    else {
        "Observed information (MML)"
    }
    if (nrow(step_tbl) > 0L) {
        step_slice <- param_slices$steps %||% integer(0)
        n_steps <- max(config$n_cat - 1L, 0L)
        if (length(step_slice) > 0L && n_steps > 0L) {
            if (!is.null(config$step_constraint_map)) {
                jac <- as.matrix(config$step_constraint_map$basis)
            }
            else if (identical(config$model, "RSM")) {
                jac <- sum_zero_jacobian(n_steps)
            }
            else {
                n_step_levels <- length(config$facet_levels[[config$step_facet]] %||% character(0))
                jac <- block_diag_sum_zero_jacobian(n_step_levels, n_steps)
            }
            cov_step <- symmetrize_matrix(jac %*% cov_free[step_slice, step_slice, drop = FALSE] %*% 
                t(jac))
            step_se <- covariance_diag_se(cov_step)
            step_tbl$SE <- if (length(step_se) == nrow(step_tbl)) 
                step_se
            else NA_real_
        }
        else {
            step_tbl$SE <- NA_real_
        }
        fixed_rows <- step_tbl$ConstraintStatus %in% c("fixed_value", "fixed_by_constraints")
        if (length(fixed_rows)) 
            step_tbl$SE[fixed_rows] <- NA_real_
        step_tbl$CI_Lower <- ifelse(is.finite(step_tbl$SE), step_tbl$Estimate - z * step_tbl$SE, NA_real_)
        step_tbl$CI_Upper <- ifelse(is.finite(step_tbl$SE), step_tbl$Estimate + z * step_tbl$SE, NA_real_)
        step_tbl$CI_Level <- ci_level
        step_tbl$SE_Method <- se_method
        step_tbl$SE_Status <- status
        step_tbl$SE_Detail <- covariance$detail
        step_tbl$InferenceReady <- mfrm_inference_ready(res)
        step_tbl$SupportsFormalInference <- step_tbl$InferenceReady & identical(status, "ok") & is.finite(step_tbl$SE)
        step_tbl$CIEligible <- step_tbl$SupportsFormalInference
        step_tbl$CIUse <- ifelse(step_tbl$CIEligible, "primary_reporting", "review_before_reporting")
        if (length(fixed_rows)) {
            step_tbl$CIUse[fixed_rows] <- "fixed_under_model"
            step_tbl$SE_Status[fixed_rows] <- "fixed_under_model"
            step_tbl$SE_Detail[fixed_rows] <- "Fixed under the declared constraints. External calibration uncertainty is excluded."
        }
    }
    if (nrow(slope_tbl) > 0L && identical(config$model, "GPCM")) {
        slope_slice <- param_slices[["log_slopes"]] %||% integer(0)
        n_slopes <- nrow(slope_tbl)
        if (length(slope_slice) > 0L && n_slopes > 0L) {
            jac <- sum_zero_jacobian(n_slopes)
            cov_log <- symmetrize_matrix(jac %*% cov_free[slope_slice, slope_slice, drop = FALSE] %*% 
                t(jac))
            log_se <- covariance_diag_se(cov_log)
            slope_vals <- as.numeric(slope_tbl$Estimate)
            cov_slope <- symmetrize_matrix(diag(slope_vals, nrow = length(slope_vals)) %*% cov_log %*% 
                diag(slope_vals, nrow = length(slope_vals)))
            slope_se <- covariance_diag_se(cov_slope)
            slope_tbl$LogSE <- if (length(log_se) == nrow(slope_tbl)) 
                log_se
            else NA_real_
            slope_tbl$SE <- if (length(slope_se) == nrow(slope_tbl)) 
                slope_se
            else NA_real_
        }
        else {
            slope_tbl$LogSE <- NA_real_
            slope_tbl$SE <- NA_real_
        }
        slope_tbl$LogCI_Lower <- ifelse(is.finite(slope_tbl$LogSE), slope_tbl$LogEstimate - z * slope_tbl$LogSE, 
            NA_real_)
        slope_tbl$LogCI_Upper <- ifelse(is.finite(slope_tbl$LogSE), slope_tbl$LogEstimate + z * slope_tbl$LogSE, 
            NA_real_)
        slope_tbl$CI_Lower <- ifelse(is.finite(slope_tbl$LogCI_Lower), exp(slope_tbl$LogCI_Lower), NA_real_)
        slope_tbl$CI_Upper <- ifelse(is.finite(slope_tbl$LogCI_Upper), exp(slope_tbl$LogCI_Upper), NA_real_)
        slope_tbl$OptimizerLogSE <- slope_tbl$LogSE
        slope_tbl$OptimizerSE <- slope_tbl$SE
        slope_tbl$OptimizerLogCI_Lower <- slope_tbl$LogCI_Lower
        slope_tbl$OptimizerLogCI_Upper <- slope_tbl$LogCI_Upper
        slope_tbl$OptimizerCI_Lower <- slope_tbl$CI_Lower
        slope_tbl$OptimizerCI_Upper <- slope_tbl$CI_Upper
        check <- mfrm_gpcm_slope_inference_check(res, covariance)
        uncertainty_eligible <- rep(isTRUE(check$eligible) && identical(status, "ok"), n_slopes) & is.finite(slope_tbl$LogSE) & 
            slope_tbl$LogSE > 0 & is.finite(slope_tbl$SE)
        interval_eligible <- uncertainty_eligible & is.finite(slope_tbl$CI_Lower) & slope_tbl$CI_Lower > 
            0 & is.finite(slope_tbl$CI_Upper)
        slope_tbl$InferenceBasis <- "mml_joint_information_log_wald"
        slope_tbl$InferenceReview <- check$review
        slope_tbl$InferenceCaution <- check$caution %||% ""
        if (isTRUE(check$eligible)) {
            slope_tbl$InferenceReview[!uncertainty_eligible] <- "The transformed slope SE is non-finite or non-positive; an interval is unavailable."
            slope_tbl$InferenceReview[uncertainty_eligible & !interval_eligible] <- "The exponentiated interval is not representable with finite positive bounds; an interval is unavailable."
        }
        slope_tbl$CIUse <- ifelse(interval_eligible, "approximate_pointwise", "unavailable")
        slope_tbl$LogSE[!uncertainty_eligible] <- NA_real_
        slope_tbl$SE[!uncertainty_eligible] <- NA_real_
        slope_tbl$LogCI_Lower[!interval_eligible] <- NA_real_
        slope_tbl$LogCI_Upper[!interval_eligible] <- NA_real_
        slope_tbl$CI_Lower[!interval_eligible] <- NA_real_
        slope_tbl$CI_Upper[!interval_eligible] <- NA_real_
        slope_tbl$SEEligible <- uncertainty_eligible
        slope_tbl$CIEligible <- interval_eligible
        if (identical(config$method, "MML")) {
            slope_tbl$PrimaryEstimate[uncertainty_eligible] <- slope_tbl$Estimate[uncertainty_eligible]
            slope_tbl$PrimaryLogEstimate[uncertainty_eligible] <- slope_tbl$LogEstimate[uncertainty_eligible]
            slope_tbl$ParameterStatus[uncertainty_eligible] <- "finite_local_solution"
            slope_tbl$PrimaryEstimateBasis[uncertainty_eligible] <- "verified_local_mml_solution"
            if ("PopulationSD" %in% names(slope_tbl)) {
                slope_tbl$FixedLatentSDPrimaryEstimate <- slope_tbl$PopulationSD * slope_tbl$PrimaryEstimate
            }
        }
        slope_tbl$UncertaintyEligibility <- ifelse(uncertainty_eligible, "eligible", if (identical(status, 
            "ok")) 
            "not_eligible_solution"
        else "not_eligible_covariance")
        slope_tbl$CI_Level <- ci_level
        slope_tbl$SE_Method <- se_method
        slope_tbl$SE_Status <- status
        slope_tbl$SE_Detail <- covariance$detail
    }
    list(steps = tibble::as_tibble(step_tbl), slopes = tibble::as_tibble(slope_tbl), summary = tibble(Component = c("steps", 
        "slopes"), Available = c(nrow(step_tbl) > 0L && "SE" %in% names(step_tbl) && any(is.finite(step_tbl$SE)), 
        nrow(slope_tbl) > 0L && "SE" %in% names(slope_tbl) && any(is.finite(slope_tbl$SE))), Status = status, 
        Detail = covariance$detail), status = status, detail = covariance$detail, covariance = list(parameters = length(res$opt$par %||% 
        numeric(0)), rank = covariance$rank, regularized = covariance$regularized))
}

apply_fixed_measure_precision <- function(tbl, config) {
    tbl$Fixed <- rep(FALSE, nrow(tbl))
    for (facet in unique(as.character(tbl$Facet))) {
        if (facet == "Person" && identical(config$method, "MML")) 
            next
        spec <- if (facet == "Person") 
            config$theta_spec
        else config$facet_specs[[facet]]
        if (is.null(spec)) 
            next
        if (identical(as.integer(spec$n_params), as.integer(length(spec$levels)))) 
            next
        jac <- mfrmr_constraint_jacobian_sparse(spec, facet)$jacobian
        fixed_levels <- as.character(spec$levels)[Matrix::rowSums(abs(jac)) == 0]
        tbl$Fixed[tbl$Facet == facet & tbl$Level %in% fixed_levels] <- TRUE
    }
    fixed <- tbl$Fixed
    for (nm in intersect(c("SE", "ModelSE", "RealSE", "CI_Lower", "CI_Upper"), names(tbl))) {
        tbl[[nm]][fixed] <- NA_real_
    }
    labels <- c(SE_Method = "Fixed by constraints; not estimated", PrecisionTier = "unavailable", SEUse = "not_applicable", 
        CIBasis = "Fixed value; no sampling interval", CIUse = "not_applicable", CI_Method = "Not applicable to fixed values", 
        CILabel = "Fixed value; no sampling interval")
    for (nm in intersect(names(labels), names(tbl))) tbl[[nm]][fixed] <- labels[[nm]]
    for (nm in intersect(c("SupportsFormalInference", "CIEligible"), names(tbl))) {
        tbl[[nm]][fixed] <- FALSE
    }
    tbl
}

build_measure_se_table <- function(res, obs_df, facet_cols, fit_tbl, covariance = NULL) {
    approx_tbl <- rename(calc_facet_se(obs_df, facet_cols), ApproxSE = SE)
    base_tbl <- distinct(bind_rows(transmute(res$facets$person, Facet = "Person", Level = as.character(Person)), 
        transmute(res$facets$others, Facet = as.character(Facet), Level = as.character(Level))), Facet, 
        Level)
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    convergence <- mfrm_convergence_state(res)
    converged <- convergence$code_converged
    inference_ready <- convergence$inference_ready
    fallback_label <- if (identical(method, "MML")) {
        "Fallback observation-table information"
    }
    else {
        "Observation-table information"
    }
    person_model_tbl <- if (identical(method, "MML") && "SD" %in% names(res$facets$person)) {
        transmute(res$facets$person, Facet = "Person", Level = as.character(Person), ModelSE = as.numeric(SD), 
            SE_Method = "Posterior SD (EAP)")
    }
    else {
        tibble(Facet = character(0), Level = character(0), ModelSE = numeric(0), SE_Method = character(0))
    }
    facet_model_bundle <- compute_mml_facet_model_se(res, covariance = covariance)
    facet_model_tbl <- mutate(facet_model_bundle$table, SE_Method = if (identical(facet_model_bundle$status, 
        "regularized")) {
        "Observed information (MML; regularized Hessian)"
    }
    else "Observed information (MML)")
    structure(arrange(apply_fixed_measure_precision(select(mutate(left_join(left_join(left_join(base_tbl, 
        approx_tbl, by = c("Facet", "Level")), rename(bind_rows(person_model_tbl, facet_model_tbl), ModelSE_Raw = ModelSE, 
        SE_Method_Raw = SE_Method), by = c("Facet", "Level")), select(fit_tbl, "Facet", "Level", "Infit"), 
        by = c("Facet", "Level")), SE_Method_Raw = ifelse(is.finite(.data$ModelSE_Raw), .data$SE_Method_Raw, 
        NA_character_), PrecisionTier = dplyr::case_when(identical(method, "MML") & !is.na(.data$SE_Method_Raw) & 
        !grepl("regularized", .data$SE_Method_Raw, fixed = TRUE) ~ "model_based", identical(method, "MML") ~ 
        "hybrid", TRUE ~ "exploratory"), Converged = converged, InferenceReady = inference_ready, ConvergenceSeverity = convergence$severity, 
        SupportsFormalInference = .data$PrecisionTier == "model_based" & .data$InferenceReady, ModelSE = dplyr::coalesce(.data$ModelSE_Raw, 
            .data$ApproxSE), RealSE = ifelse(is.finite(.data$ModelSE), .data$ModelSE * sqrt(pmax(dplyr::coalesce(.data$Infit, 
            1), 1)), NA_real_), SE = .data$ModelSE, SE_Method = dplyr::coalesce(.data$SE_Method_Raw, 
            fallback_label), SEUse = dplyr::case_when(.data$PrecisionTier == "model_based" & .data$InferenceReady ~ 
            "primary_reporting", .data$PrecisionTier == "model_based" ~ "review_before_reporting", .data$PrecisionTier == 
            "hybrid" ~ "review_before_reporting", TRUE ~ "screening_only"), CIBasis = dplyr::case_when(.data$PrecisionTier == 
            "model_based" & .data$InferenceReady ~ "Normal interval from model-based SE", .data$PrecisionTier == 
            "model_based" ~ "Diagnostic normal band; ordinary inference unavailable for this fit", .data$PrecisionTier == 
            "hybrid" ~ "Diagnostic normal band from fallback or regularized SE", TRUE ~ "Normal interval from exploratory observation-table SE"), 
        CIUse = dplyr::case_when(.data$PrecisionTier == "model_based" & .data$InferenceReady ~ "primary_reporting", 
            .data$PrecisionTier == "model_based" ~ "review_before_reporting", .data$PrecisionTier == 
                "hybrid" ~ "review_before_reporting", TRUE ~ "screening_only")), "Facet", "Level", "N", 
        "SE", "ModelSE", "RealSE", "SE_Method", "Converged", "InferenceReady", "ConvergenceSeverity", 
        "PrecisionTier", "SupportsFormalInference", "SEUse", "CIBasis", "CIUse"), res$config), .data$Facet, 
        .data$Level), mml_se_status = facet_model_bundle$status, mml_se_detail = facet_model_bundle$detail)
}

summarize_precision_basis <- function(df, se_col, distribution_basis = c("sample", "population")) {
    distribution_basis <- match.arg(distribution_basis)
    est <- suppressWarnings(as.numeric(df$Estimate))
    se_vals <- if (se_col %in% names(df)) 
        suppressWarnings(as.numeric(df[[se_col]]))
    else rep(NA_real_, nrow(df))
    ok_est <- is.finite(est)
    ok_se <- ok_est & is.finite(se_vals) & se_vals >= 0
    n_est <- sum(ok_est)
    n_se <- sum(ok_se)
    complete_se <- n_est > 0L && n_se == n_est && !any(df[["Fixed"]] %in% TRUE)
    is_eap <- n_est > 0L && "SE_Method" %in% names(df) && all(grepl("^Posterior SD \\(EAP", as.character(df$SE_Method[ok_est])))
    observed_mean <- if (n_est > 0L) 
        mean(est[ok_est])
    else NA_real_
    observed_var <- if (n_est == 0L) {
        NA_real_
    }
    else if (identical(distribution_basis, "sample")) {
        if (n_est >= 2L) 
            stats::var(est[ok_est])
        else NA_real_
    }
    else {
        mean((est[ok_est] - observed_mean)^2)
    }
    observed_sd <- if (is.finite(observed_var)) 
        sqrt(observed_var)
    else NA_real_
    rmse <- if (complete_se) 
        sqrt(mean(se_vals[ok_se]^2))
    else NA_real_
    error_var <- if (is.finite(rmse)) 
        rmse^2
    else NA_real_
    true_var <- if (is.finite(observed_var) && is.finite(error_var)) {
        if (is_eap) 
            observed_var
        else pmax(observed_var - error_var, 0)
    }
    else {
        NA_real_
    }
    true_sd <- if (is.finite(true_var)) 
        sqrt(true_var)
    else NA_real_
    separation <- if (is.finite(rmse) && rmse > 0 && is.finite(true_sd)) 
        true_sd/rmse
    else NA_real_
    denom_var <- if (is_eap) 
        observed_var + error_var
    else observed_var
    reliability <- if (is.finite(denom_var) && denom_var > 0 && is.finite(true_var)) 
        true_var/denom_var
    else NA_real_
    strata <- if (is.finite(separation)) 
        (4 * separation + 1)/3
    else NA_real_
    list(ObservedMean = observed_mean, ObservedSD = observed_sd, RMSE = rmse, TrueSD = true_sd, ObservedVariance = observed_var, 
        ErrorVariance = error_var, TrueVariance = true_var, Separation = separation, Strata = strata, 
        Reliability = reliability, IsEAP = is_eap, EstimateAvailable = n_est, SEAvailable = n_se, ExcludedEstimates = nrow(df) - 
            n_est, SummaryNote = if (n_est == 0L) {
            "Indices unavailable: no finite estimates."
        } else if (any(df[["Fixed"]] %in% TRUE)) {
            "Indices unavailable: facet includes values fixed by constraints."
        } else if (!complete_se) {
            sprintf("Indices unavailable: %d of %d finite estimates lack a valid SE.", n_est - n_se, 
                n_est)
        } else if (is_eap) {
            sprintf("Computed over %d of %d levels via EAP posterior-variance decomposition (Var(EAP) / (Var(EAP) + mean(SE^2))).", 
                n_est, nrow(df))
        } else {
            sprintf("Computed over %d of %d levels with finite estimates and SEs.", n_est, nrow(df))
        }, MeanSE = if (any(ok_se)) mean(se_vals[ok_se], na.rm = TRUE) else NA_real_, MedianSE = if (any(ok_se)) stats::median(se_vals[ok_se], 
            na.rm = TRUE) else NA_real_)
}

build_facet_precision_summary <- function(measure_df, variability_tbl = NULL) {
    if (is.null(measure_df) || nrow(measure_df) == 0) 
        return(tibble())
    variability_tbl <- as.data.frame(variability_tbl %||% data.frame(), stringsAsFactors = FALSE)
    variability_keep <- intersect(c("Facet", "FixedChiSq", "FixedDF", "FixedProb", "RandomVar", "RandomChiSq", 
        "RandomDF", "RandomProb", "InferenceTier", "SupportsFormalInference", "StatisticBasis"), names(variability_tbl))
    variability_tbl <- variability_tbl[, variability_keep, drop = FALSE]
    mode_map <- c(model = "ModelSE", fit_adjusted = "RealSE")
    rows <- list()
    row_id <- 1L
    facets <- unique(as.character(measure_df$Facet))
    facets <- facets[!is.na(facets) & nzchar(facets)]
    for (facet in facets) {
        sub <- measure_df[as.character(measure_df$Facet) == facet, , drop = FALSE]
        for (mode_name in names(mode_map)) {
            se_col <- mode_map[[mode_name]]
            if (!se_col %in% names(sub)) 
                next
            for (basis_name in c("sample", "population")) {
                stats <- summarize_precision_basis(sub, se_col = se_col, distribution_basis = basis_name)
                rows[[row_id]] <- tibble(Facet = facet, Levels = nrow(sub), DistributionBasis = basis_name, 
                  SEMode = mode_name, SEColumn = se_col, ObservedMean = stats$ObservedMean, ObservedSD = stats$ObservedSD, 
                  RMSE = stats$RMSE, TrueSD = stats$TrueSD, ObservedVariance = stats$ObservedVariance, 
                  ErrorVariance = stats$ErrorVariance, TrueVariance = stats$TrueVariance, Separation = stats$Separation, 
                  Strata = stats$Strata, Reliability = stats$Reliability, EstimateAvailable = stats$EstimateAvailable, 
                  SEAvailable = stats$SEAvailable, ExcludedEstimates = stats$ExcludedEstimates, SummaryNote = stats$SummaryNote, 
                  MeanSE = stats$MeanSE, MedianSE = stats$MedianSE, MeanInfit = if ("Infit" %in% names(sub)) 
                    mean(sub$Infit, na.rm = TRUE)
                  else NA_real_, MeanOutfit = if ("Outfit" %in% names(sub)) 
                    mean(sub$Outfit, na.rm = TRUE)
                  else NA_real_)
                row_id <- row_id + 1L
            }
        }
    }
    out <- bind_rows(rows)
    if (nrow(out) == 0) {
        return(tibble())
    }
    if (nrow(variability_tbl) > 0 && "Facet" %in% names(variability_tbl)) {
        out <- left_join(out, variability_tbl, by = "Facet")
    }
    arrange(out, .data$Facet, .data$DistributionBasis, .data$SEMode)
}

validate_diagnostics_zstd <- function(diagnostics) {
    measures <- diagnostics$measures
    if (inherits(diagnostics, "mfrm_diagnostics") && !inherits(diagnostics, "mfrm_imported_diagnostics") && 
        is.data.frame(measures)) {
        stale_boundary <- !"FitBoundaryRows" %in% names(measures) && any(measures$Facet %in% "Person" & 
            is.infinite(measures$Estimate))
        stale_df <- FALSE
        for (stat in c("Infit", "Outfit")) for (suffix in c("", "_FACETS", "_ENGINE")) {
            df <- measures[[paste0("DF_", stat, suffix)]]
            z <- measures[[paste0(stat, "ZSTD", suffix)]]
            if (!is.null(df) && !is.null(z)) 
                stale_df <- stale_df || any(is.finite(df) & df < 1 & is.finite(z))
        }
        if (stale_boundary || stale_df) 
            stop(paste("These saved diagnostics predate the boundary/small-df ZSTD safeguards.", "Recompute diagnose_mfrm(fit) from the existing fit; no model refit is needed."), 
                call. = FALSE)
    }
    invisible(TRUE)
}

validate_diagnostics_precision <- function(diagnostics) {
    if (inherits(diagnostics, "mfrm_imported_diagnostics") && (!identical(diagnostics$metric_version, 
        1L) || (is.data.frame(diagnostics$facets_chisq) && nrow(diagnostics$facets_chisq) > 0L && !"SupportsFormalInference" %in% 
        names(diagnostics$facets_chisq)) || (is.data.frame(diagnostics$reliability) && nrow(diagnostics$reliability) > 
        0L && !"EstimateAvailable" %in% names(diagnostics$reliability)))) {
        stop(paste("These saved imported diagnostics do not record the current uncertainty restrictions.", 
            "Re-import the existing source-package fit with compute_fit = TRUE; no re-estimation is needed."), 
            call. = FALSE)
    }
    profile <- diagnostics$precision_profile
    if (inherits(diagnostics, "mfrm_diagnostics") && !inherits(diagnostics, "mfrm_imported_diagnostics") && 
        is.data.frame(profile) && nrow(profile) > 0L && !"HasRegularizedSE" %in% names(profile)) {
        stop(paste("These saved diagnostics do not distinguish ordinary, fallback and regularized uncertainty.", 
            "Recompute diagnose_mfrm(fit) from the existing fit; no model refit is needed."), call. = FALSE)
    }
    if (inherits(diagnostics, "mfrm_diagnostics") && !inherits(diagnostics, "mfrm_imported_diagnostics") && 
        is.data.frame(diagnostics$reliability) && nrow(diagnostics$reliability) > 0L && !"ModelSummaryNote" %in% 
        names(diagnostics$reliability)) {
        stop(paste("These saved diagnostics do not record the levels used for reliability.", "Recompute diagnose_mfrm(fit) from the existing fit; no model refit is needed."), 
            call. = FALSE)
    }
    regularized <- identical(diagnostics$parameter_uncertainty$status, "regularized")
    measures <- diagnostics$measures
    validate_diagnostics_zstd(diagnostics)
    if (inherits(diagnostics, "mfrm_diagnostics") && !inherits(diagnostics, "mfrm_imported_diagnostics") && 
        is.list(diagnostics$fair_average)) {
        tryCatch(validate_fair_measure_basis(diagnostics$fair_average), error = function(e) {
            stop(paste("These saved diagnostics do not retain the fitted-measure and mean-reference basis.", 
                "Recompute diagnose_mfrm(fit) from the existing fit; no model refit is needed."), call. = FALSE)
        })
    }
    if (regularized && is.data.frame(measures) && any(measures$Facet != "Person" & measures$SupportsFormalInference %in% 
        TRUE)) {
        stop(paste("These saved diagnostics classify regularized standard errors as ordinary uncertainty.", 
            "Recompute diagnose_mfrm(fit) from the existing fit; no model refit is needed."), call. = FALSE)
    }
    invisible(TRUE)
}

validate_precision_review_profile <- function(profile) {
    if (!is.data.frame(profile) || !"HasRegularizedSE" %in% names(profile)) {
        stop(paste("This saved precision report does not record whether standard errors were regularized.", 
            "Recreate it with mfrm_report(type = 'precision', fit) using the existing fit."), call. = FALSE)
    }
    invisible(TRUE)
}

mfrm_precision_reporting_note <- function(method, precision_tier, inference_ready) {
    if (identical(method, "JML") || identical(precision_tier, "exploratory")) {
        return(paste("JML standard errors and normal bands are exploratory approximations.", "Changing to MML does not by itself establish valid uncertainty;", 
            "review the fitted model and its uncertainty assumptions."))
    }
    if (!isTRUE(inference_ready)) {
        return(paste("This fit does not support ordinary SE/CI inference. Finite standard", "errors and normal bands are diagnostic only; review identification,", 
            "category support, parameter boundaries and numerical convergence."))
    }
    if (identical(precision_tier, "hybrid")) {
        return(paste("Some standard errors use fallback information or a regularized Hessian.", "Those rows are diagnostic only; inspect individual interval eligibility."))
    }
    paste("Uncertainty is conditional on the fitted model. Person posterior SDs", "condition on the fitted calibration; facet standard errors use observed", 
        "information. Review interval assumptions before reporting.")
}

build_precision_profile <- function(res, measure_df, reliability_tbl, facet_precision_tbl) {
    measure_df <- as.data.frame(measure_df %||% data.frame(), stringsAsFactors = FALSE)
    reliability_tbl <- as.data.frame(reliability_tbl %||% data.frame(), stringsAsFactors = FALSE)
    facet_precision_tbl <- as.data.frame(facet_precision_tbl %||% data.frame(), stringsAsFactors = FALSE)
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    method <- ifelse(identical(method, "JMLE"), "JML", method)
    convergence <- mfrm_convergence_state(res)
    converged <- convergence$code_converged
    inference_ready <- convergence$inference_ready
    person_labels <- character(0)
    nonperson_labels <- character(0)
    all_labels <- character(0)
    if (nrow(measure_df) > 0 && "SE_Method" %in% names(measure_df) && "Facet" %in% names(measure_df)) {
        all_labels <- unique(as.character(stats::na.omit(measure_df$SE_Method)))
        person_labels <- unique(as.character(stats::na.omit(measure_df$SE_Method[measure_df$Facet == 
            "Person"])))
        nonperson_labels <- unique(as.character(stats::na.omit(measure_df$SE_Method[measure_df$Facet != 
            "Person"])))
    }
    has_fallback <- identical(method, "MML") && any(grepl("Fallback observation-table information", all_labels))
    has_regularized <- identical(method, "MML") && any(grepl("regularized Hessian", all_labels, fixed = TRUE))
    precision_tier <- if (!identical(method, "MML")) {
        "exploratory"
    }
    else if (has_fallback || has_regularized) {
        "hybrid"
    }
    else {
        "model_based"
    }
    supports_formal <- identical(precision_tier, "model_based") && inference_ready
    has_fit_adjusted <- nrow(measure_df) > 0 && "RealSE" %in% names(measure_df) && any(is.finite(suppressWarnings(as.numeric(measure_df$RealSE))))
    coverage_complete <- FALSE
    if (nrow(facet_precision_tbl) > 0 && all(c("Facet", "DistributionBasis", "SEMode") %in% names(facet_precision_tbl))) {
        precision_facets <- unique(as.character(facet_precision_tbl$Facet))
        precision_facets <- precision_facets[!is.na(precision_facets) & nzchar(precision_facets)]
        if (length(precision_facets) > 0) {
            expected <- expand.grid(DistributionBasis = c("sample", "population"), SEMode = c("model", 
                "fit_adjusted"), stringsAsFactors = FALSE)
            coverage_complete <- all(vapply(precision_facets, function(facet_name) {
                sub <- facet_precision_tbl[facet_precision_tbl$Facet == facet_name, c("DistributionBasis", 
                  "SEMode"), drop = FALSE]
                all(apply(expected, 1, function(row) {
                  any(sub$DistributionBasis == row[["DistributionBasis"]] & sub$SEMode == row[["SEMode"]])
                }))
            }, logical(1)))
        }
    }
    tibble(Method = method, Converged = converged, InferenceReady = inference_ready, ConvergenceSeverity = convergence$severity, 
        ReasonCodes = mfrmr_get_readiness_record(res)$fit$ReasonCodes, PrecisionTier = precision_tier, 
        SupportsFormalInference = supports_formal, HasFallbackSE = has_fallback, HasRegularizedSE = has_regularized, 
        PersonSEBasis = if (length(person_labels) > 0) 
            paste(sort(person_labels), collapse = "; ")
        else NA_character_, NonPersonSEBasis = if (length(nonperson_labels) > 0) 
            paste(sort(nonperson_labels), collapse = "; ")
        else NA_character_, CIBasis = if (identical(precision_tier, "model_based")) {
            if (isTRUE(inference_ready)) {
                "Normal interval from model-based SE"
            }
            else {
                "Diagnostic normal band; ordinary inference unavailable for this fit"
            }
        }
        else if (identical(precision_tier, "hybrid")) {
            "Normal bands from mixed model-based, fallback or regularized SE"
        }
        else {
            "Normal interval from exploratory SE"
        }, ReliabilityBasis = if (identical(precision_tier, "model_based")) {
            if (isTRUE(inference_ready)) {
                if (any(grepl("^Posterior SD \\(EAP", person_labels))) {
                  "EAP posterior-variance decomposition for Person; marginal-SE variance subtraction for structural facets"
                }
                else {
                  "Observed variance minus mean squared model-based or fit-adjusted SE"
                }
            }
            else {
                "Descriptive variance decomposition; ordinary inference unavailable for this fit"
            }
        }
        else if (identical(precision_tier, "hybrid")) {
            "Descriptive variance summary with mixed uncertainty approximations"
        }
        else {
            "Exploratory observed variance minus mean squared SE"
        }, HasFitAdjustedSE = has_fit_adjusted, HasSamplePopulationCoverage = coverage_complete, RecommendedUse = mfrm_precision_reporting_note(method, 
            precision_tier, inference_ready))
}

audit_precision_outputs <- function(res, measure_df, reliability_tbl, facet_precision_tbl, precision_profile_tbl = NULL) {
    measure_df <- as.data.frame(measure_df %||% data.frame(), stringsAsFactors = FALSE)
    if ("Fixed" %in% names(measure_df)) 
        measure_df <- measure_df[!measure_df$Fixed, , drop = FALSE]
    reliability_tbl <- as.data.frame(reliability_tbl %||% data.frame(), stringsAsFactors = FALSE)
    facet_precision_tbl <- as.data.frame(facet_precision_tbl %||% data.frame(), stringsAsFactors = FALSE)
    precision_profile_tbl <- as.data.frame(precision_profile_tbl %||% data.frame(), stringsAsFactors = FALSE)
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    method <- ifelse(identical(method, "JMLE"), "JML", method)
    convergence <- mfrm_convergence_state(res)
    numerical_ready <- identical(as.character(mfrmr_get_readiness_record(res)$fit$NumericalState[1]), 
        "ready")
    finite_model <- if ("ModelSE" %in% names(measure_df)) 
        is.finite(suppressWarnings(as.numeric(measure_df$ModelSE)))
    else logical(0)
    model_share <- if (length(finite_model) > 0) 
        mean(finite_model)
    else NA_real_
    real_ok <- NA
    if (all(c("ModelSE", "RealSE") %in% names(measure_df))) {
        model_vals <- suppressWarnings(as.numeric(measure_df$ModelSE))
        real_vals <- suppressWarnings(as.numeric(measure_df$RealSE))
        ok <- is.finite(model_vals) & is.finite(real_vals)
        if (any(ok)) {
            real_ok <- all(real_vals[ok] >= model_vals[ok])
        }
    }
    rel_ok <- NA
    if (all(c("Reliability", "RealReliability") %in% names(reliability_tbl))) {
        rel_vals <- suppressWarnings(as.numeric(reliability_tbl$Reliability))
        real_rel_vals <- suppressWarnings(as.numeric(reliability_tbl$RealReliability))
        ok <- is.finite(rel_vals) & is.finite(real_rel_vals)
        if (any(ok)) {
            rel_ok <- all(real_rel_vals[ok] <= rel_vals[ok])
        }
    }
    coverage_ok <- FALSE
    if (nrow(precision_profile_tbl) > 0 && "HasSamplePopulationCoverage" %in% names(precision_profile_tbl)) {
        coverage_ok <- isTRUE(precision_profile_tbl$HasSamplePopulationCoverage[1])
    }
    label_status <- "review"
    label_detail <- "The basis of the standard errors was not recorded."
    if (nrow(measure_df) > 0 && all(c("Facet", "SE_Method") %in% names(measure_df))) {
        labels <- as.character(measure_df$SE_Method)
        person_labels <- labels[measure_df$Facet == "Person"]
        nonperson_labels <- labels[measure_df$Facet != "Person"]
        if (identical(method, "MML")) {
            has_person_eap <- length(person_labels) == 0 || any(grepl("Posterior SD \\(EAP\\)", person_labels))
            has_nonperson_info <- length(nonperson_labels) == 0 || any(grepl("Observed information \\(MML", 
                nonperson_labels))
            has_fallback <- any(grepl("Fallback observation-table information", labels))
            has_regularized <- any(grepl("regularized Hessian", labels, fixed = TRUE))
            if (has_person_eap && has_nonperson_info && !has_fallback && !has_regularized) {
                label_status <- "pass"
                label_detail <- "Person uncertainty uses posterior SDs; facet uncertainty uses observed information."
            }
            else if (has_person_eap && (has_nonperson_info || has_fallback)) {
                label_status <- "review"
                label_detail <- "Some SEs use fallback information or a regularized Hessian; those SEs are diagnostic only."
            }
            else {
                label_status <- "warn"
                label_detail <- "The recorded SE basis does not consistently identify Person posterior SDs and facet observed information."
            }
        }
        else {
            uses_obs_info <- all(grepl("Observation-table information", labels))
            if (uses_obs_info) {
                label_status <- "pass"
                label_detail <- "JML SEs use approximate information from the observed responses."
            }
            else {
                label_status <- "warn"
                label_detail <- "The recorded SE basis is inconsistent with the expected JML approximation."
            }
        }
    }
    tibble(Check = c("Precision tier", "Optimizer convergence", "ModelSE availability", "Fit-adjusted SE ordering", 
        "Reliability ordering", "Facet precision coverage", "SE source labels"), Status = c(if (nrow(precision_profile_tbl) > 
        0) {
        if (isTRUE(precision_profile_tbl$SupportsFormalInference[1])) "pass" else "review"
    } else if (identical(method, "MML")) {
        "review"
    } else {
        "review"
    }, if (numerical_ready) "pass" else "review", if (!is.finite(model_share)) "warn" else if (model_share >= 
        0.99) "pass" else if (model_share >= 0.9) "review" else "warn", if (is.na(real_ok)) "review" else if (isTRUE(real_ok)) "pass" else "warn", 
        if (is.na(rel_ok)) "review" else if (isTRUE(rel_ok)) "pass" else "warn", if (isTRUE(coverage_ok)) "pass" else "review", 
        label_status), Detail = c(mfrm_precision_reporting_note(method, as.character(precision_profile_tbl$PrecisionTier[1] %||% 
        ""), convergence$inference_ready), if (numerical_ready) {
        "Numerical convergence checks passed; this alone does not establish valid SEs or intervals."
    } else {
        paste0("Numerical convergence requires review before interpreting estimates.", if (nzchar(convergence$detail)) paste0(" ", 
            convergence$detail) else "")
    }, if (!is.finite(model_share)) {
        "The proportion of available SEs could not be computed."
    } else {
        paste0("Finite standard errors were available for ", sprintf("%.1f", 100 * model_share), "% of non-fixed rows.")
    }, if (is.na(real_ok)) {
        "No finite model/fit-adjusted SE pairs were available for comparison."
    } else if (isTRUE(real_ok)) {
        "Among available pairs, fit-adjusted SEs were at least as large as their unadjusted values."
    } else {
        "At least one fit-adjusted SE was smaller than its unadjusted value."
    }, if (is.na(rel_ok)) {
        "No finite model/fit-adjusted reliability pairs were available for comparison."
    } else if (isTRUE(rel_ok)) {
        "Among available pairs, fit-adjusted reliability values were not larger than the model-based values."
    } else {
        "At least one fit-adjusted reliability estimate exceeded its unadjusted value."
    }, if (isTRUE(coverage_ok)) {
        "Each facet had sample/population summaries for both model and fit-adjusted SE modes."
    } else {
        "At least one facet is missing a sample/population or model/fit-adjusted precision combination."
    }, label_detail))
}

calc_reliability <- function(measure_df) {
    dplyr::ungroup(dplyr::group_modify(dplyr::group_by(measure_df, Facet), function(.x, .y) {
        model_stats <- summarize_precision_basis(.x, if ("ModelSE" %in% names(.x)) 
            "ModelSE"
        else "SE", distribution_basis = "sample")
        real_stats <- summarize_precision_basis(.x, if ("RealSE" %in% names(.x)) 
            "RealSE"
        else if ("ModelSE" %in% names(.x)) 
            "ModelSE"
        else "SE", distribution_basis = "sample")
        tier_vals <- unique(as.character(stats::na.omit(.x$PrecisionTier %||% character(0))))
        converged_vals <- unique(as.logical(stats::na.omit(.x$Converged %||% logical(0))))
        facet_converged <- if (length(converged_vals) == 0) {
            FALSE
        }
        else {
            all(converged_vals)
        }
        facet_ready <- "InferenceReady" %in% names(.x) && all(.x$InferenceReady %in% TRUE)
        facet_tier <- if (length(tier_vals) == 0) {
            NA_character_
        }
        else if (all(tier_vals == "model_based")) {
            "model_based"
        }
        else if (any(tier_vals == "exploratory")) {
            "exploratory"
        }
        else {
            "hybrid"
        }
        supports_formal <- identical(facet_tier, "model_based") && facet_ready && "SupportsFormalInference" %in% 
            names(.x) && all(.x$SupportsFormalInference %in% TRUE) && model_stats$EstimateAvailable == 
            nrow(.x) && model_stats$SEAvailable == nrow(.x) && real_stats$SEAvailable == nrow(.x) && 
            is.finite(model_stats$Reliability) && is.finite(real_stats$Reliability)
        tibble(Levels = nrow(.x), EstimateAvailable = model_stats$EstimateAvailable, ModelSEAvailable = model_stats$SEAvailable, 
            RealSEAvailable = real_stats$SEAvailable, ExcludedEstimates = model_stats$ExcludedEstimates, 
            ModelSummaryNote = model_stats$SummaryNote, RealSummaryNote = real_stats$SummaryNote, Converged = facet_converged, 
            InferenceReady = facet_ready, PrecisionTier = facet_tier, SourceSupportsFormalInference = supports_formal, 
            SupportsFormalInference = FALSE, ReliabilityBasis = if (isTRUE(model_stats$IsEAP)) {
                "EAP posterior-variance decomposition: Var(EAP) / (Var(EAP) + mean(SE^2)); conditional on assumed prior"
            }
            else {
                "Approximate marginal-SE variance subtraction; covariance not propagated"
            }, ReliabilityUse = dplyr::case_when(supports_formal ~ "approximate_summary", identical(facet_tier, 
                "model_based") ~ "review_before_reporting", identical(facet_tier, "hybrid") ~ "review_before_reporting", 
                identical(facet_tier, "exploratory") ~ "screening_only", TRUE ~ NA_character_), SD = model_stats$ObservedSD, 
            RMSE = model_stats$RMSE, TrueSD = model_stats$TrueSD, ObservedVariance = model_stats$ObservedVariance, 
            ModelErrorVariance = model_stats$ErrorVariance, ModelTrueVariance = model_stats$TrueVariance, 
            Separation = model_stats$Separation, Strata = model_stats$Strata, Reliability = model_stats$Reliability, 
            ModelRMSE = model_stats$RMSE, ModelTrueSD = model_stats$TrueSD, ModelSeparation = model_stats$Separation, 
            ModelStrata = model_stats$Strata, ModelReliability = model_stats$Reliability, RealRMSE = real_stats$RMSE, 
            RealTrueSD = real_stats$TrueSD, RealErrorVariance = real_stats$ErrorVariance, RealTrueVariance = real_stats$TrueVariance, 
            RealSeparation = real_stats$Separation, RealStrata = real_stats$Strata, RealReliability = real_stats$Reliability, 
            MeanInfit = if ("Infit" %in% names(.x)) 
                mean(.x$Infit, na.rm = TRUE)
            else NA_real_, MeanOutfit = if ("Outfit" %in% names(.x)) 
                mean(.x$Outfit, na.rm = TRUE)
            else NA_real_)
    }))
}

residual_pca_correlation <- function(residual_matrix) {
    mat <- as.matrix(residual_matrix)
    mat[!is.finite(mat)] <- NA_real_
    correlation <- tryCatch(suppressWarnings(stats::cor(mat, use = "pairwise.complete.obs")), error = function(e) NULL)
    error <- NULL
    if (is.null(correlation) || any(!is.finite(correlation))) {
        error <- paste("Residual correlations are unavailable for one or more columns or pairs.", "Check shared-person counts and residual variation; missing correlations are not replaced with zero.")
    }
    else {
        values <- eigen(correlation, symmetric = TRUE, only.values = TRUE)$values
        if (min(values) < -sqrt(.Machine$double.eps) * max(1, max(values))) {
            error <- paste("Pairwise residual correlations do not form a positive semidefinite matrix.", 
                "Review missingness and shared-person coverage; the matrix is not automatically smoothed.")
        }
    }
    list(cor_matrix = correlation, error = error)
}

compute_principal_components <- function(cor_matrix, n_factors) {
    warnings <- character(0)
    pca <- withCallingHandlers(tryCatch(psych::principal(cor_matrix, nfactors = n_factors, rotate = "none"), 
        error = function(e) e), warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
    })
    list(pca = pca, warning = if (length(warnings) == 0) NULL else paste(unique(warnings), collapse = "; "))
}

compute_pca_overall <- function(obs_df, facet_names, max_factors = 10L) {
    pca_failure <- function(message, residual_matrix = NULL, cor_matrix = NULL, warning = NULL) {
        list(pca = NULL, residual_matrix = residual_matrix, cor_matrix = cor_matrix, error = message, 
            warning = warning, calculation_version = 2L, max_factors = as.integer(max_factors))
    }
    if (length(facet_names) == 0) 
        return(NULL)
    combinations <- unique(obs_df[, facet_names, drop = FALSE])
    if (anyDuplicated(do.call(paste, c(combinations, sep = "_")))) {
        return(pca_failure("Combined-facet column labels are ambiguous. Relabel facet levels to distinguish the combinations."))
    }
    df_aug <- select(mutate(obs_df, Person = as.character(Person), item_combination = paste(!!!rlang::syms(facet_names), 
        sep = "_")), Person, item_combination, StdResidual)
    residual_matrix_prep <- summarize(group_by(df_aug, Person, item_combination), std_residual = mean(StdResidual, 
        na.rm = TRUE), .groups = "drop")
    residual_matrix_wide <- tryCatch({
        tibble::column_to_rownames(tidyr::pivot_wider(residual_matrix_prep, id_cols = Person, names_from = item_combination, 
            values_from = std_residual, values_fill = list(std_residual = NA)), "Person")
    }, error = function(e) e)
    if (inherits(residual_matrix_wide, "error")) {
        return(pca_failure(paste0("Could not reshape the residual matrix: ", conditionMessage(residual_matrix_wide))))
    }
    if (is.null(residual_matrix_wide) || nrow(residual_matrix_wide) < 2 || ncol(residual_matrix_wide) < 
        2) {
        return(pca_failure("Residual PCA requires at least two persons and two combined-facet columns."))
    }
    correlation <- residual_pca_correlation(residual_matrix_wide)
    cor_matrix <- correlation$cor_matrix
    if (!is.null(correlation$error)) {
        return(pca_failure(correlation$error, residual_matrix_wide, cor_matrix))
    }
    max_cap <- if (is.na(max_factors) || !is.finite(max_factors)) {
        min(10L, ncol(cor_matrix) - 1L, nrow(cor_matrix) - 1L)
    }
    else {
        as.integer(max_factors)
    }
    n_factors <- max(1, min(max_cap, ncol(cor_matrix) - 1, nrow(cor_matrix) - 1))
    pca_run <- compute_principal_components(cor_matrix, n_factors)
    pca_result <- pca_run$pca
    if (inherits(pca_result, "error")) {
        return(pca_failure(paste0("Principal components could not be computed: ", conditionMessage(pca_result)), 
            residual_matrix = residual_matrix_wide, cor_matrix = cor_matrix, warning = pca_run$warning))
    }
    list(pca = pca_result, residual_matrix = residual_matrix_wide, cor_matrix = cor_matrix, error = NULL, 
        warning = pca_run$warning, calculation_version = 2L, max_factors = as.integer(max_factors))
}

compute_pca_by_facet <- function(obs_df, facet_names, max_factors = 10L) {
    out <- list()
    for (facet in facet_names) {
        pca_failure <- function(message, residual_matrix = NULL, cor_matrix = NULL, warning = NULL) {
            list(pca = NULL, residual_matrix = residual_matrix, cor_matrix = cor_matrix, error = message, 
                warning = warning, calculation_version = 2L, max_factors = as.integer(max_factors))
        }
        facet_sym <- rlang::sym(facet)
        prep <- summarize(group_by(select(mutate(obs_df, Person = as.character(Person), .Level = as.character(!!facet_sym)), 
            Person, .Level, StdResidual), Person, .Level), std_residual = mean(StdResidual, na.rm = TRUE), 
            .groups = "drop")
        wide <- tryCatch({
            tibble::column_to_rownames(tidyr::pivot_wider(prep, id_cols = Person, names_from = .Level, 
                values_from = std_residual, values_fill = list(std_residual = NA)), "Person")
        }, error = function(e) e)
        if (inherits(wide, "error")) {
            out[[facet]] <- pca_failure(paste0("Could not reshape the residual matrix: ", conditionMessage(wide)))
            next
        }
        if (is.null(wide) || nrow(wide) < 2 || ncol(wide) < 2) {
            out[[facet]] <- pca_failure("Residual PCA requires at least two persons and two facet-level columns.")
            next
        }
        correlation <- residual_pca_correlation(wide)
        cor_mat <- correlation$cor_matrix
        if (!is.null(correlation$error)) {
            out[[facet]] <- pca_failure(correlation$error, wide, cor_mat)
            next
        }
        max_cap <- if (is.na(max_factors) || !is.finite(max_factors)) {
            min(10L, ncol(cor_mat) - 1L, nrow(cor_mat) - 1L)
        }
        else {
            as.integer(max_factors)
        }
        n_factors <- max(1, min(max_cap, ncol(cor_mat) - 1, nrow(cor_mat) - 1))
        pca_run <- compute_principal_components(cor_mat, n_factors)
        pca_obj <- pca_run$pca
        if (inherits(pca_obj, "error")) {
            out[[facet]] <- pca_failure(paste0("Principal components could not be computed: ", conditionMessage(pca_obj)), 
                residual_matrix = wide, cor_matrix = cor_mat, warning = pca_run$warning)
            next
        }
        out[[facet]] <- list(pca = pca_obj, cor_matrix = cor_mat, residual_matrix = wide, error = NULL, 
            warning = pca_run$warning, calculation_version = 2L, max_factors = as.integer(max_factors))
    }
    out
}

mfrm_diagnostics <- function(res, interaction_pairs = NULL, top_n_interactions = 20, whexact = FALSE, 
    fit_df_method = "facets", diagnostic_mode = c("legacy", "marginal_fit", "both"), residual_pca = c("none", 
        "overall", "facet", "both"), pca_max_factors = 10L) {
    res$config$method <- public_mfrm_method_label(res$config$method)
    fit_df_method <- match_fit_df_method(fit_df_method)
    diagnostic_mode <- match.arg(diagnostic_mode, c("legacy", "marginal_fit", "both"))
    residual_pca <- match.arg(tolower(residual_pca), c("none", "overall", "facet", "both"))
    obs_df <- compute_obs_table(res)
    facet_cols <- c("Person", res$config$facet_names)
    overall_fit <- calc_overall_fit(obs_df, whexact = whexact, fit_df_method = fit_df_method)
    fit_tbl <- calc_facet_fit(obs_df, facet_cols, whexact = whexact, fit_df_method = fit_df_method)
    parameter_covariance <- compute_mml_parameter_covariance(res)
    se_tbl <- build_measure_se_table(res, obs_df, facet_cols, fit_tbl, covariance = parameter_covariance)
    structural_uncertainty <- compute_mml_structural_parameter_se(res, covariance = parameter_covariance)
    bias_tbl <- calc_bias_facet(obs_df, facet_cols)
    interaction_tbl <- calc_bias_interactions(obs_df, facet_cols, pairs = interaction_pairs, top_n = top_n_interactions)
    ptmea_tbl <- calc_ptmea(obs_df, facet_cols)
    if (identical(res$config$method, "JML") && res$config$model %in% c("RSM", "PCM") && !length(res$config$interaction_specs) && 
        !any(res$config$anchor_summary$GroupAnchors > 0)) {
        ptmea_tbl <- left_join(ptmea_tbl, .mfrm_expected_ptmea(res, obs_df, facet_cols), by = c("Facet", 
            "Level"))
    }
    subset_tbls <- calc_subsets(obs_df, facet_cols)
    person_tbl <- mutate(res$facets$person, Facet = "Person", Level = Person)
    if (!"ParameterStatus" %in% names(person_tbl)) {
        person_tbl$ParameterStatus <- NA_character_
    }
    facet_tbl <- mutate(res$facets$others, Level = as.character(Level))
    measure_ci_level <- 0.95
    measure_ci_z <- stats::qnorm((1 - measure_ci_level)/2, lower.tail = FALSE)
    measures <- mutate(left_join(left_join(left_join(left_join(bind_rows(select(person_tbl, Facet, Level, 
        Estimate, any_of(c("ParameterStatus", "BoundaryDirection", "ResponseExtreme", "OptimizerEstimate", 
            "DisplayEstimate", "DisplayAdjustment", "PrimaryEstimateBasis", "OptimizerEstimateUse", "ReasonCodes", 
            "ReadinessContractVersion", "SourceFitReadiness", "SourceInferenceReady", "EstimateUse"))), 
        select(facet_tbl, Facet, Level, Estimate)), se_tbl, by = c("Facet", "Level")), fit_tbl, by = c("Facet", 
        "Level")), bias_tbl, by = c("Facet", "Level")), ptmea_tbl, by = c("Facet", "Level")), BoundaryExcluded = dplyr::coalesce(.data$ParameterStatus %in% 
        c("unbounded_low", "unbounded_high"), FALSE), ModelSE = ifelse(.data$BoundaryExcluded, NA_real_, 
        .data$ModelSE), RealSE = ifelse(.data$BoundaryExcluded, NA_real_, .data$RealSE), SE = ifelse(.data$BoundaryExcluded, 
        NA_real_, .data$SE), InferenceReady = ifelse(.data$BoundaryExcluded, FALSE, .data$InferenceReady), 
        SupportsFormalInference = ifelse(.data$BoundaryExcluded, FALSE, .data$SupportsFormalInference), 
        PrecisionTier = ifelse(.data$BoundaryExcluded, "unavailable", .data$PrecisionTier), SE_Method = ifelse(.data$BoundaryExcluded, 
            "Unavailable for unbounded JML Person", .data$SE_Method), SEUse = ifelse(.data$BoundaryExcluded, 
            "not_available", .data$SEUse), CIBasis = ifelse(.data$BoundaryExcluded, "Not available for unbounded JML Person", 
            .data$CIBasis), CIUse = ifelse(.data$BoundaryExcluded, "not_available", .data$CIUse), CI_Lower = ifelse(is.finite(Estimate) & 
            is.finite(SE), Estimate - measure_ci_z * SE, NA_real_), CI_Upper = ifelse(is.finite(Estimate) & 
            is.finite(SE), Estimate + measure_ci_z * SE, NA_real_), CI_Level = measure_ci_level, CI_Method = ifelse(.data$BoundaryExcluded, 
            "Not available for unbounded JML Person", ifelse(.data$Fixed, "Not applicable to fixed values", 
                "Normal approximation")), CIEligible = dplyr::coalesce(.data$SupportsFormalInference, 
            FALSE), CILabel = dplyr::case_when(.data$BoundaryExcluded ~ "No interval; typed unbounded JML Person", 
            .data$Fixed ~ "Fixed value; no sampling interval", .data$PrecisionTier == "model_based" & 
                !.data$CIEligible ~ "Diagnostic normal band; ordinary inference unavailable", .data$PrecisionTier == 
                "model_based" ~ "Model-based normal interval", .data$PrecisionTier == "hybrid" ~ "Diagnostic normal band; review fallback or regularized SE", 
            .data$PrecisionTier == "exploratory" ~ "Approximate interval; screening only", TRUE ~ "Approximate interval"))
    if (!"N" %in% names(measures)) {
        if ("N.x" %in% names(measures) || "N.y" %in% names(measures)) {
            measures <- mutate(measures, N = dplyr::coalesce(.data$N.x, .data$N.y))
        }
        else {
            measures <- mutate(measures, N = NA_real_)
        }
    }
    reliability_tbl <- calc_reliability(measures)
    facets_chisq_tbl <- calc_facets_chisq(measures)
    facet_precision_tbl <- build_facet_precision_summary(measures, facets_chisq_tbl)
    default_rater_facet <- infer_default_rater_facet(res$config$facet_names)
    interrater_tbl <- augment_interrater_with_precision(calc_interrater_agreement(obs_df = obs_df, facet_cols = facet_cols, 
        rater_facet = default_rater_facet, res = res), reliability_tbl = reliability_tbl, rater_facet = default_rater_facet)
    unexpected_abs_z_min <- 3
    unexpected_prob_max <- 0.3
    unexpected_rule <- "residual"
    unexpected_tbl <- calc_unexpected_response_table(obs_df = obs_df, probs = compute_prob_matrix(res), 
        facet_names = res$config$facet_names, rating_min = res$prep$rating_min, abs_z_min = unexpected_abs_z_min, 
        prob_max = unexpected_prob_max, rule = unexpected_rule)
    unexpected_summary <- summarize_unexpected_response_table(unexpected_tbl = unexpected_tbl, total_observations = nrow(obs_df), 
        abs_z_min = unexpected_abs_z_min, prob_max = unexpected_prob_max, rule = unexpected_rule)
    fair_average <- if (identical(res$config$model, "GPCM")) {
        list(raw_by_facet = list(), by_facet = list(), stacked = tibble(), available = FALSE, status = "available_direct_only", 
            direct_route = "fair_average_table(fit, diagnostics = diagnostics)", reason = .mfrmr_const_gpcm_fair_average_rationale)
    }
    else {
        calc_fair_average_bundle(res = res, diagnostics = list(obs = obs_df, measures = measures), totalscore = TRUE, 
            umean = 0, uscale = 1, udecimals = 2, omit_unobserved = FALSE, xtreme = 0)
    }
    displacement_abs_warn <- 0.5
    displacement_abs_t_warn <- 2
    displacement_tbl <- calc_displacement_table(obs_df = obs_df, res = res, measures = measures, abs_displacement_warn = displacement_abs_warn, 
        abs_t_warn = displacement_abs_t_warn)
    displacement_summary <- summarize_displacement_table(displacement_tbl = displacement_tbl, abs_displacement_warn = displacement_abs_warn, 
        abs_t_warn = displacement_abs_t_warn)
    pca_overall <- NULL
    pca_by_facet <- NULL
    if (residual_pca %in% c("overall", "both")) {
        pca_overall <- compute_pca_overall(obs_df = obs_df, facet_names = res$config$facet_names, max_factors = pca_max_factors)
    }
    if (residual_pca %in% c("facet", "both")) {
        pca_by_facet <- compute_pca_by_facet(obs_df = obs_df, facet_names = res$config$facet_names, max_factors = pca_max_factors)
    }
    method <- as.character(res$summary$Method[1] %||% res$config$method %||% NA_character_)
    se_detail <- attr(se_tbl, "mml_se_detail", exact = TRUE) %||% "SE values default to observation-table information approximations."
    precision_profile_tbl <- build_precision_profile(res, measures, reliability_tbl, facet_precision_tbl)
    precision_review_tbl <- audit_precision_outputs(res, measures, reliability_tbl, facet_precision_tbl, 
        precision_profile_tbl = precision_profile_tbl)
    approximation_notes <- tibble::tibble(Component = c("SE", "RealSE", "CI", "Reliability"), Method = c(if (identical(method, 
        "MML")) "Model-based SE (MML)" else "Model-based SE (exploratory JML)", "Fit-adjusted SE", "Normal interval", 
        "Variance decomposition"), Detail = c(paste0("The `SE` column is kept as a compatibility alias for `ModelSE`. ", 
        if (identical(method, "MML")) {
            "Persons use posterior SD from EAP estimation; non-person facets use observed-information SEs from the marginal log-likelihood. "
        } else {
            "JML uses observation-table information as an exploratory approximation. "
        }, se_detail, " Row-level `PrecisionTier`, `InferenceReady`, `SupportsFormalInference`, and `SEUse` indicate whether a given estimate is suitable for primary reporting."), 
        "RealSE is a fit-adjusted companion to ModelSE: ModelSE * sqrt(max(Infit, 1)), so it is never smaller than ModelSE.", 
        "CI_Lower and CI_Upper are symmetric 95% normal bands computed as Estimate +/- qnorm(0.975) * SE. `CI_Level` records 0.95 and `CI_Method` records the interval family. Use `CIEligible`, `InferenceReady`, `CIBasis`, and `CIUse` to distinguish primary-reporting intervals from review or screening approximations.", 
        "Reliability tables use observed variance minus mean squared SE (truncated at zero) for unshrunk point estimates, and the EAP posterior-variance decomposition Var(EAP) / (Var(EAP) + mean(SE^2)) with separation sqrt(Var(EAP)) / RMSE for MML Persons scored by EAP (conditional on the assumed prior and fixed calibration). Model and fit-adjusted values are companion indices, not confidence bounds. Finite-estimate and SE counts state the calculation basis; indices are unavailable if any finite estimate lacks an SE. `Reliability`/`Separation` remain compatibility aliases for the model-based values, while `SourceSupportsFormalInference` describes the input precision only. `ReliabilityUse` labels approximate or review summaries; `SupportsFormalInference` is FALSE for these derived indices, which do not propagate covariance among estimates."))
    marginal_fit <- if (diagnostic_mode %in% c("marginal_fit", "both")) {
        calc_marginal_fit_bundle(res)
    }
    else {
        list(available = FALSE, summary = tibble(Available = FALSE, Method = method, Model = as.character(res$config$model %||% 
            res$summary$Model[1] %||% NA_character_), Basis = "latent_integrated_first_order_counts", 
            Reason = "Not computed; use `diagnostic_mode = \"marginal_fit\"` or `\"both\"`."), thresholds = list(abs_z_warn = 2, 
            rmsd_warn = 0.05), notes = "Strict marginal diagnostics were not requested for this run.")
    }
    diagnostic_basis_tbl <- build_diagnostic_basis_guide(diagnostic_mode = diagnostic_mode, marginal_fit = marginal_fit)
    fit_standardization <- tibble::tibble(PrimaryFitDfMethod = fit_df_method, PrimaryZSTDColumns = if (identical(fit_df_method, 
        "facets")) {
        "InfitZSTD / OutfitZSTD use FACETS-style df"
    }
    else {
        "InfitZSTD / OutfitZSTD use engine df"
    }, EngineDf = "DF_Infit = sum(Var * Weight); DF_Outfit = sum(Weight)", FacetsDf = "DF = 2 / q^2 using the Wright-Masters/FACETS fourth-moment approximation", 
        FacetsColumnsAvailable = identical(fit_df_method, "both") || identical(fit_df_method, "facets"), 
        ZSTDTransform = fit_zstd_transform_label(whexact), FacetsZSTDCap = if (identical(fit_df_method, 
            "engine")) 
            NA_real_
        else 9)
    fit_readiness_record <- mfrmr_get_readiness_record(res)
    list(calculation_version = 2L, obs = obs_df, facet_names = res$config$facet_names, replay_inputs = list(interaction_pairs = interaction_pairs, 
        top_n_interactions = top_n_interactions, whexact = whexact, fit_df_method = fit_df_method, diagnostic_mode = diagnostic_mode, 
        residual_pca = residual_pca, pca_max_factors = pca_max_factors), diagnostic_mode = diagnostic_mode, 
        diagnostic_basis = diagnostic_basis_tbl, fit_standardization = fit_standardization, fit_readiness = as.data.frame(fit_readiness_record$fit %||% 
            data.frame(), stringsAsFactors = FALSE), fit_readiness_components = as.data.frame(fit_readiness_record$components %||% 
            data.frame(), stringsAsFactors = FALSE), fit_readiness_parameters = mfrm_update_slope_readiness_parameters(fit_readiness_record$parameters %||% 
            mfrmr_readiness_empty_parameter_table, structural_uncertainty$slopes), overall_fit = overall_fit, 
        measures = measures, fit = fit_tbl, reliability = reliability_tbl, precision_profile = precision_profile_tbl, 
        precision_review = precision_review_tbl, parameter_uncertainty = structural_uncertainty, facet_precision = facet_precision_tbl, 
        facets_chisq = facets_chisq_tbl, bias = bias_tbl, interactions = interaction_tbl, interrater = interrater_tbl, 
        unexpected = list(table = utils::head(unexpected_tbl, 100L), summary = unexpected_summary, thresholds = list(abs_z_min = unexpected_abs_z_min, 
            prob_max = unexpected_prob_max, rule = unexpected_rule)), fair_average = fair_average, displacement = list(table = displacement_tbl, 
            summary = displacement_summary, thresholds = list(abs_displacement_warn = displacement_abs_warn, 
                abs_t_warn = displacement_abs_t_warn)), approximation_notes = approximation_notes, marginal_fit = marginal_fit, 
        subsets = subset_tbls, residual_pca_mode = residual_pca, residual_pca_overall = pca_overall, 
        residual_pca_by_facet = pca_by_facet)
}
