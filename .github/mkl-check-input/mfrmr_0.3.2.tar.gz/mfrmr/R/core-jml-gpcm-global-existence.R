mfrmr_jml_gpcm_global_existence_contract_version <- function() {
    "mfrmr-jml-gpcm-global-existence-0.2.3-v1"
}

mfrmr_jml_gpcm_exact_zero_certificate_rows <- function(audit) {
    tables <- list(audit$certificates %||% data.frame(), audit$rate_certificates %||% data.frame())
    any(vapply(tables, function(value) {
        table <- tryCatch(as.data.frame(value, stringsAsFactors = FALSE), error = function(e) data.frame())
        if (nrow(table) == 0L || !all(c("BoundaryLogLikelihood", "Certified") %in% names(table))) {
            return(FALSE)
        }
        boundary <- suppressWarnings(as.numeric(table$BoundaryLogLikelihood))
        certified <- as.logical(table$Certified)
        analytic <- if ("AnalyticTailCertified" %in% names(table)) {
            as.logical(table$AnalyticTailCertified)
        } else {
            rep(TRUE, nrow(table))
        }
        any(certified %in% TRUE & analytic %in% TRUE & is.finite(boundary) & boundary == 0)
    }, logical(1)))
}

audit_mfrm_jml_gpcm_global_existence <- function(config, person_boundary, joint_additive, parameter_sequence_flag, 
    slope_boundary = list(), joint_slope_boundary = list(), retained_log_likelihood = NA_real_) {
    method <- as.character(config$method %||% "unknown")[1]
    model <- as.character(config$model %||% "unknown")[1]
    retained <- mfrmr_jml_gpcm_exponential_balance_scalar(retained_log_likelihood)
    source_matches <- identical(as.character(parameter_sequence_flag$contract_version %||% "")[1], mfrmr_jml_gpcm_parameter_sequence_flag_contract_version()) && 
        isTRUE(parameter_sequence_flag$every_parameter_sequence_has_classifiable_further_subsequence_likelihood_limit)
    finish <- function(state, evaluated, nonexistence, supremum_zero, detail, reason_codes, person_count = 0L, 
        additive_cone = FALSE, zero_path_source = "none") {
        list(contract_version = mfrmr_jml_gpcm_global_existence_contract_version(), method = method, 
            model = model, estimator_identity = "unpenalized_fixed_effects_jml_no_finite_box", objective_identity = "identified_conditional_joint_log_likelihood", 
            state = state, evaluated = isTRUE(evaluated), retained_log_likelihood = as.numeric(retained), 
            retained_point_finite = is.finite(retained), retained_point_is_optimizer_trace_only = TRUE, 
            source_parameter_sequence_flag_contract = as.character(parameter_sequence_flag$contract_version %||% 
                "missing")[1], source_parameter_sequence_flag_contract_matches = isTRUE(source_matches), 
            every_parameter_sequence_has_classifiable_further_subsequence_likelihood_limit = isTRUE(source_matches), 
            free_extreme_person_recession_count = as.integer(person_count), global_additive_recession_cone_certified = isTRUE(additive_cone), 
            universal_upper_bound_zero_path_source = zero_path_source, universal_finite_log_likelihood_upper_bound = 0, 
            global_supremum_value_classified = isTRUE(supremum_zero), global_log_likelihood_supremum = if (isTRUE(supremum_zero)) 0 else NA_real_, 
            global_boundary_competitiveness_certified = isTRUE(supremum_zero) || isTRUE(nonexistence), 
            finite_jmle_existence_classified = isTRUE(nonexistence), finite_jmle_existence_certified = FALSE, 
            finite_jmle_nonexistence_certified = isTRUE(nonexistence), global_boundary_classified = isTRUE(nonexistence), 
            global_boundary_presence_certified = isTRUE(nonexistence), global_boundary_absence_certified = FALSE, 
            complete_boundary_envelope_constructed = FALSE, finite_over_complete_boundary_gap_certified = FALSE, 
            production_parameter_path_declared = FALSE, original_optimizer_sequence_limit_classified = FALSE, 
            standard_error_eligible = FALSE, confidence_interval_eligible = FALSE, external_comparison_eligible = FALSE, 
            readiness_effect = "none_diagnostic_only", reason_codes = reason_codes, detail = detail, 
            limitations = paste("A positive strict recession direction proves finite-JMLE", "nonexistence, but a negative bounded search does not prove finite", 
                "attainment. Without a complete boundary limsup envelope strictly", "below a finite point, finite existence remains open. MML, uncertainty,", 
                "readiness, recovery, simulation, and external comparison are outside", "this contract."))
    }
    if (!identical(model, "GPCM")) {
        out <- finish("not_applicable_model", FALSE, FALSE, FALSE, "The global-existence analysis applies only to GPCM.", 
            "global_existence_not_applicable_model")
        out$estimator_identity <- "not_applicable"
        out$objective_identity <- "not_applicable"
        return(out)
    }
    if (!identical(method, "JML")) {
        out <- finish("not_applicable_estimator", FALSE, FALSE, FALSE, "The conditional JML result is not reused for marginal MML.", 
            "global_existence_not_applicable_estimator")
        out$estimator_identity <- "not_applicable"
        out$objective_identity <- "not_applicable_marginal_estimator"
        return(out)
    }
    if (as.integer(config$gpcm_spec$n_params %||% 0L) == 0L) {
        return(finish("not_required_unit_slope", FALSE, FALSE, FALSE, "The exact unit-slope reduction continues to use the PCM geometry.", 
            "no_free_log_slope_coordinate"))
    }
    if (!source_matches) {
        return(finish("not_evaluated_source_contract", FALSE, FALSE, FALSE, "The current further-subsequence limit classification is required.", 
            "global_existence_parameter_sequence_flag_source_mismatch"))
    }
    person_status <- tryCatch(as.data.frame(person_boundary$parameter_status, stringsAsFactors = FALSE), 
        error = function(e) data.frame())
    person_contract_matches <- identical(as.character(person_boundary$contract_version %||% "")[1], mfrmr_readiness_contract_version()) && 
        identical(as.character(person_boundary$method %||% "")[1], "JML") && identical(as.character(person_boundary$model %||% 
        "")[1], "GPCM")
    free_extreme <- if (person_contract_matches && nrow(person_status) > 0L && "ParameterStatus" %in% 
        names(person_status)) {
        as.character(person_status$ParameterStatus) %in% c("unbounded_low", "unbounded_high")
    }
    else {
        logical(0)
    }
    person_count <- sum(free_extreme)
    cone_table <- tryCatch(as.data.frame(joint_additive$cone_certificate, stringsAsFactors = FALSE), 
        error = function(e) data.frame())
    cone_contract_matches <- identical(as.character(joint_additive$contract_version %||% "")[1], mfrmr_readiness_contract_version()) && 
        identical(as.character(joint_additive$method %||% "")[1], "JML") && identical(as.character(joint_additive$model %||% 
        "")[1], "GPCM")
    additive_cone <- cone_contract_matches && isTRUE(joint_additive$prescreen$cone_certified) && nrow(cone_table) > 
        0L && all(c("Certified", "StrictContrastRows", "DirectionL1") %in% names(cone_table)) && any(as.logical(cone_table$Certified) %in% 
        TRUE & suppressWarnings(as.numeric(cone_table$StrictContrastRows)) > 0 & suppressWarnings(as.numeric(cone_table$DirectionL1)) > 
        0)
    slope_source_matches <- identical(as.character(slope_boundary$contract_version %||% "")[1], mfrmr_readiness_contract_version()) && 
        identical(as.character(slope_boundary$method %||% "")[1], "JML") && identical(as.character(slope_boundary$model %||% 
        "")[1], "GPCM")
    joint_source_matches <- identical(as.character(joint_slope_boundary$contract_version %||% "")[1], 
        mfrmr_readiness_contract_version()) && identical(as.character(joint_slope_boundary$method %||% 
        "")[1], "JML") && identical(as.character(joint_slope_boundary$model %||% "")[1], "GPCM")
    slope_zero <- slope_source_matches && mfrmr_jml_gpcm_exact_zero_certificate_rows(slope_boundary)
    joint_zero <- joint_source_matches && mfrmr_jml_gpcm_exact_zero_certificate_rows(joint_slope_boundary)
    supremum_zero <- slope_zero || joint_zero
    zero_source <- if (slope_zero && joint_zero) {
        "slope_only_and_joint_slope_additive_analytic_paths"
    }
    else if (slope_zero) {
        "slope_only_analytic_path"
    }
    else if (joint_zero) {
        "joint_slope_additive_analytic_path"
    }
    else {
        "none"
    }
    nonexistence <- supremum_zero || person_count > 0L || additive_cone
    if (supremum_zero) {
        return(finish("global_supremum_zero_finite_jmle_nonexistence_certified", TRUE, TRUE, TRUE, paste("An analytic parameter-reachable boundary path attains the universal", 
            "conditional log-likelihood upper bound zero. No finite response", "vector can attain zero."), 
            paste("analytic_boundary_path_reaches_zero", "global_log_likelihood_supremum_zero", "finite_jmle_nonexistence_certified", 
                sep = ";"), person_count = person_count, additive_cone = additive_cone, zero_path_source = zero_source))
    }
    if (nonexistence) {
        recession_reasons <- c(if (person_count > 0L) "free_extreme_person_strict_recession", if (additive_cone) "global_additive_strict_recession_cone", 
            "finite_jmle_nonexistence_certified")
        return(finish("finite_jmle_nonexistence_certified_strict_additive_recession", TRUE, TRUE, FALSE, 
            paste("A free extreme-Person direction or a certified global additive", "recession cone strictly improves the conditional likelihood from", 
                "every finite point while respecting the identified coordinates."), paste(recession_reasons, 
                collapse = ";"), person_count = person_count, additive_cone = additive_cone))
    }
    finish("global_finite_jmle_existence_open_complete_boundary_envelope_unavailable", TRUE, FALSE, FALSE, 
        paste("No strict recession certificate was present. The finite-limit analysis ensures", "further-subsequence limit classification, but the package has not", 
            "constructed a complete upper envelope over every reachable boundary", "flag, so a finite optimizer trace cannot be promoted to a finite JMLE."), 
        paste("no_production_strict_recession_certificate", "complete_boundary_envelope_unavailable", 
            "finite_jmle_existence_open", sep = ";"))
}
