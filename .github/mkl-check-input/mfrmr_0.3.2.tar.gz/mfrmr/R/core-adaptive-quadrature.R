mfrmr_adaptive_integration <- function(config) {
    mode <- config$estimation_control$mml_integration %||% "fixed"
    if (!is.character(mode) || length(mode) != 1L || !mode %in% c("fixed", "adaptive")) {
        stop("Unrecognized MML integration mode in the retained configuration.", call. = FALSE)
    }
    identical(mode, "adaptive")
}

new_adaptive_quadrature_numeric_error <- function(message) {
    structure(list(message = message, call = NULL), class = c("mfrmr_adaptive_quadrature_numeric_error", 
        "error", "condition"))
}

mfrmr_adaptive_posterior_location <- function(evaluate) {
    mode <- stats::uniroot(function(z) evaluate(z)$score, c(-1, 1), extendInt = "downX", check.conv = TRUE, 
        tol = 1e-12)$root
    at_mode <- evaluate(mode)
    scale <- 1/sqrt(at_mode$information)
    if (!is.finite(scale) || scale <= 0) {
        stop(new_adaptive_quadrature_numeric_error("Invalid local posterior scale."))
    }
    list(mode = mode, scale = scale, score = at_mode$score)
}

mfrmr_adaptive_quadrature_basis <- function(idx, config, params, quad, base_eta, population_spec = NULL, 
    person_count = config$n_person) {
    basis <- resolve_person_quadrature_basis(quad, population_spec %||% materialize_population_spec(config, 
        params), person_count = person_count)
    mu <- if (isTRUE(basis$transformed)) 
        basis$mu
    else rep(0, person_count)
    sigma <- if (isTRUE(basis$transformed)) 
        basis$sigma
    else 1
    weights <- idx$weight %||% rep(1, length(idx$score_k))
    if (any(!is.finite(weights)) || any(weights < 0)) {
        stop("Adaptive quadrature requires finite non-negative observation weights.", call. = FALSE)
    }
    persons <- sort(unique(idx$person))
    groups <- split(seq_along(idx$person), factor(idx$person, levels = persons))
    if (length(persons) > 0L && mfrm_use_cpp11_backend(config)) {
        group_starts <- c(0L, cumsum(lengths(groups)))
        group_rows <- as.integer(unlist(groups, use.names = FALSE))
        model_code <- mfrm_model_code(config$model)
        step_cum_rsm <- if (model_code == 0L) 
            c(0, cumsum(params$steps))
        else numeric(0)
        step_cum_mat <- if (model_code == 0L) 
            matrix(0, 0L, 0L)
        else mfrm_step_cum_matrix(params$steps_mat)
        step_idx <- if (model_code == 0L) 
            integer(0)
        else as.integer(idx$step_idx)
        slopes <- if (model_code == 2L) 
            as.double(params$slopes)
        else numeric(0)
        slope_idx <- if (model_code == 2L) 
            as.integer(idx$slope_idx)
        else integer(0)
        init_nodes <- as.matrix(basis$nodes)
        if (!is.double(init_nodes)) 
            storage.mode(init_nodes) <- "double"
        init_log_weights <- as.matrix(basis$log_weights)
        if (!is.double(init_log_weights)) 
            storage.mode(init_log_weights) <- "double"
        res <- mfrm_cpp_adaptive_quad_basis(model_code = model_code, k_cat = as.integer(config$n_cat), 
            persons = as.integer(persons), group_starts = as.integer(group_starts), group_rows = group_rows, 
            score_k = as.integer(idx$score_k), weights = as.double(weights), base_eta = as.double(base_eta), 
            step_cum_rsm = as.double(step_cum_rsm), step_cum_mat = step_cum_mat, step_idx = step_idx, 
            slopes = slopes, slope_idx = slope_idx, mu = as.double(mu), sigma = as.double(sigma), quad_nodes = as.double(quad$nodes), 
            log_quad_weights = log(as.double(quad$weights)), log_dnorm_quad_nodes = stats::dnorm(as.double(quad$nodes), 
                log = TRUE), init_nodes = init_nodes, init_log_weights = init_log_weights)
        if (res$error_code != 0L && res$error_code != 5L) {
            if (res$error_code == 3L) {
                stop(res$error_message, call. = FALSE)
            }
            stop(new_adaptive_quadrature_numeric_error(res$error_message))
        }
        if (res$error_code == 0L) {
            dimnames(res$nodes) <- dimnames(basis$nodes)
            dimnames(res$log_weights) <- dimnames(basis$log_weights)
            basis$nodes <- res$nodes
            basis$log_weights <- res$log_weights
            return(basis)
        }
    }
    for (i in seq_along(groups)) {
        person <- persons[i]
        rows <- groups[[i]]
        local_idx <- list(person = rep(1L, length(rows)), score_k = idx$score_k[rows], weight = weights[rows], 
            step_idx = idx$step_idx[rows], slope_idx = idx$slope_idx[rows])
        evaluate <- mfrmr_adaptive_person_kernel(local_idx, config, params, base_eta[rows], mu[person], 
            sigma)
        location <- mfrmr_adaptive_posterior_location(evaluate)
        z <- location$mode + location$scale * quad$nodes
        basis$nodes[person, ] <- mu[person] + sigma * z
        basis$log_weights[person, ] <- log(quad$weights) + stats::dnorm(z, log = TRUE) - stats::dnorm(quad$nodes, 
            log = TRUE) + log(location$scale)
    }
    basis
}

mfrmr_adaptive_person_kernel <- function(idx, config, params, base_eta, mu, sigma) {
    config$n_person <- 1L
    config$population_spec <- list(active = FALSE)
    categories <- seq_len(config$n_cat) - 1L
    slope <- if (identical(config$model, "GPCM")) 
        params$slopes[idx$slope_idx]
    else rep(1, length(idx$score_k))
    if (any(!is.finite(slope)) || any(slope <= 0)) {
        stop("The retained slopes are not positive finite values.", call. = FALSE)
    }
    step_cum <- if (config$model == "RSM") {
        c(0, cumsum(params$steps))
    }
    else {
        t(apply(params$steps_mat, 1, function(x) c(0, cumsum(x))))
    }
    n <- length(idx$score_k)
    rows <- seq_len(n)
    step_rows <- if (config$model == "RSM") {
        matrix(step_cum, n, length(categories), byrow = TRUE)
    }
    else step_cum[idx$step_idx, , drop = FALSE]
    function(z, include_linear_part = FALSE, include_moments = TRUE) {
        if (!include_moments && mfrm_use_cpp11_backend(config, include_linear_part)) {
            bundle <- mfrm_mml_logprob_bundle_cpp11(idx, config, list(nodes = mu + sigma * z, weights = rep(1, 
                length(z))), params, base_eta, step_cum = step_cum, include_probs = FALSE)
            return(list(log_likelihood = colSums(bundle$log_prob_mat)))
        }
        node_rows <- rep(rows, length(z))
        eta <- base_eta[node_rows] + rep(mu + sigma * z, each = n)
        linear <- outer(eta, categories) - step_rows[node_rows, , drop = FALSE]
        log_num <- if (identical(config$model, "GPCM")) 
            linear * slope[node_rows]
        else linear
        flat_rows <- seq_along(node_rows)
        row_max <- log_num[cbind(flat_rows, max.col(log_num, ties.method = "first"))]
        log_num <- log_num - row_max
        log_denom <- log(rowSums(exp(log_num)))
        log_prob <- log_num[cbind(flat_rows, idx$score_k[node_rows] + 1L)] - log_denom
        if (!is.null(idx$weight)) 
            log_prob <- log_prob * idx$weight[node_rows]
        log_likelihood <- colSums(matrix(log_prob, n, length(z)))
        if (!include_moments) 
            return(list(log_likelihood = log_likelihood))
        probability <- exp(log_num - log_denom)
        node_indices <- lapply(seq_along(z), function(q) rows + (q - 1L) * n)
        prob_list <- lapply(node_indices, function(i) probability[i, , drop = FALSE])
        linear_part_list <- if (include_linear_part) {
            if (identical(config$model, "GPCM")) {
                lapply(node_indices, function(i) linear[i, , drop = FALSE])
            }
            else vector("list", length(z))
        }
        else NULL
        expected <- as.vector(probability %*% categories)
        variance <- rowSums(probability * (rep(categories, each = nrow(probability)) - expected)^2)
        moments <- rbind(score = sigma * colSums(matrix((idx$weight * slope)[node_rows] * (idx$score_k[node_rows] - 
            expected), n)), information = sigma^2 * colSums(matrix((idx$weight * slope^2)[node_rows] * 
            variance, n)))
        if (any(!is.finite(moments))) {
            stop(new_adaptive_quadrature_numeric_error("Non-finite adaptive posterior score or information."))
        }
        list(log_likelihood = log_likelihood, score = moments[1L, ] - z, information = moments[2L, ] + 
            1, prob_list = prob_list, linear_part_list = linear_part_list)
    }
}




pack_pattern_csc_designs <- function(mat_list) {
    n_pat <- length(mat_list)
    pat_col_starts <- integer(n_pat + 1L)
    active_cols_list <- vector("list", n_pat)
    col_counts_list <- vector("list", n_pat)
    row_i_list <- vector("list", n_pat)
    val_x_list <- vector("list", n_pat)
    total_active <- 0L
    for (pat in seq_len(n_pat)) {
        m <- mat_list[[pat]]
        if (!inherits(m, "dgCMatrix")) {
            m <- methods::as(methods::as(methods::as(m, "dMatrix"), "generalMatrix"), "CsparseMatrix")
        }
        counts <- diff(m@p)
        nz_cols <- which(counts > 0L)
        active_cols_list[[pat]] <- nz_cols - 1L
        col_counts_list[[pat]] <- counts[nz_cols]
        row_i_list[[pat]] <- m@i
        val_x_list[[pat]] <- m@x
        total_active <- total_active + length(nz_cols)
        pat_col_starts[pat + 1L] <- total_active
    }
    active_col <- if (total_active > 0L) 
        as.integer(unlist(active_cols_list, use.names = FALSE))
    else integer(0)
    col_counts <- if (total_active > 0L) 
        as.integer(unlist(col_counts_list, use.names = FALSE))
    else integer(0)
    col_val_starts <- c(0L, cumsum(col_counts))
    row_i <- if (total_active > 0L) 
        as.integer(unlist(row_i_list, use.names = FALSE))
    else integer(0)
    val_x <- if (total_active > 0L) 
        as.double(unlist(val_x_list, use.names = FALSE))
    else numeric(0)
    list(pat_col_starts = as.integer(pat_col_starts), active_col = active_col, col_val_starts = as.integer(col_val_starts), 
        row_i = row_i, val_x = val_x)
}

mfrmr_make_adaptive_mml_evaluator <- function(idx, config, sizes, quad_points, reuse_identical_patterns = TRUE, 
    include_person_summaries = FALSE) {
    if (!identical(config$method, "MML")) {
        stop("Adaptive MML evaluation requires an MML configuration.", call. = FALSE)
    }
    rule <- gauss_hermite_normal(quad_points)
    n <- length(idx$score_k)
    p <- sum(unlist(sizes, use.names = FALSE))
    categories <- seq_len(config$n_cat) - 1L
    weights <- idx$weight %||% rep(1, n)
    if (length(weights) != n || any(!is.finite(weights)) || any(weights < 0)) {
        stop("Adaptive MML requires finite non-negative observation weights.", call. = FALSE)
    }
    slices <- build_param_slices(sizes)
    adjacent <- mfrmr_estimability_adjacent_design(NULL, idx, config, sizes, include_person = FALSE, 
        include_population_beta = FALSE)
    mapping <- Matrix::sparseMatrix(i = seq_len(ncol(adjacent$design)), j = adjacent$map$OptimizerIndex, 
        x = 1, dims = c(ncol(adjacent$design), p))
    adjacent <- adjacent$design %*% mapping
    cumulative <- lapply(seq_len(config$n_cat - 1L), function(k) {
        adjacent[seq_len(n) + (k - 1L) * n, , drop = FALSE]
    })
    cumulative <- do.call(rbind, Reduce(`+`, cumulative, accumulate = TRUE))
    log_slope_design <- mfrmr_empty_sparse_matrix(n, p)
    if (length(slices[["log_slopes"]])) {
        log_slope_design[, slices[["log_slopes"]]] <- gpcm_log_slope_design(config$gpcm_spec)[idx$slope_idx, 
            , drop = FALSE]
    }
    patterns <- mfrmr_mml_person_design_groups(idx, config, reuse_identical_designs = reuse_identical_patterns, 
        include_responses = TRUE)
    person_ids <- patterns$person_ids[patterns$representative_positions]
    groups <- patterns$canonical_rows[patterns$representative_positions]
    multiplicity <- patterns$group_sizes
    designs <- lapply(groups, function(rows) {
        list(cumulative = cumulative[as.vector(outer(rows, (categories[-1L] - 1L) * n, `+`)), , drop = FALSE], 
            log_slope = log_slope_design[rows, , drop = FALSE])
    })
    cum_packed <- pack_pattern_csc_designs(lapply(designs, `[[`, "cumulative"))
    has_log_slopes <- length(slices[["log_slopes"]]) > 0L
    ls_packed <- if (has_log_slopes) {
        pack_pattern_csc_designs(lapply(designs, `[[`, "log_slope"))
    }
    else {
        list(pat_col_starts = integer(length(groups) + 1L), active_col = integer(0), col_val_starts = 0L, 
            row_i = integer(0), val_x = numeric(0))
    }
    pat_row_starts <- as.integer(c(0L, cumsum(lengths(groups))))
    pat_obs_idx <- if (length(groups) > 0L) 
        as.integer(unlist(groups, use.names = FALSE))
    else integer(0)
    log_rule_weights <- log(as.double(rule$weights))
    log_dnorm_rule_nodes <- stats::dnorm(as.double(rule$nodes), log = TRUE)
    beta_cols0 <- if (length(slices[["beta"]])) 
        as.integer(slices[["beta"]] - 1L)
    else integer(0)
    log_sigma2_col0 <- if (length(slices[["log_sigma2"]])) 
        as.integer(slices[["log_sigma2"]][1L] - 1L)
    else -1L
    summary_pat_map <- if (include_person_summaries) {
        mp <- integer(length(patterns$person_ids))
        for (i in seq_along(groups)) {
            mp[patterns$group_positions[[i]]] <- i
        }
        mp
    }
    else {
        integer(0)
    }
    function(par) {
        if (length(par) != p || any(!is.finite(par))) {
            stop("Adaptive MML requires a finite free-parameter vector of the expected length.", call. = FALSE)
        }
        params <- expand_params(par, sizes, config)
        base <- compute_base_eta(idx, params, config)
        population <- materialize_population_spec(config, params)
        basis <- resolve_person_quadrature_basis(list(nodes = 0, weights = 1), population, person_count = config$n_person)
        mu <- if (isTRUE(basis$transformed)) 
            basis$mu
        else rep(0, config$n_person)
        sigma <- if (isTRUE(basis$transformed)) 
            basis$sigma
        else 1
        if (mfrm_use_cpp11_backend(config)) {
            model_code <- mfrm_model_code(config$model)
            step_cum_rsm <- if (model_code == 0L) 
                c(0, cumsum(params$steps))
            else numeric(0)
            step_cum_mat <- if (model_code == 0L) 
                matrix(0, 0L, 0L)
            else mfrm_step_cum_matrix(params$steps_mat)
            step_idx_cpp <- if (model_code == 0L) 
                integer(0)
            else as.integer(idx$step_idx)
            slopes_cpp <- if (model_code == 2L) 
                as.double(params$slopes)
            else numeric(0)
            slope_idx_cpp <- if (model_code == 2L) 
                as.integer(idx$slope_idx)
            else integer(0)
            pat_pop_design <- if (length(beta_cols0) > 0L) {
                pm <- as.matrix(population$design_matrix[population$person_lookup[person_ids], , drop = FALSE])
                if (!is.double(pm)) 
                  storage.mode(pm) <- "double"
                pm
            }
            else {
                matrix(0, 0L, 0L)
            }
            res <- mfrm_cpp_adaptive_mml_eval(model_code = model_code, k_cat = as.integer(config$n_cat), 
                p_dim = as.integer(p), pat_person_ids = as.integer(person_ids), pat_multiplicity = as.double(multiplicity), 
                pat_row_starts = pat_row_starts, pat_obs_idx = pat_obs_idx, score_k = as.integer(idx$score_k), 
                weights = as.double(weights), base_eta = as.double(base), step_cum_rsm = as.double(step_cum_rsm), 
                step_cum_mat = step_cum_mat, step_idx = step_idx_cpp, slopes = slopes_cpp, slope_idx = slope_idx_cpp, 
                mu = as.double(mu), sigma = as.double(sigma), rule_nodes = as.double(rule$nodes), log_rule_weights = log_rule_weights, 
                log_dnorm_rule_nodes = log_dnorm_rule_nodes, cum_pat_col_starts = cum_packed$pat_col_starts, 
                cum_active_col = cum_packed$active_col, cum_col_val_starts = cum_packed$col_val_starts, 
                cum_row_i = cum_packed$row_i, cum_val_x = cum_packed$val_x, has_log_slopes = has_log_slopes, 
                ls_pat_col_starts = ls_packed$pat_col_starts, ls_active_col = ls_packed$active_col, ls_col_val_starts = ls_packed$col_val_starts, 
                ls_row_i = ls_packed$row_i, ls_val_x = ls_packed$val_x, beta_cols0 = beta_cols0, pat_pop_design = pat_pop_design, 
                log_sigma2_col0 = log_sigma2_col0, include_person_summaries = isTRUE(include_person_summaries))
            if (res$error_code != 0L && res$error_code != 5L) {
                if (res$error_code == 3L) {
                  stop(res$error_message, call. = FALSE)
                }
                stop(new_adaptive_quadrature_numeric_error(res$error_message))
            }
            if (res$error_code == 0L) {
                if (!is.finite(res$value) || any(!is.finite(res$gradient))) {
                  stop(new_adaptive_quadrature_numeric_error("Non-finite adaptive MML objective or gradient."))
                }
                out <- list(value = res$value, gradient = res$gradient)
                if (include_person_summaries) {
                  person_summaries <- res$pat_summaries[summary_pat_map, , drop = FALSE]
                  colnames(person_summaries) <- c("LogMarginal", "EAP", "PosteriorSD")
                  if (any(!is.finite(person_summaries))) {
                    stop(new_adaptive_quadrature_numeric_error("Non-finite posterior moments."))
                  }
                  out$per_person <- data.frame(PersonIndex = patterns$person_ids, person_summaries)
                }
                return(out)
            }
        }
        value <- 0
        gradient <- numeric(p)
        if (include_person_summaries) {
            person_summaries <- matrix(NA_real_, length(patterns$person_ids), 3L, dimnames = list(NULL, 
                c("LogMarginal", "EAP", "PosteriorSD")))
        }
        for (i in seq_along(groups)) {
            person <- person_ids[i]
            rows <- groups[[i]]
            local_idx <- list(person = rep(1L, length(rows)), score_k = idx$score_k[rows], weight = weights[rows], 
                step_idx = idx$step_idx[rows], slope_idx = idx$slope_idx[rows])
            slope <- if (identical(config$model, "GPCM")) 
                params$slopes[local_idx$slope_idx]
            else rep(1, length(rows))
            evaluate <- mfrmr_adaptive_person_kernel(local_idx, config, params, base[rows], mu[person], 
                sigma)
            location <- mfrmr_adaptive_posterior_location(evaluate)
            mode <- location$mode
            at_mode <- evaluate(mode, include_linear_part = TRUE)
            scale <- location$scale
            mean_derivative <- variance_derivative <- numeric(p)
            if (length(slices[["beta"]])) {
                mean_derivative[slices[["beta"]]] <- population$design_matrix[population$person_lookup[person], 
                  ]
            }
            if (length(slices[["log_sigma2"]])) 
                variance_derivative[slices[["log_sigma2"]]] <- 1
            project <- function(coefficient, linear) {
                answer <- as.numeric(Matrix::crossprod(designs[[i]]$cumulative, as.vector(coefficient[, 
                  -1L, drop = FALSE] * slope)))
                if (length(slices[["log_slopes"]])) {
                  answer <- answer + as.numeric(Matrix::crossprod(designs[[i]]$log_slope, rowSums(coefficient * 
                    linear) * slope))
                }
                answer
            }
            probability <- at_mode$prob_list[[1L]]
            expected <- as.vector(probability %*% categories)
            centered <- rep(categories, each = length(rows)) - expected
            variance <- rowSums(probability * centered^2)
            w <- local_idx$weight
            linear <- at_mode$linear_part_list[[1L]]
            mixed <- -project(probability * centered * (w * slope), linear) + as.numeric(Matrix::crossprod(designs[[i]]$log_slope, 
                w * slope * (local_idx$score_k - expected))) + mean_derivative/sigma^2 + mode/sigma * 
                variance_derivative
            curvature_derivative <- project(probability * (centered^2 - variance) * (w * slope^2), linear) + 
                as.numeric(Matrix::crossprod(designs[[i]]$log_slope, 2 * w * slope^2 * variance)) - variance_derivative/sigma^2
            curvature_theta <- sum(w * slope^3 * rowSums(probability * centered^3))
            curvature <- at_mode$information/sigma^2
            mode_derivative <- mixed/curvature
            log_scale_derivative <- -(curvature_derivative + curvature_theta * mode_derivative)/(2 * 
                curvature)
            z <- mode + scale * rule$nodes
            nodes <- evaluate(z, include_linear_part = TRUE)
            offset <- max(nodes$log_likelihood)
            joint <- log(rule$weights) + (nodes$log_likelihood - offset) + stats::dnorm(z, log = TRUE) - 
                stats::dnorm(rule$nodes, log = TRUE) + log(scale)
            if (any(!is.finite(joint))) {
                stop(new_adaptive_quadrature_numeric_error("Non-finite integration terms."))
            }
            normalizer <- logsumexp(joint)
            posterior <- exp(joint - max(joint))
            posterior <- posterior/sum(posterior)
            value <- value - multiplicity[i] * (offset + normalizer)
            if (include_person_summaries) {
                center <- sum(posterior * z)
                moments <- c(offset + normalizer, mu[person] + sigma * center, sigma * sqrt(sum(posterior * 
                  (z - center)^2)))
                person_summaries[patterns$group_positions[[i]], ] <- matrix(moments, multiplicity[i], 
                  3L, byrow = TRUE)
            }
            residual_mean <- matrix(0, length(rows), config$n_cat)
            slope_mean <- numeric(length(rows))
            observed <- cbind(seq_along(rows), local_idx$score_k + 1L)
            for (q in seq_along(rule$nodes)) {
                residual <- -nodes$prob_list[[q]]
                residual[observed] <- residual[observed] + 1
                residual_mean <- residual_mean + posterior[q] * residual
                if (length(slices[["log_slopes"]])) {
                  slope_mean <- slope_mean + posterior[q] * rowSums(residual * nodes$linear_part_list[[q]])
                }
            }
            fixed_derivative <- as.numeric(Matrix::crossprod(designs[[i]]$cumulative, as.vector(residual_mean[, 
                -1L, drop = FALSE] * (w * slope))))
            if (length(slices[["log_slopes"]])) {
                fixed_derivative <- fixed_derivative + as.numeric(Matrix::crossprod(designs[[i]]$log_slope, 
                  slope_mean * (w * slope)))
            }
            fixed_derivative <- fixed_derivative + sum(posterior * z)/sigma * mean_derivative + sum(posterior * 
                (z^2 - 1))/2 * variance_derivative
            gradient <- gradient - multiplicity[i] * (fixed_derivative + sum(posterior * nodes$score)/sigma * 
                mode_derivative + sum(posterior * (scale * nodes$score * rule$nodes + 1)) * log_scale_derivative)
        }
        if (!is.finite(value) || any(!is.finite(gradient))) {
            stop(new_adaptive_quadrature_numeric_error("Non-finite adaptive MML objective or gradient."))
        }
        out <- list(value = value, gradient = gradient)
        if (include_person_summaries) {
            if (any(!is.finite(person_summaries))) {
                stop(new_adaptive_quadrature_numeric_error("Non-finite posterior moments."))
            }
            out$per_person <- data.frame(PersonIndex = patterns$person_ids, person_summaries)
        }
        out
    }
}
