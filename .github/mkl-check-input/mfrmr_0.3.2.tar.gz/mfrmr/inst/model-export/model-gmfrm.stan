functions {
  vector mfrmr_logits(real eta, row_vector steps) {
    int C = num_elements(steps) + 1;
    vector[C] logits;
    logits[1] = 0;
    for (k in 2:C)
      logits[k] = logits[k - 1] + eta - steps[k - 1];
    return logits;
  }
}
data {
  int<lower=1> N;
  int<lower=1> J;
  int<lower=2> C;
  int<lower=0> P;
  int<lower=1> L;
  int<lower=1> G;
  int<lower=0> Q;
  int<lower=1> S;
  int<lower=2> A;
  array[N] int<lower=1, upper=J> person;
  array[N] int<lower=1, upper=G> owner;
  array[N] int<lower=1, upper=C> y;
  matrix[N, P] X;
  matrix[L, P] location_basis;
  matrix[C - 1, Q] step_basis;
  vector<lower=0>[P] location_sd;
  real<lower=0> step_sd;
  matrix[A, S] slope_basis;
  matrix[N, S] slope_X;
  vector<lower=0>[S] log_slope_sd;
}
parameters {
  vector[J] theta;
  vector[P] location_free;
  matrix[G, Q] step_free;
  vector[S] log_slope_free;
}
transformed parameters {
  vector[L] locations = location_basis * location_free;
  matrix[G, C - 1] steps = step_free * step_basis';
  vector[A] log_component_slopes = slope_basis * log_slope_free;
  vector[A] component_slopes = exp(log_component_slopes);
}
model {
  vector[N] eta = theta[person] + X * location_free;
  vector[N] effective_slopes = exp(slope_X * log_slope_free);
  theta ~ std_normal();
  log_slope_free ~ normal(0, log_slope_sd);
  location_free ~ normal(0, location_sd);
  to_vector(step_free) ~ normal(0, step_sd);
  for (n in 1:N)
    y[n] ~ categorical_logit(effective_slopes[n] * mfrmr_logits(eta[n], steps[owner[n]]));
}
generated quantities {
  vector[N] log_lik;
  array[N] int y_rep;
  // Row-level work vectors need not be written for every retained draw.
  {
    vector[N] eta = theta[person] + X * location_free;
    vector[N] effective_slopes = exp(slope_X * log_slope_free);
    for (n in 1:N) {
      vector[C] logits = effective_slopes[n] * mfrmr_logits(eta[n], steps[owner[n]]);
      log_lik[n] = categorical_logit_lpmf(y[n] | logits);
      y_rep[n] = categorical_logit_rng(logits);
    }
  }
}
