# Shared toy-fit fixtures for testthat.
#
# testthat sources every `helper-*.R` file in this directory before
# running tests, so anything defined here is visible to all
# `test-*.R` files. The goal is to keep test setup focused on what
# is actually being tested rather than re-typing the same
# `load_mfrmr_data() + fit_mfrm() + diagnose_mfrm()` chain.
#
# Each helper is deterministic and fast (the JML toy fit takes
# well under a second on example_core / example_bias). Caching
# fitted models avoids paying that cost more than once when
# multiple tests in the same session ask for the same fixture.

# Internal fit cache. Diagnostics are computed from the supplied fit so
# changes to its estimates or readiness cannot reuse another fit's results.
.mfrmr_test_cache <- new.env(parent = emptyenv())

# Repository-only integration fixtures occasionally need the development
# namespace. Both `devtools::test()` and installed-package checks load it before
# helpers run. Reloading it here would create stale function/namespace pairs and
# make later mocked-binding tests order-dependent.
.mfrmr_test_ensure_source_namespace <- function(root) {
  if (!file.exists(file.path(root, "DESCRIPTION"))) {
    stop("The mfrmr source root is unavailable.", call. = FALSE)
  }
  if (!"mfrmr" %in% loadedNamespaces()) {
    stop("The mfrmr namespace must be loaded before repository tests run.",
         call. = FALSE)
  }
  invisible(asNamespace("mfrmr"))
}

.mfrmr_test_skip_unless_version <- function(version) {
  testthat::skip_if_not(
    identical(as.character(utils::packageVersion("mfrmr")), version),
    paste("Historical source-bound replay requires mfrmr", version)
  )
}

# Muffle only warnings that a test has explicitly classified as unrelated
# setup noise. Any warning that does not match one of `patterns` continues to
# propagate, so new package warnings cannot be hidden accidentally.
.mfrmr_muffle_expected_warnings <- function(expr, patterns) {
  patterns <- as.character(patterns)
  withCallingHandlers(
    expr,
    warning = function(w) {
      message <- conditionMessage(w)
      matched <- any(vapply(
        patterns,
        function(pattern) grepl(pattern, message, perl = TRUE),
        logical(1)
      ))
      if (matched) {
        invokeRestart("muffleWarning")
      }
    }
  )
}

.cache_key <- function(...) paste(vapply(list(...), function(x) {
  if (is.null(x)) "NULL" else paste(deparse(x), collapse = "|")
}, character(1)), collapse = ":")

#' Toy MFRM fit on `example_core` for tests
#'
#' Returns a deterministic JML fit suitable for smoke / contract
#' tests. The result is cached for repeated calls with the same
#' arguments.
make_toy_fit <- function(method = "JML",
                         maxit = 25,
                         model = "RSM",
                         attach_diagnostics = FALSE,
                         dataset = "example_core") {
  key <- .cache_key("fit", dataset, method, maxit, model, attach_diagnostics)
  if (exists(key, envir = .mfrmr_test_cache, inherits = FALSE)) {
    return(get(key, envir = .mfrmr_test_cache, inherits = FALSE))
  }
  toy <- load_mfrmr_data(dataset)
  fit <- suppressMessages(suppressWarnings(
    fit_mfrm(toy,
             person = "Person",
             facets = c("Rater", "Criterion"),
             score = "Score",
             method = method,
             model = model,
             maxit = maxit)
  ))
  assign(key, fit, envir = .mfrmr_test_cache)
  fit
}

#' Toy diagnostics bundle for the same `example_core` fit
make_toy_diagnostics <- function(fit = NULL,
                                 diagnostic_mode = "legacy",
                                 residual_pca = "none") {
  if (is.null(fit)) fit <- make_toy_fit()
  suppressMessages(suppressWarnings(
    diagnose_mfrm(fit,
                  residual_pca = residual_pca)
  ))
}

#' Loads the toy data + fit + diagnostics into the calling test_that
#' block under the conventional `.toy` / `.fit` / `.diag` names.
#'
#' Tests that follow the `.toy / .fit / .diag` convention can replace
#' an opening `local({ ... })` block with a single call to
#' `local_toy_fit()` inside `test_that()`.
local_toy_fit <- function(envir = parent.frame(),
                          method = "JML",
                          maxit = 25,
                          model = "RSM",
                          dataset = "example_core",
                          diagnostic_mode = "legacy") {
  envir$.toy <- load_mfrmr_data(dataset)
  envir$.fit <- make_toy_fit(method = method, maxit = maxit,
                              model = model, dataset = dataset)
  envir$.diag <- make_toy_diagnostics(envir$.fit,
                                       diagnostic_mode = diagnostic_mode)
  invisible(envir)
}


make_core_workflow <- function() {
  key <- "core_workflow_mml"
  if (!exists(key, envir = .mfrmr_test_cache, inherits = FALSE)) {
    value <- mfrm_analysis(load_mfrmr_data("example_core"), "Person",
      c("Rater", "Criterion"), "Score", dff_group = "Group", cut_scores = 2.5,
      compare_methods = "JML")
    assign(key, value, envir = .mfrmr_test_cache)
  }
  get(key, envir = .mfrmr_test_cache, inherits = FALSE)
}


# Downstream-contract tests use the shipped calibration, never a silent refit.
read_example_bundle <- function(name = "core-jml") {
  readRDS(system.file("examples", paste0(name, ".rds"), package = "mfrmr",
    mustWork = TRUE))
}
